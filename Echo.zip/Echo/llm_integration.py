"""
LLM integration for the Echo cognitive agent.
"""
from typing import Dict, Any, Optional
from interfaces import LLMProvider

class OllamaLLMProvider(LLMProvider):
    """Ollama-based LLM provider."""
    
    def __init__(self, model_name: str = "llama2", base_url: str = "http://localhost:11434"):
        self.model_name = model_name
        self.base_url = base_url
        self._import_ollama()
    
    def _import_ollama(self) -> None:
        """Import ollama package and handle import errors."""
        try:
            import ollama
            self.ollama = ollama
        except ImportError:
            raise ImportError(
                "Ollama package not found. Please install it with: pip install ollama"
            )
    
    def generate(self, prompt: str, **kwargs) -> str:
        """Generate a response using Ollama.
        
        Args:
            prompt: The input prompt.
            **kwargs: Additional parameters for the LLM.
            
        Returns:
            The generated response as a string.
        """
        try:
            response = self.ollama.generate(
                model=self.model_name,
                prompt=prompt,
                **kwargs
            )
            return response["response"]
        except Exception as e:
            raise RuntimeError(f"Error generating response with Ollama: {str(e)}")

class HuggingFaceLLMProvider(LLMProvider):
    """HuggingFace-based LLM provider."""
    
    def __init__(self, model_name: str = "gpt2"):
        self.model_name = model_name
        self._import_transformers()
        self._load_model()
    
    def _import_transformers(self) -> None:
        """Import transformers package and handle import errors."""
        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer
            self.AutoModelForCausalLM = AutoModelForCausalLM
            self.AutoTokenizer = AutoTokenizer
        except ImportError:
            raise ImportError(
                "Transformers package not found. Please install it with: "
                "pip install transformers torch"
            )
    
    def _load_model(self) -> None:
        """Load the model and tokenizer."""
        try:
            self.tokenizer = self.AutoTokenizer.from_pretrained(self.model_name)
            self.model = self.AutoModelForCausalLM.from_pretrained(self.model_name)
        except Exception as e:
            raise RuntimeError(f"Error loading model: {str(e)}")
    
    def generate(self, prompt: str, **kwargs) -> str:
        """Generate a response using HuggingFace model.
        
        Args:
            prompt: The input prompt.
            **kwargs: Additional parameters for the LLM.
            
        Returns:
            The generated response as a string.
        """
        try:
            inputs = self.tokenizer(prompt, return_tensors="pt")
            outputs = self.model.generate(
                inputs["input_ids"],
                max_length=kwargs.get("max_length", 100),
                num_return_sequences=1,
                **kwargs
            )
            response = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
            return response[len(prompt):]  # Remove the prompt from the response
        except Exception as e:
            raise RuntimeError(f"Error generating response with HuggingFace: {str(e)}")

def create_llm_provider(provider_type: str, **kwargs) -> LLMProvider:
    """Create an LLM provider instance.
    
    Args:
        provider_type: The type of provider to create ("ollama" or "huggingface").
        **kwargs: Additional arguments for the provider.
        
    Returns:
        An instance of the specified LLM provider.
        
    Raises:
        ValueError: If an invalid provider type is specified.
    """
    if provider_type.lower() == "ollama":
        return OllamaLLMProvider(**kwargs)
    elif provider_type.lower() == "huggingface":
        return HuggingFaceLLMProvider(**kwargs)
    else:
        raise ValueError(f"Invalid provider type: {provider_type}") 
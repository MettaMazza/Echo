"""
Main script for running the Echo cognitive agent.
"""
import argparse
import sys
import os
from datetime import datetime
from core.agent import EchoAgent
from core.dialogue_interface import DialogueInterface
from core.llm_integration import LLMProvider
from core.service_locator import ServiceLocator
from core.monitoring import SystemMonitor
from core.config import ConfigManager
from core.config_migration import ConfigVersionManager
from core.config_schema import SchemaValidator, create_echo_schema
from core.processor import InputProcessor
from core.context import StateManager
from core.memory import MemorySystem
from core.emotion import EmotionSystem
from core.attention import AttentionSystem
from core.knowledge import KnowledgeGraph
from core.planning import PlanningSystem
from core.decision import DecisionSystem
from core.learning import LearningSystem

def setup_services(config_manager: ConfigManager) -> ServiceLocator:
    """Set up and configure services."""
    services = ServiceLocator()
    
    # Get configuration
    config = config_manager.get_config()
    
    # Register services with configuration
    services.register(LLMProvider(
        model_name=config.llm.model_name,
        temperature=config.llm.temperature,
        max_tokens=config.llm.max_tokens,
        api_key=config.llm.api_key,
        api_base=config.llm.api_base,
        timeout=config.llm.timeout
    ))
    services.register(DialogueInterface())
    
    return services

def setup_processor(config_manager: ConfigManager) -> InputProcessor:
    """Set up the input processor with all required subsystems."""
    config = config_manager.get_config()
    
    # Initialize subsystems
    llm = LLMProvider(
        model_name=config.llm.model_name,
        temperature=config.llm.temperature,
        max_tokens=config.llm.max_tokens,
        api_key=config.llm.api_key,
        api_base=config.llm.api_base,
        timeout=config.llm.timeout
    )
    memory = MemorySystem()
    emotion = EmotionSystem()
    attention = AttentionSystem()
    knowledge = KnowledgeGraph()
    planning = PlanningSystem()
    decision = DecisionSystem()
    learning = LearningSystem()
    state_manager = StateManager()
    
    # Create and return processor
    return InputProcessor(
        llm=llm,
        memory=memory,
        emotion=emotion,
        attention=attention,
        knowledge=knowledge,
        planning=planning,
        decision=decision,
        learning=learning,
        state_manager=state_manager
    )

def run_interactive_mode(processor: InputProcessor, monitor: SystemMonitor, config_manager: ConfigManager):
    """Run the agent in interactive mode."""
    print("Echo Agent initialized. Type 'exit' to quit, 'debug' for debug mode, 'config' to view configuration, 'status' for system status, 'docs' to view configuration documentation, or 'state' to view current state.")
    
    debug_mode = False
    turn_count = 0
    
    while True:
        try:
            # Get user input
            user_input = input("\nYou: ").strip()
            
            # Handle special commands
            if user_input.lower() == 'exit':
                print("\nGoodbye!")
                break
            elif user_input.lower() == 'debug':
                debug_mode = not debug_mode
                print(f"\nDebug mode {'enabled' if debug_mode else 'disabled'}")
                continue
            elif user_input.lower() == 'config':
                config = config_manager.get_config()
                print("\nCurrent Configuration:")
                print(f"LLM Model: {config.llm.model_name}")
                print(f"Temperature: {config.llm.temperature}")
                print(f"Max Tokens: {config.llm.max_tokens}")
                print(f"Log Level: {config.monitoring.log_level}")
                print(f"Log Directory: {config.monitoring.log_dir}")
                continue
            elif user_input.lower() == 'status':
                status = monitor.get_system_health()
                print("\nSystem Status:")
                print(f"Health: {status['health']}")
                print(f"Memory Usage: {status['memory_usage']:.2f}%")
                print(f"Response Time: {status['avg_response_time']:.2f}s")
                print(f"Error Rate: {status['error_rate']:.2f}%")
                continue
            elif user_input.lower() == 'docs':
                validator = SchemaValidator(create_echo_schema())
                docs = validator.generate_docs()
                print("\nConfiguration Documentation:")
                print(docs)
                continue
            elif user_input.lower() == 'state':
                state = processor.state_manager.load_state()
                if state:
                    print("\nCurrent State:")
                    print(f"Beliefs: {len(state.beliefs)} items")
                    print(f"Goals: {len(state.goals)} items")
                    print(f"Knowledge Graph: {len(state.knowledge_graph)} nodes")
                    print(f"Emotions: {state.emotions}")
                    print(f"Attention: {state.attention}")
                else:
                    print("\nNo state found.")
                continue
            
            # Process input and get response
            with monitor.time_conversation_turn():
                result = processor.process_input(user_input)
            
            # Print response
            print(f"\nEcho: {result.response}")
            
            # Increment turn count
            turn_count += 1
            
            # Create checkpoint if needed
            if turn_count % config_manager.get_config().monitoring.checkpoint_interval == 0:
                monitor.create_checkpoint()
            
            # Print debug information if enabled
            if debug_mode:
                print("\nDebug Information:")
                print(f"Turn Count: {turn_count}")
                print(f"Memory Usage: {monitor.metrics.get_memory_usage():.2f}%")
                print(f"Average Response Time: {monitor.metrics.get_avg_response_time():.2f}s")
                print(f"Error Count: {monitor.metrics.get_error_count()}")
                print("\nSubsystem States:")
                for subsystem, state in result.state.context.subsystem_states.items():
                    print(f"{subsystem}: {state}")
        
        except KeyboardInterrupt:
            print("\n\nExiting...")
            break
        except Exception as e:
            monitor.record_error(str(e))
            print(f"\nError: {str(e)}")
            if debug_mode:
                import traceback
                print("\nTraceback:")
                print(traceback.format_exc())

def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description="Run the Echo cognitive agent")
    parser.add_argument("--config", default="config.json", help="Path to configuration file")
    parser.add_argument("--log-dir", default="logs", help="Directory for log files")
    parser.add_argument("--generate-docs", action="store_true", help="Generate configuration documentation")
    args = parser.parse_args()
    
    try:
        # Generate documentation if requested
        if args.generate_docs:
            validator = SchemaValidator(create_echo_schema())
            docs_path = "config_docs.md"
            validator.generate_docs(docs_path)
            print(f"Configuration documentation generated at {docs_path}")
            return
        
        # Set up configuration with migration
        version_manager = ConfigVersionManager(args.config)
        config, migration_log = version_manager.load_and_migrate()
        
        # Print migration log if any migrations occurred
        if migration_log:
            print("Configuration migrations applied:")
            for log in migration_log:
                print(f"- {log}")
        
        # Validate configuration against schema
        validator = SchemaValidator(create_echo_schema())
        validator.validate(config.to_dict())
        
        # Set up configuration manager
        config_manager = ConfigManager(args.config)
        
        # Set up monitoring
        monitor = SystemMonitor(
            log_level=config.monitoring.log_level,
            log_dir=args.log_dir
        )
        
        # Set up input processor
        processor = setup_processor(config_manager)
        
        # Run interactive mode
        run_interactive_mode(processor, monitor, config_manager)
    
    except Exception as e:
        print(f"Error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main() 
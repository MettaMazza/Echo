"""
Core interfaces for the Echo cognitive agent system.
"""
from abc import ABC, abstractmethod
from typing import Any, Dict, Protocol, runtime_checkable

@runtime_checkable
class CognitiveSubsystem(Protocol):
    """Base interface for all cognitive subsystems."""
    
    @abstractmethod
    def update(self, context: Dict[str, Any]) -> None:
        """Update the subsystem's state based on the given context.
        
        Args:
            context: A dictionary containing the current state and context
                    for the cognitive system.
        """
        pass
    
    @abstractmethod
    def get_state(self) -> Dict[str, Any]:
        """Get the current state of the subsystem.
        
        Returns:
            A dictionary containing the subsystem's current state.
        """
        pass

class LLMProvider(Protocol):
    """Interface for LLM providers."""
    
    @abstractmethod
    def generate(self, prompt: str, **kwargs) -> str:
        """Generate a response from the LLM.
        
        Args:
            prompt: The input prompt for the LLM.
            **kwargs: Additional parameters for the LLM.
            
        Returns:
            The generated response as a string.
        """
        pass

class DialogueInterface(Protocol):
    """Interface for user interaction."""
    
    @abstractmethod
    def get_input(self) -> str:
        """Get input from the user.
        
        Returns:
            The user's input as a string.
        """
        pass
    
    @abstractmethod
    def send_output(self, message: str) -> None:
        """Send output to the user.
        
        Args:
            message: The message to send to the user.
        """
        pass 
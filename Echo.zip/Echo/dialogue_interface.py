"""
Dialogue interface for the Echo cognitive agent.
"""
from typing import Optional
from interfaces import DialogueInterface

class ConsoleDialogueInterface(DialogueInterface):
    """Console-based dialogue interface."""
    
    def get_input(self) -> str:
        """Get input from the user via console.
        
        Returns:
            The user's input as a string.
        """
        return input("You: ").strip()
    
    def send_output(self, message: str) -> None:
        """Send output to the user via console.
        
        Args:
            message: The message to send to the user.
        """
        print(f"Echo: {message}")

class VoiceDialogueInterface(DialogueInterface):
    """Voice-based dialogue interface."""
    
    def __init__(self):
        self._import_speech_recognition()
        self._import_pyttsx3()
    
    def _import_speech_recognition(self) -> None:
        """Import speech recognition package and handle import errors."""
        try:
            import speech_recognition as sr
            self.recognizer = sr.Recognizer()
            self.microphone = sr.Microphone()
        except ImportError:
            raise ImportError(
                "SpeechRecognition package not found. Please install it with: "
                "pip install SpeechRecognition pyaudio"
            )
    
    def _import_pyttsx3(self) -> None:
        """Import text-to-speech package and handle import errors."""
        try:
            import pyttsx3
            self.engine = pyttsx3.init()
        except ImportError:
            raise ImportError(
                "pyttsx3 package not found. Please install it with: pip install pyttsx3"
            )
    
    def get_input(self) -> str:
        """Get input from the user via voice.
        
        Returns:
            The user's input as a string.
        """
        print("Listening...")
        with self.microphone as source:
            self.recognizer.adjust_for_ambient_noise(source)
            audio = self.recognizer.listen(source)
        
        try:
            text = self.recognizer.recognize_google(audio)
            print(f"You: {text}")
            return text
        except Exception as e:
            print(f"Error recognizing speech: {str(e)}")
            return ""
    
    def send_output(self, message: str) -> None:
        """Send output to the user via voice.
        
        Args:
            message: The message to send to the user.
        """
        print(f"Echo: {message}")
        self.engine.say(message)
        self.engine.runAndWait()

def create_dialogue_interface(interface_type: str) -> DialogueInterface:
    """Create a dialogue interface instance.
    
    Args:
        interface_type: The type of interface to create ("console" or "voice").
        
    Returns:
        An instance of the specified dialogue interface.
        
    Raises:
        ValueError: If an invalid interface type is specified.
    """
    if interface_type.lower() == "console":
        return ConsoleDialogueInterface()
    elif interface_type.lower() == "voice":
        return VoiceDialogueInterface()
    else:
        raise ValueError(f"Invalid interface type: {interface_type}") 
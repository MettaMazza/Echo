# Echo Cognitive Agent Deployment Guide

This guide provides instructions for deploying the Echo cognitive agent in a production environment.

## Prerequisites

- Python 3.9 or higher
- Docker (optional, for containerized deployment)
- Prometheus (for metrics collection)
- Grafana (for metrics visualization)
- A supported LLM API key (e.g., OpenAI, Anthropic)

## Installation

### 1. Clone the Repository

```bash
git clone https://github.com/your-org/echo.git
cd echo
```

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

### 3. Configure Environment

Create a `.env` file with the following variables:

```env
LLM_API_KEY=your_api_key
LLM_API_BASE=https://api.openai.com/v1
LOG_LEVEL=INFO
METRICS_PORT=9090
ALERT_WEBHOOK=https://your-alert-webhook.com
```

## Deployment Options

### Option 1: Direct Deployment

1. Start the agent:

```bash
python echo.py --config config.json --log-dir logs
```

2. Monitor the agent:

```bash
# View logs
tail -f logs/echo.log

# View metrics
curl localhost:9090/metrics
```

### Option 2: Docker Deployment

1. Build the Docker image:

```bash
docker build -t echo-agent .
```

2. Run the container:

```bash
docker run -d \
  --name echo-agent \
  -p 9090:9090 \
  -v $(pwd)/config.json:/app/config.json \
  -v $(pwd)/logs:/app/logs \
  -v $(pwd)/state:/app/state \
  -v $(pwd)/memory:/app/memory \
  --env-file .env \
  echo-agent
```

## Monitoring Setup

### 1. Prometheus Configuration

Add the following to your `prometheus.yml`:

```yaml
scrape_configs:
  - job_name: 'echo'
    static_configs:
      - targets: ['localhost:9090']
```

### 2. Grafana Dashboard

Import the provided dashboard configuration:

```bash
curl -X POST \
  -H "Content-Type: application/json" \
  -d @grafana-dashboard.json \
  http://localhost:3000/api/dashboards/db
```

## Scaling

### Horizontal Scaling

1. Deploy multiple instances behind a load balancer:

```bash
# Example with Docker Swarm
docker stack deploy -c docker-compose.yml echo
```

2. Configure shared storage for state and memory:

```yaml
# docker-compose.yml
version: '3.8'
services:
  echo:
    image: echo-agent
    deploy:
      replicas: 3
    volumes:
      - shared-state:/app/state
      - shared-memory:/app/memory
volumes:
  shared-state:
  shared-memory:
```

### Vertical Scaling

1. Adjust resource limits:

```bash
# Docker
docker run -d \
  --name echo-agent \
  --memory=4g \
  --cpus=2 \
  echo-agent
```

2. Configure subsystem parameters in `config.json`:

```json
{
  "memory": {
    "page_size": 100,
    "max_workers": 8
  },
  "monitoring": {
    "checkpoint_interval": 100
  }
}
```

## Backup and Restore

### Backup

1. Create a backup script:

```bash
#!/bin/bash
BACKUP_DIR="backups/$(date +%Y%m%d_%H%M%S)"
mkdir -p $BACKUP_DIR

# Backup state
cp -r state/* $BACKUP_DIR/state/

# Backup memory
cp -r memory/* $BACKUP_DIR/memory/

# Backup logs
cp -r logs/* $BACKUP_DIR/logs/

# Backup configuration
cp config.json $BACKUP_DIR/
```

2. Schedule regular backups:

```bash
# Add to crontab
0 0 * * * /path/to/backup.sh
```

### Restore

1. Stop the agent:

```bash
docker stop echo-agent
```

2. Restore from backup:

```bash
#!/bin/bash
BACKUP_DIR=$1

# Restore state
cp -r $BACKUP_DIR/state/* state/

# Restore memory
cp -r $BACKUP_DIR/memory/* memory/

# Restore configuration
cp $BACKUP_DIR/config.json .
```

3. Start the agent:

```bash
docker start echo-agent
```

## Troubleshooting

### Common Issues

1. **High Memory Usage**
   - Check memory usage: `docker stats echo-agent`
   - Adjust memory limits in Docker configuration
   - Review memory-intensive operations in logs

2. **Slow Response Times**
   - Check LLM API latency
   - Monitor subsystem health in Grafana
   - Adjust worker pool size in configuration

3. **State/Memory Corruption**
   - Restore from latest backup
   - Check disk space: `df -h`
   - Verify file permissions

### Log Analysis

1. View error logs:

```bash
grep ERROR logs/echo.log
```

2. Analyze performance:

```bash
# Average response time
grep "response_time" logs/echo.log | awk '{sum+=$2} END {print sum/NR}'
```

## Security Considerations

1. **API Key Security**
   - Store API keys in environment variables
   - Rotate keys regularly
   - Use key management service

2. **Network Security**
   - Use HTTPS for all API calls
   - Implement rate limiting
   - Configure firewall rules

3. **Data Security**
   - Encrypt sensitive data
   - Implement access controls
   - Regular security audits

## Maintenance

### Regular Tasks

1. **Daily**
   - Monitor system health
   - Check error logs
   - Verify backup completion

2. **Weekly**
   - Review performance metrics
   - Clean up old logs
   - Update dependencies

3. **Monthly**
   - Security updates
   - Configuration review
   - Capacity planning

### Update Procedure

1. Pull latest changes:

```bash
git pull origin main
```

2. Update dependencies:

```bash
pip install -r requirements.txt
```

3. Restart services:

```bash
docker-compose down
docker-compose up -d
```

## Support

For support, please:

1. Check the troubleshooting guide
2. Review the logs
3. Contact the development team
4. Submit an issue on GitHub

## License

This project is licensed under the MIT License - see the LICENSE file for details. 
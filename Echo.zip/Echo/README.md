# Echo - A Modular Cognitive Agent System

Echo is a modular, extensible, and testable cognitive agent system that simulates an artificial general intelligence. It is built using modern Python best practices and follows a clean architecture pattern.

## Features

- Modular cognitive subsystems (emotion, memory, belief)
- Extensible design allowing easy addition of new subsystems
- Support for multiple LLM providers (Ollama, HuggingFace)
- Multiple interface options (console, voice)
- Comprehensive test suite
- Clean dependency injection using ServiceLocator pattern

## Architecture

The system is organized into several key components:

- `interfaces.py`: Core interfaces for all subsystems
- `service_locator.py`: Dependency injection container
- `prompt_builder.py`: Dynamic prompt construction
- `unified_agent.py`: Main orchestrator
- `bootstrap.py`: System initialization
- `dialogue_interface.py`: User interaction layer
- `llm_integration.py`: LLM provider abstractions
- `core/`: Cognitive subsystem implementations
- `tests/`: Unit and integration tests

## Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/echo.git
cd echo
```

2. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

## Usage

### Basic Usage

```python
from bootstrap import bootstrap_agent, create_default_config

# Create agent with default configuration
config = create_default_config()
agent = bootstrap_agent(config)

# Run interaction loop
while True:
    agent.run_step()
```

### Custom Configuration

```python
config = {
    "llm_provider": "huggingface",
    "llm_config": {
        "model_name": "gpt2"
    },
    "dialogue_interface": "voice",
    "max_memories": 200
}
agent = bootstrap_agent(config)
```

### Running Tests

```bash
pytest tests/
```

## Adding New Subsystems

To add a new cognitive subsystem:

1. Create a new class in the `core/` directory
2. Implement the `CognitiveSubsystem` interface
3. Register the subsystem in `bootstrap.py`

Example:
```python
from interfaces import CognitiveSubsystem

class NewSubsystem(CognitiveSubsystem):
    def update(self, context: dict) -> None:
        # Update logic here
        pass
    
    def get_state(self) -> dict:
        # Return state here
        return {}
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details. 
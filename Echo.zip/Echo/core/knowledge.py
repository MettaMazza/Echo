"""
Knowledge system for Echo cognitive agent.
"""
from typing import Dict, Any, List, Optional, Set
from dataclasses import dataclass, field
from datetime import datetime
import json
from core.interfaces import CognitiveSubsystem

@dataclass
class Knowledge:
    """Knowledge item."""
    id: str
    content: str
    source: str
    confidence: float
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    tags: Set[str] = field(default_factory=set)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary.
        
        Returns:
            Dictionary representation
        """
        return {
            'id': self.id,
            'content': self.content,
            'source': self.source,
            'confidence': self.confidence,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'tags': list(self.tags),
            'metadata': self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Knowledge':
        """Create from dictionary.
        
        Args:
            data: Dictionary representation
            
        Returns:
            Knowledge instance
        """
        return cls(
            id=data['id'],
            content=data['content'],
            source=data['source'],
            confidence=data['confidence'],
            created_at=datetime.fromisoformat(data['created_at']),
            updated_at=datetime.fromisoformat(data['updated_at']),
            tags=set(data['tags']),
            metadata=data['metadata']
        )

class KnowledgeSystem(CognitiveSubsystem):
    """System for managing knowledge."""
    
    def __init__(self):
        """Initialize knowledge system."""
        self._knowledge: Dict[str, Knowledge] = {}
        self._tag_index: Dict[str, Set[str]] = {}
    
    def add_knowledge(self, knowledge: Knowledge) -> None:
        """Add knowledge item.
        
        Args:
            knowledge: Knowledge item to add
        """
        self._knowledge[knowledge.id] = knowledge
        for tag in knowledge.tags:
            if tag not in self._tag_index:
                self._tag_index[tag] = set()
            self._tag_index[tag].add(knowledge.id)
    
    def get_knowledge(self, knowledge_id: str) -> Optional[Knowledge]:
        """Get knowledge item by ID.
        
        Args:
            knowledge_id: Knowledge item ID
            
        Returns:
            Knowledge item if found, None otherwise
        """
        return self._knowledge.get(knowledge_id)
    
    def get_knowledge_by_tag(self, tag: str) -> List[Knowledge]:
        """Get knowledge items by tag.
        
        Args:
            tag: Tag to search for
            
        Returns:
            List of knowledge items with the tag
        """
        if tag not in self._tag_index:
            return []
        return [self._knowledge[kid] for kid in self._tag_index[tag]]
    
    def update_knowledge(self, knowledge: Knowledge) -> None:
        """Update knowledge item.
        
        Args:
            knowledge: Updated knowledge item
        """
        if knowledge.id not in self._knowledge:
            raise ValueError(f"Knowledge item {knowledge.id} not found")
        
        # Remove old tags from index
        old_knowledge = self._knowledge[knowledge.id]
        for tag in old_knowledge.tags:
            self._tag_index[tag].remove(knowledge.id)
            if not self._tag_index[tag]:
                del self._tag_index[tag]
        
        # Add new knowledge and update tag index
        self.add_knowledge(knowledge)
    
    def delete_knowledge(self, knowledge_id: str) -> None:
        """Delete knowledge item.
        
        Args:
            knowledge_id: Knowledge item ID
        """
        if knowledge_id not in self._knowledge:
            raise ValueError(f"Knowledge item {knowledge_id} not found")
        
        # Remove from tag index
        knowledge = self._knowledge[knowledge_id]
        for tag in knowledge.tags:
            self._tag_index[tag].remove(knowledge_id)
            if not self._tag_index[tag]:
                del self._tag_index[tag]
        
        # Remove knowledge item
        del self._knowledge[knowledge_id]
    
    def update(self, context: Dict[str, Any]) -> None:
        """Update knowledge system based on context.
        
        Args:
            context: Current context
        """
        # Update knowledge based on context
        if 'new_knowledge' in context:
            for knowledge_data in context['new_knowledge']:
                knowledge = Knowledge.from_dict(knowledge_data)
                self.add_knowledge(knowledge)
    
    def get_state(self) -> Dict[str, Any]:
        """Get current state.
        
        Returns:
            Current state
        """
        return {
            'knowledge_count': len(self._knowledge),
            'tag_count': len(self._tag_index),
            'knowledge_items': [k.to_dict() for k in self._knowledge.values()]
        }
    
    def save(self, filepath: str) -> None:
        """Save knowledge system to file.
        
        Args:
            filepath: Path to save file
        """
        with open(filepath, 'w') as f:
            json.dump({
                'knowledge': [k.to_dict() for k in self._knowledge.values()],
                'tag_index': {tag: list(ids) for tag, ids in self._tag_index.items()}
            }, f, indent=2)
    
    @classmethod
    def load(cls, filepath: str) -> 'KnowledgeSystem':
        """Load knowledge system from file.
        
        Args:
            filepath: Path to load file
            
        Returns:
            Loaded knowledge system
        """
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        system = cls()
        for knowledge_data in data['knowledge']:
            knowledge = Knowledge.from_dict(knowledge_data)
            system.add_knowledge(knowledge)
        
        return system

class KnowledgeGraph:
    """Minimal placeholder for KnowledgeGraph."""
    def __init__(self):
        self.nodes = set()
        self.edges = dict()
    def add_node(self, node):
        self.nodes.add(node)
    def add_edge(self, src, dst):
        if src not in self.edges:
            self.edges[src] = set()
        self.edges[src].add(dst) 
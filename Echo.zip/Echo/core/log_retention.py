"""
Log retention and archival system for Echo cognitive agent.
"""
import gzip
import shutil
from datetime import datetime, timedelta
from pathlib import Path
import asyncio
import structlog
from typing import Optional

logger = structlog.get_logger(__name__)

class LogRetentionManager:
    """Manages log retention, rotation, and archival."""
    
    def __init__(
        self,
        log_dir: str,
        retention_days: int = 30,
        archive_dir: str = "logs/archive",
        max_log_size_mb: int = 100,
        cleanup_interval_hours: int = 24
    ):
        """Initialize log retention manager."""
        self.log_dir = Path(log_dir)
        self.archive_dir = Path(archive_dir)
        self.retention_days = retention_days
        self.max_log_size_mb = max_log_size_mb
        self.cleanup_interval_hours = cleanup_interval_hours
        
        # Create directories
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.archive_dir.mkdir(parents=True, exist_ok=True)
        
        # Start cleanup task
        self._cleanup_task: Optional[asyncio.Task] = None
        
        logger.info("log_retention_initialized",
            log_dir=str(log_dir),
            archive_dir=str(archive_dir),
            retention_days=retention_days,
            max_log_size_mb=max_log_size_mb
        )
    
    async def start(self):
        """Start the log retention manager."""
        self._cleanup_task = asyncio.create_task(self._cleanup_loop())
        logger.info("log_retention_started")
    
    async def stop(self):
        """Stop the log retention manager."""
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass
        logger.info("log_retention_stopped")
    
    async def _cleanup_loop(self):
        """Periodic cleanup loop."""
        while True:
            try:
                await self.cleanup_old_logs()
                await self.enforce_size_limits()
                await asyncio.sleep(self.cleanup_interval_hours * 3600)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error("cleanup_loop_error",
                    error=str(e)
                )
                await asyncio.sleep(300)  # Wait 5 minutes before retrying
    
    async def cleanup_old_logs(self):
        """Remove logs older than retention period."""
        current_time = datetime.now()
        for log_file in self.log_dir.glob("*.log"):
            try:
                file_age = current_time - datetime.fromtimestamp(log_file.stat().st_mtime)
                if file_age.days > self.retention_days:
                    await self._archive_log(log_file)
                    log_file.unlink()
                    logger.info("log_archived_and_removed",
                        file=str(log_file),
                        age_days=file_age.days
                    )
            except Exception as e:
                logger.error("log_cleanup_error",
                    file=str(log_file),
                    error=str(e)
                )
    
    async def _archive_log(self, log_file: Path):
        """Archive log file before deletion."""
        try:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            archive_path = self.archive_dir / f"{log_file.stem}_{timestamp}.gz"
            
            # Compress and archive
            with open(log_file, 'rb') as f_in:
                with gzip.open(archive_path, 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
            
            logger.info("log_archived",
                file=str(log_file),
                archive=str(archive_path)
            )
        except Exception as e:
            logger.error("log_archive_error",
                file=str(log_file),
                error=str(e)
            )
            raise
    
    async def enforce_size_limits(self):
        """Enforce maximum log size limits."""
        for log_file in self.log_dir.glob("*.log"):
            try:
                if log_file.stat().st_size > self.max_log_size_mb * 1024 * 1024:
                    await self._rotate_log(log_file)
            except Exception as e:
                logger.error("size_limit_enforcement_error",
                    file=str(log_file),
                    error=str(e)
                )
    
    async def _rotate_log(self, log_file: Path):
        """Rotate log file when size limit is reached."""
        try:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            rotated_path = log_file.parent / f"{log_file.stem}_{timestamp}.log"
            
            # Rotate the log file
            log_file.rename(rotated_path)
            
            # Create new empty log file
            log_file.touch()
            
            # Archive the rotated file
            await self._archive_log(rotated_path)
            
            logger.info("log_rotated",
                file=str(log_file),
                rotated=str(rotated_path)
            )
        except Exception as e:
            logger.error("log_rotation_error",
                file=str(log_file),
                error=str(e)
            )
            raise
    
    async def cleanup_archives(self, max_archive_age_days: int = 365):
        """Clean up old archived logs."""
        current_time = datetime.now()
        for archive_file in self.archive_dir.glob("*.gz"):
            try:
                file_age = current_time - datetime.fromtimestamp(archive_file.stat().st_mtime)
                if file_age.days > max_archive_age_days:
                    archive_file.unlink()
                    logger.info("archive_removed",
                        file=str(archive_file),
                        age_days=file_age.days
                    )
            except Exception as e:
                logger.error("archive_cleanup_error",
                    file=str(archive_file),
                    error=str(e)
                ) 
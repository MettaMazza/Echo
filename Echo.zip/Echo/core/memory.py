"""
Memory system for Echo cognitive agent.
"""
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
import json
from pathlib import Path
import asyncio
import aiofiles
import structlog
from core.context import State
import math
import os

logger = structlog.get_logger(__name__)

@dataclass
class Memory:
    """Memory data class."""
    content: str
    memory_type: str = "short-term"
    importance: float = 0.5
    emotional_valence: float = 0.0
    confidence: float = 1.0
    created_at: datetime = None
    last_accessed: datetime = None
    access_count: int = 0
    timestamp: datetime = None
    associations: list = None
    context: dict = None
    
    def __post_init__(self):
        """Initialize timestamps."""
        if self.created_at is None:
            self.created_at = datetime.now()
        if self.last_accessed is None:
            self.last_accessed = self.created_at
        if self.timestamp is None:
            self.timestamp = self.created_at
        if self.associations is None:
            self.associations = []
        if self.context is None:
            self.context = {}
    
    def to_dict(self) -> dict:
        """Convert memory to dictionary."""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: dict) -> 'Memory':
        """Create memory from dictionary."""
        return cls(**data)

    def add_association(self, assoc):
        if assoc not in self.associations:
            self.associations.append(assoc)

    def update_importance(self, value):
        self.importance = max(0.0, min(1.0, value))

    def update_emotional_valence(self, value):
        self.emotional_valence = max(-1.0, min(1.0, value))

    def update_confidence(self, value):
        self.confidence = max(0.0, min(1.0, value))

    def access(self):
        self.access_count += 1
        self.last_accessed = datetime.now()

class MemorySystem:
    """Memory system for storing and retrieving memories."""
    
    def __init__(self, storage_dir: str = "data/memories"):
        """Initialize memory system."""
        self.storage_dir = Path(storage_dir)
        self._max_memories = 1000
        self._memories: Dict[str, Memory] = {}
        self._short_term: Dict[str, Memory] = {}
        self._long_term: Dict[str, Memory] = {}
        self._working: Dict[str, Memory] = {}
        self._memory_history = []
        self._initialized = False
    
    async def initialize(self, config: dict = None):
        """Initialize the memory system asynchronously with config validation."""
        if config:
            if "max_memories" in config:
                if not isinstance(config["max_memories"], int) or config["max_memories"] <= 0:
                    raise ValueError("max_memories must be a positive integer")
                self._max_memories = config["max_memories"]
            if "storage_dir" in config:
                if not isinstance(config["storage_dir"], str) or not config["storage_dir"]:
                    raise ValueError("storage_dir must be a non-empty string")
                self.storage_dir = Path(config["storage_dir"])
        if not isinstance(self._max_memories, int) or self._max_memories <= 0:
            raise ValueError("max_memories must be a positive integer")
        if not isinstance(self.storage_dir, Path) or not str(self.storage_dir):
            raise ValueError("storage_dir must be a valid path")
        if not self._initialized:
            self._initialized = True
            logger.info("memory_system_initialized")
    
    def _update_memory_dict(self):
        """Update memory dictionary from memory lists."""
        self._memories = {}
        self._memories.update(self._short_term)
        self._memories.update(self._long_term)
        self._memories.update(self._working)
    
    async def store_memory(self, content: str, importance: float = 1.0, context: dict = None) -> bool:
        """Store a new memory."""
        try:
            memory = Memory(
                content=content,
                timestamp=datetime.now(),
                importance=importance,
                context=context or {}
            )
            
            await self._add_memory(memory)
            logger.info(f"stored_memory: {content[:50]}...")
            return True
        except Exception as e:
            logger.error(f"error_storing_memory: {e}")
            return False
    
    async def retrieve_memories(self, query: str = None, limit: int = 10) -> list:
        """Retrieve memories matching query."""
        try:
            if not query:
                return list(self._memories.values())[-limit:]
            
            # Simple keyword matching for now
            matches = []
            for memory in self._memories.values():
                if query.lower() in memory.content.lower():
                    matches.append(memory)
            
            return matches[-limit:]
        except Exception as e:
            logger.error(f"error_retrieving_memories: {e}")
            return []
    
    async def get_state(self) -> dict:
        """Get current state of the memory system."""
        return {
            "memories": [m.to_dict() for m in self._memories.values()],
            "working_memory": [m.to_dict() for m in self._working.values()],
            "short_term_memory": [m.to_dict() for m in self._short_term.values()],
            "long_term_memory": [m.to_dict() for m in self._long_term.values()],
            "total_memories": len(self._memories),
            "max_memories": self._max_memories,
            "last_update": datetime.now().isoformat()
        }
    
    async def get_metrics(self) -> dict:
        """Get memory system metrics."""
        return {
            "total_memories": len(self._memories),
            "working_memories": len(self._working),
            "short_term_memories": len(self._short_term),
            "long_term_memories": len(self._long_term),
            "memory_operations": sum(m.access_count for m in self._memories.values())
        }
    
    async def update(self, context: dict) -> None:
        """Update memory system with new context."""
        try:
            if "user_input" in context:
                await self._process_user_input(context["user_input"])
            if "goals" in context:
                await self._process_goals(context["goals"])
            await self._update_memory_states()
        except Exception as e:
            logger.error(f"error_updating_memory_system: {e}")
    
    async def _update_memory_states(self) -> None:
        """Update memory states."""
        # Update memory states
        for memory in self._memories.values():
            # Update importance based on access count
            memory.importance = min(1.0, 0.5 + memory.access_count * 0.1)
            
            # Update confidence based on age
            age_days = (datetime.now() - memory.created_at).days
            memory.confidence = max(0.5, 1.0 - age_days * 0.1)
    
    async def _prune_memories(self) -> None:
        """Prune old and less important memories."""
        # Sort memories by importance and last accessed
        all_memories = list(self._memories.values())
        all_memories.sort(key=lambda m: (m.importance, m.last_accessed))
        
        # Remove oldest and least important memories
        while len(all_memories) >= self._max_memories:
            memory = all_memories.pop(0)
            del self._memories[memory.content]
            if memory.content in self._working:
                del self._working[memory.content]
            if memory.content in self._short_term:
                del self._short_term[memory.content]
            if memory.content in self._long_term:
                del self._long_term[memory.content]

    async def process_input(self, input_text: str, state: State) -> Dict[str, Any]:
        """Process input and update memory asynchronously."""
        try:
            # Create new memory
            memory = Memory(
                content=input_text,
                memory_type="user_input"
            )
            
            # Process in parallel
            await asyncio.gather(
                self._store_working_memory(memory),
                self._update_short_term_memory(memory),
                self._update_long_term_memory(memory)
            )
            
            return {"status": "success", "memory_id": memory.content}
        except Exception as e:
            logger.error(f"Error processing input: {e}")
            return {"status": "error", "error": str(e)}

    async def _store_working_memory(self, memory: Memory) -> None:
        """Store memory in working memory."""
        self._working[memory.content] = memory
        self._memories[memory.content] = memory

    async def _update_short_term_memory(self, memory: Memory) -> None:
        """Update short-term memory."""
        self._short_term[memory.content] = memory

    async def _update_long_term_memory(self, memory: Memory) -> None:
        """Update long-term memory."""
        self._long_term[memory.content] = memory

    async def get_recent_memories(self, hours: float = 1.0) -> List[Memory]:
        """Get memories from the last N hours."""
        cutoff = datetime.now() - timedelta(hours=hours)
        return [m for m in self._memories.values() if m.created_at > cutoff]

    async def update_memory(self, content: str, importance: float) -> None:
        """Update memory importance."""
        if content in self._memories:
            memory = self._memories[content]
            memory.update_importance(importance)
            memory.access()

    async def _add_memory(self, memory: Memory) -> None:
        """Add memory to appropriate stores."""
        # Add to working memory
        self._working[memory.content] = memory
        self._memories[memory.content] = memory
        
        # Add to memory history
        self._memory_history.append(memory)
        
        # Check for memory overflow
        if len(self._memories) >= self._max_memories:
            await self._prune_memories()

    async def _process_user_input(self, input_text: str) -> Dict[str, Any]:
        """Process user input and create memory."""
        try:
            memory = Memory(
                content=input_text,
                memory_type="user_input",
                importance=0.7  # Default importance for user input
            )
            await self._add_memory(memory)
            return {"status": "success", "memory_id": memory.content}
        except Exception as e:
            logger.error(f"Error processing user input: {e}")
            return {"status": "error", "error": str(e)}

    async def _process_goals(self, goals: List[Dict[str, Any]]) -> None:
        """Process goals and create goal memories."""
        for goal in goals:
            try:
                memory = Memory(
                    content=goal.get("description", ""),
                    memory_type="goal",
                    importance=goal.get("priority", 0.5),
                    context={"goal_id": goal.get("id"), "status": goal.get("status")}
                )
                await self._add_memory(memory)
            except Exception as e:
                logger.error(f"Error processing goal: {e}")

    async def save_state(self) -> bool:
        """Save memory system state to disk."""
        try:
            state = await self.get_state()
            os.makedirs(self.storage_dir, exist_ok=True)
            async with aiofiles.open(self.storage_dir / "memory_state.json", "w") as f:
                await f.write(json.dumps(state, default=str))
            return True
        except Exception as e:
            logger.error(f"Error saving memory state: {e}")
            return False

    async def load_state(self) -> bool:
        """Load memory system state from disk."""
        try:
            state_file = self.storage_dir / "memory_state.json"
            if not state_file.exists():
                return False
            
            async with aiofiles.open(state_file, "r") as f:
                state = json.loads(await f.read())
            
            # Clear existing memories
            self._memories.clear()
            self._working.clear()
            self._short_term.clear()
            self._long_term.clear()
            
            # Load memories
            for memory_data in state.get("memories", []):
                memory = Memory.from_dict(memory_data)
                self._memories[memory.content] = memory
            
            # Update memory stores
            self._update_memory_dict()
            return True
        except Exception as e:
            logger.error(f"Error loading memory state: {e}")
            return False

    async def find_related_memories(self, query: str, limit: int = 5) -> List[Memory]:
        """Find memories related to the query."""
        try:
            # Simple keyword matching for now
            matches = []
            for memory in self._memories.values():
                if query.lower() in memory.content.lower():
                    matches.append(memory)
            
            # Sort by relevance (importance * confidence)
            matches.sort(key=lambda m: m.importance * m.confidence, reverse=True)
            return matches[:limit]
        except Exception as e:
            logger.error(f"Error finding related memories: {e}")
            return []

    async def get_memory_by_type(self, memory_type: str) -> List[Memory]:
        """Get memories of a specific type."""
        return [m for m in self._memories.values() if m.memory_type == memory_type]

    async def _consolidate_memories(self) -> None:
        """Consolidate memories based on importance and recency."""
        # Move important memories to long-term storage
        for memory in list(self._short_term.values()):
            if memory.importance > 0.8 and memory.access_count > 5:
                self._long_term[memory.content] = memory
                del self._short_term[memory.content]
        
        # Update memory dictionary
        self._update_memory_dict() 
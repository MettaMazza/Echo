"""
Configuration migration system for Echo cognitive agent.
"""
from typing import Dict, Any, Optional, List, Tuple
from dataclasses import dataclass
from datetime import datetime
import json
import os
from pathlib import Path
from core.config import EchoConfig, ValidationError

@dataclass
class MigrationStep:
    """Represents a single configuration migration step."""
    version: str
    description: str
    migration_func: callable

class ConfigMigrationManager:
    """Manages configuration migrations between versions."""
    
    def __init__(self, config_dir: str = "config"):
        """Initialize migration manager."""
        self.config_dir = Path(config_dir)
        self.migrations: List[MigrationStep] = []
        self._register_migrations()
    
    def _register_migrations(self):
        """Register all available migrations."""
        # Version 1.0 to 1.1: Add monitoring configuration
        self.migrations.append(MigrationStep(
            version="1.1",
            description="Add monitoring configuration",
            migration_func=self._migrate_to_1_1
        ))
        
        # Version 1.1 to 1.2: Add learning rate to learning config
        self.migrations.append(MigrationStep(
            version="1.2",
            description="Add learning rate to learning configuration",
            migration_func=self._migrate_to_1_2
        ))
        
        # Version 1.2 to 1.3: Add emotion intensity range
        self.migrations.append(MigrationStep(
            version="1.3",
            description="Add emotion intensity range configuration",
            migration_func=self._migrate_to_1_3
        ))
    
    def _migrate_to_1_1(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Migrate configuration to version 1.1."""
        if 'monitoring' not in config:
            config['monitoring'] = {
                'log_level': 'INFO',
                'log_dir': 'logs',
                'checkpoint_interval': 10,
                'metrics_retention': 1000,
                'health_check_interval': 60
            }
        return config
    
    def _migrate_to_1_2(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Migrate configuration to version 1.2."""
        if 'learning' in config:
            if 'learning_rate' not in config['learning']:
                config['learning']['learning_rate'] = 0.1
        return config
    
    def _migrate_to_1_3(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Migrate configuration to version 1.3."""
        if 'emotion' in config:
            if 'max_emotion_intensity' not in config['emotion']:
                config['emotion']['max_emotion_intensity'] = 1.0
            if 'min_emotion_intensity' not in config['emotion']:
                config['emotion']['min_emotion_intensity'] = 0.1
        return config
    
    def get_current_version(self, config: Dict[str, Any]) -> str:
        """Get the current version of the configuration."""
        return config.get('version', '1.0')
    
    def get_latest_version(self) -> str:
        """Get the latest configuration version."""
        return self.migrations[-1].version if self.migrations else '1.0'
    
    def get_migration_path(self, current_version: str) -> List[MigrationStep]:
        """Get the list of migrations needed to reach the latest version."""
        migrations_needed = []
        for migration in self.migrations:
            if migration.version > current_version:
                migrations_needed.append(migration)
        return migrations_needed
    
    def migrate_config(self, config: Dict[str, Any]) -> Tuple[Dict[str, Any], List[str]]:
        """Migrate configuration to the latest version."""
        current_version = self.get_current_version(config)
        latest_version = self.get_latest_version()
        
        if current_version == latest_version:
            return config, []
        
        migrations_needed = self.get_migration_path(current_version)
        if not migrations_needed:
            return config, []
        
        # Create backup of original config
        backup_path = self._create_backup(config, current_version)
        
        # Apply migrations
        migration_log = []
        for migration in migrations_needed:
            try:
                config = migration.migration_func(config)
                config['version'] = migration.version
                migration_log.append(f"Migrated to version {migration.version}: {migration.description}")
            except Exception as e:
                # Restore from backup if migration fails
                self._restore_from_backup(backup_path)
                raise ValidationError(f"Migration to version {migration.version} failed: {str(e)}")
        
        return config, migration_log
    
    def _create_backup(self, config: Dict[str, Any], version: str) -> Path:
        """Create a backup of the configuration."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_dir = self.config_dir / "backups"
        backup_dir.mkdir(parents=True, exist_ok=True)
        
        backup_path = backup_dir / f"config_v{version}_{timestamp}.json"
        with open(backup_path, 'w') as f:
            json.dump(config, f, indent=2)
        
        return backup_path
    
    def _restore_from_backup(self, backup_path: Path):
        """Restore configuration from backup."""
        if backup_path.exists():
            with open(backup_path, 'r') as f:
                return json.load(f)
        return None

class ConfigVersionManager:
    """Manages configuration versioning and migrations."""
    
    def __init__(self, config_path: str, migration_manager: Optional[ConfigMigrationManager] = None):
        """Initialize version manager."""
        self.config_path = Path(config_path)
        self.migration_manager = migration_manager or ConfigMigrationManager()
    
    def load_and_migrate(self) -> Tuple[EchoConfig, List[str]]:
        """Load configuration and migrate if necessary."""
        if not self.config_path.exists():
            return EchoConfig(), []
        
        with open(self.config_path, 'r') as f:
            config_dict = json.load(f)
        
        # Migrate configuration if needed
        migrated_config, migration_log = self.migration_manager.migrate_config(config_dict)
        
        # Convert to EchoConfig
        try:
            config = EchoConfig.from_dict(migrated_config)
        except ValidationError as e:
            raise ValidationError(f"Invalid configuration after migration: {str(e)}")
        
        # Save migrated configuration
        if migration_log:
            self._save_migrated_config(migrated_config)
        
        return config, migration_log
    
    def _save_migrated_config(self, config_dict: Dict[str, Any]):
        """Save migrated configuration."""
        with open(self.config_path, 'w') as f:
            json.dump(config_dict, f, indent=2) 
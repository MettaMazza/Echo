"""
Context and state management for Echo cognitive agent.
"""
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List
from datetime import datetime
import json
from pathlib import Path

@dataclass
class Context:
    """Represents the current context of a conversation."""
    input_text: str
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)
    subsystem_states: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert context to dictionary."""
        return {
            "input_text": self.input_text,
            "timestamp": self.timestamp.isoformat(),
            "metadata": self.metadata,
            "subsystem_states": self.subsystem_states
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Context':
        """Create context from dictionary."""
        return cls(
            input_text=data["input_text"],
            timestamp=datetime.fromisoformat(data["timestamp"]),
            metadata=data["metadata"],
            subsystem_states=data["subsystem_states"]
        )

@dataclass
class State:
    """Represents the aggregated state of all subsystems."""
    context: Context
    beliefs: Dict[str, Any] = field(default_factory=dict)
    goals: List[Dict[str, Any]] = field(default_factory=list)
    knowledge_graph: Dict[str, Any] = field(default_factory=dict)
    emotions: Dict[str, float] = field(default_factory=dict)
    attention: Dict[str, float] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert state to dictionary."""
        return {
            "context": self.context.to_dict(),
            "beliefs": self.beliefs,
            "goals": self.goals,
            "knowledge_graph": self.knowledge_graph,
            "emotions": self.emotions,
            "attention": self.attention
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'State':
        """Create state from dictionary."""
        return cls(
            context=Context.from_dict(data["context"]),
            beliefs=data["beliefs"],
            goals=data["goals"],
            knowledge_graph=data["knowledge_graph"],
            emotions=data["emotions"],
            attention=data["attention"]
        )

class StateManager:
    """Manages state persistence and updates."""
    
    def __init__(self, storage_dir: str = "state"):
        """Initialize state manager."""
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(exist_ok=True)
        
        # Create subdirectories
        (self.storage_dir / "beliefs").mkdir(exist_ok=True)
        (self.storage_dir / "goals").mkdir(exist_ok=True)
        (self.storage_dir / "knowledge").mkdir(exist_ok=True)
    
    def save_state(self, state: State) -> None:
        """Save state to persistent storage."""
        # Save beliefs
        beliefs_file = self.storage_dir / "beliefs" / "current.json"
        with open(beliefs_file, 'w') as f:
            json.dump(state.beliefs, f, indent=2)
        
        # Save goals
        goals_file = self.storage_dir / "goals" / "current.json"
        with open(goals_file, 'w') as f:
            json.dump(state.goals, f, indent=2)
        
        # Save knowledge graph
        knowledge_file = self.storage_dir / "knowledge" / "current.json"
        with open(knowledge_file, 'w') as f:
            json.dump(state.knowledge_graph, f, indent=2)
        
        # Save full state for history
        timestamp = state.context.timestamp.strftime("%Y%m%d_%H%M%S")
        history_file = self.storage_dir / f"state_{timestamp}.json"
        with open(history_file, 'w') as f:
            json.dump(state.to_dict(), f, indent=2)
    
    def load_state(self) -> Optional[State]:
        """Load state from persistent storage."""
        try:
            # Load beliefs
            beliefs_file = self.storage_dir / "beliefs" / "current.json"
            with open(beliefs_file, 'r') as f:
                beliefs = json.load(f)
            
            # Load goals
            goals_file = self.storage_dir / "goals" / "current.json"
            with open(goals_file, 'r') as f:
                goals = json.load(f)
            
            # Load knowledge graph
            knowledge_file = self.storage_dir / "knowledge" / "current.json"
            with open(knowledge_file, 'r') as f:
                knowledge_graph = json.load(f)
            
            # Create empty context for loading
            context = Context(input_text="")
            
            # Create and return state
            return State(
                context=context,
                beliefs=beliefs,
                goals=goals,
                knowledge_graph=knowledge_graph
            )
        
        except FileNotFoundError:
            return None
    
    def update_subsystem_state(self, state: State, subsystem: str, data: Dict[str, Any]) -> State:
        """Update a subsystem's state."""
        state.context.subsystem_states[subsystem] = data
        return state 
"""
Main agent class for Echo cognitive system.
"""
import asyncio
from typing import Dict, List, Optional
from datetime import datetime
import structlog

from .memory import MemorySystem
from .monitoring import MonitoringSystem
from .emotion import EmotionSystem
from .attention import AttentionSystem
from .learning import LearningSystem
from .knowledge import KnowledgeSystem
from .planning import PlanningSystem
from .decision import DecisionSystem
from .processor import InputProcessor

logger = structlog.get_logger(__name__)

class Agent:
    """Main agent class that coordinates all cognitive systems."""
    
    def __init__(self):
        """Initialize the agent and all its subsystems."""
        # Initialize subsystems
        self.memory = MemorySystem()
        self.monitor = MonitoringSystem()
        self.emotion = EmotionSystem()
        self.attention = AttentionSystem()
        self.learning = LearningSystem()
        self.knowledge = KnowledgeSystem()
        self.planning = PlanningSystem()
        self.decision = DecisionSystem()
        self.processor = InputProcessor()
        
        # Initialize state
        self.state_history: List[Dict] = []
        self._lock = asyncio.Lock()
    
    async def initialize(self):
        """Initialize the agent asynchronously."""
        try:
            # Initialize systems that need async setup
            await self.memory.initialize()
            await self.emotion.initialize()
            
            logger.info("agent_initialized")
        except Exception as e:
            logger.error(f"Error initializing agent: {e}")
            raise
    
    async def process_input(self, user_input: str) -> str:
        """Process user input and generate response."""
        try:
            # Create context for this interaction
            context = {
                "user_input": user_input,
                "timestamp": datetime.now().isoformat()
            }
            
            # Update all systems
            await self.update_systems(context)
            
            # Generate response
            response = await self.generate_response(context)
            
            # Store interaction in state history
            await self.store_state(context, response)
            
            return response
        except Exception as e:
            logger.error(f"Error processing input: {e}")
            return "I apologize, but I encountered an error processing your input."
    
    async def update_systems(self, context: dict) -> None:
        """Update all cognitive systems with new context."""
        try:
            # Update systems in parallel
            await asyncio.gather(
                self.memory.update(context),
                self.monitor.update(context),
                self.emotion.update(context),
                self.attention.update(context),
                self.learning.update(context),
                self.knowledge.update(context),
                self.planning.update(context),
                self.decision.update(context),
                self.processor.update(context)
            )
        except Exception as e:
            logger.error(f"Error updating systems: {e}")
    
    async def generate_response(self, context: dict) -> str:
        """Generate response based on current state and context."""
        try:
            # Get emotional response
            emotional_response = await self.emotion.get_emotional_response(context)
            
            # Get cognitive response
            cognitive_response = await self.processor.generate_response(context)
            
            # Combine responses
            return f"{emotional_response} {cognitive_response}"
        except Exception as e:
            logger.error(f"Error generating response: {e}")
            return "I apologize, but I'm having trouble formulating a response."
    
    async def store_state(self, context: dict, response: str) -> None:
        """Store current state in history."""
        async with self._lock:
            state = {
                "timestamp": datetime.now().isoformat(),
                "context": context,
                "response": response,
                "memory_state": await self.memory.get_state(),
                "emotion_state": await self.emotion.get_state(),
                "attention_state": await self.attention.get_state(),
                "learning_state": await self.learning.get_state(),
                "knowledge_state": await self.knowledge.get_state(),
                "planning_state": await self.planning.get_state(),
                "decision_state": await self.decision.get_state(),
                "processor_state": await self.processor.get_state()
            }
            self.state_history.append(state)
    
    async def get_state(self) -> dict:
        """Get current state of the agent."""
        async with self._lock:
            return {
                "timestamp": datetime.now().isoformat(),
                "memory_state": await self.memory.get_state(),
                "emotion_state": await self.emotion.get_state(),
                "attention_state": await self.attention.get_state(),
                "learning_state": await self.learning.get_state(),
                "knowledge_state": await self.knowledge.get_state(),
                "planning_state": await self.planning.get_state(),
                "decision_state": await self.decision.get_state(),
                "processor_state": await self.processor.get_state(),
                "state_history_length": len(self.state_history)
            }
    
    async def get_metrics(self) -> dict:
        """Get agent metrics."""
        async with self._lock:
            return {
                "memory_metrics": await self.memory.get_metrics(),
                "emotion_metrics": await self.emotion.get_metrics(),
                "attention_metrics": await self.attention.get_metrics(),
                "learning_metrics": await self.learning.get_metrics(),
                "knowledge_metrics": await self.knowledge.get_metrics(),
                "planning_metrics": await self.planning.get_metrics(),
                "decision_metrics": await self.decision.get_metrics(),
                "processor_metrics": await self.processor.get_metrics(),
                "state_history_length": len(self.state_history)
            } 
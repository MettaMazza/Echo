"""
LLM integration for Echo cognitive agent.
"""
from typing import Dict, Any, Optional, List
from abc import ABC, abstractmethod
import openai
from core.config import LLMConfig

class LLMProvider(ABC):
    """Abstract base class for LLM providers."""
    
    @abstractmethod
    def generate(self, prompt: str, **kwargs) -> str:
        """Generate text from prompt.
        
        Args:
            prompt: Input prompt
            **kwargs: Additional generation parameters
            
        Returns:
            Generated text
        """
        pass
    
    @abstractmethod
    def get_embeddings(self, text: str) -> List[float]:
        """Get embeddings for text.
        
        Args:
            text: Input text
            
        Returns:
            List of embedding values
        """
        pass

class OpenAIProvider(LLMProvider):
    """OpenAI API provider."""
    
    def __init__(self, config: LLMConfig):
        """Initialize OpenAI provider.
        
        Args:
            config: LLM configuration
        """
        self.config = config
        openai.api_key = config.api_key
        if config.api_base:
            openai.api_base = config.api_base
    
    def generate(self, prompt: str, **kwargs) -> str:
        """Generate text using OpenAI API.
        
        Args:
            prompt: Input prompt
            **kwargs: Additional generation parameters
            
        Returns:
            Generated text
        """
        try:
            response = openai.ChatCompletion.create(
                model=self.config.model_name,
                messages=[{"role": "user", "content": prompt}],
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
                **kwargs
            )
            return response.choices[0].message.content
        except Exception as e:
            raise RuntimeError(f"OpenAI API error: {str(e)}")
    
    def get_embeddings(self, text: str) -> List[float]:
        """Get embeddings using OpenAI API.
        
        Args:
            text: Input text
            
        Returns:
            List of embedding values
        """
        try:
            response = openai.Embedding.create(
                model="text-embedding-ada-002",
                input=text
            )
            return response.data[0].embedding
        except Exception as e:
            raise RuntimeError(f"OpenAI API error: {str(e)}")

def create_llm_provider(config: LLMConfig) -> LLMProvider:
    """Create LLM provider based on configuration.
    
    Args:
        config: LLM configuration
        
    Returns:
        LLM provider instance
    """
    if config.model_name.startswith("gpt-"):
        return OpenAIProvider(config)
    else:
        raise ValueError(f"Unsupported model: {config.model_name}") 
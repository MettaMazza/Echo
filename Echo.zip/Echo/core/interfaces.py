"""
Core interfaces for the Echo cognitive agent.
"""
from abc import ABC, abstractmethod
from typing import Dict, Any

class CognitiveSubsystem(ABC):
    """Abstract base class for all cognitive subsystems."""
    
    @abstractmethod
    def update(self, context: Dict[str, Any]) -> None:
        """Update the subsystem based on the current context.
        
        Args:
            context: Dictionary containing current context information
        """
        pass
    
    @abstractmethod
    def get_state(self) -> Dict[str, Any]:
        """Get the current state of the subsystem.
        
        Returns:
            Dictionary containing the current state
        """
        pass 
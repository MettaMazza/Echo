"""
Integration subsystem for the Echo cognitive agent.
"""
from typing import Dict, Any, List, Optional, Set
from core.interfaces import CognitiveSubsystem
from datetime import datetime, timedelta
import math
import json
from dataclasses import dataclass
from pathlib import Path
import asyncio
import structlog
import os
import uuid
import aiofiles

logger = structlog.get_logger(__name__)

@dataclass
class IntegrationEvent:
    """Represents an integration event between subsystems."""
    event_type: str
    source_subsystem: str
    target_subsystem: str
    data: Dict[str, Any]
    priority: float = 0.5
    status: str = "pending"
    result: Optional[Dict[str, Any]] = None
    created_at: datetime = None
    last_updated: datetime = None
    timeout: float = 300.0  # Timeout in seconds
    retry_count: int = 0
    max_retries: int = 3
    related_events: Set[str] = None
    
    def __post_init__(self):
        """Initialize event attributes."""
        if self.created_at is None:
            self.created_at = datetime.now()
        if self.last_updated is None:
            self.last_updated = self.created_at
        if self.related_events is None:
            self.related_events = set()
    
    def update_status(self, status: str, result: Optional[Dict[str, Any]] = None) -> None:
        """Update event status and result."""
        self.status = status
        if result is not None:
            self.result = result
        self.last_updated = datetime.now()
    
    def is_expired(self) -> bool:
        """Check if event has expired."""
        return (datetime.now() - self.last_updated).total_seconds() > self.timeout
    
    def can_retry(self) -> bool:
        """Check if event can be retried."""
        return self.retry_count < self.max_retries
    
    def increment_retry(self) -> None:
        """Increment retry count."""
        self.retry_count += 1
        self.last_updated = datetime.now()
    
    def to_dict(self) -> dict:
        """Convert event to dictionary."""
        return {
            "event_type": self.event_type,
            "source_subsystem": self.source_subsystem,
            "target_subsystem": self.target_subsystem,
            "data": self.data,
            "priority": self.priority,
            "status": self.status,
            "result": self.result,
            "created_at": self.created_at.isoformat(),
            "last_updated": self.last_updated.isoformat(),
            "timeout": self.timeout,
            "retry_count": self.retry_count,
            "max_retries": self.max_retries,
            "related_events": list(self.related_events)
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'IntegrationEvent':
        """Create event from dictionary."""
        return cls(
            event_type=data["event_type"],
            source_subsystem=data["source_subsystem"],
            target_subsystem=data["target_subsystem"],
            data=data["data"],
            priority=float(data["priority"]),
            status=data["status"],
            result=data["result"],
            created_at=datetime.fromisoformat(data["created_at"]),
            last_updated=datetime.fromisoformat(data["last_updated"]),
            timeout=float(data["timeout"]),
            retry_count=int(data["retry_count"]),
            max_retries=int(data["max_retries"]),
            related_events=set(data["related_events"])
        )

class IntegrationSystem(CognitiveSubsystem):
    """Manages integration between cognitive subsystems."""
    
    def __init__(self, storage_dir: str = "data/integration"):
        """Initialize integration system."""
        self.storage_dir = Path(storage_dir)
        self._subsystems: Dict[str, Any] = {}
        self._events: Dict[str, IntegrationEvent] = {}
        self._event_history: List[Dict[str, Any]] = []
        self._lock = asyncio.Lock()
        self._max_events = 1000
        self._max_history = 1000
        self._processing_interval = 1.0  # seconds
        
        # Create storage directory
        os.makedirs(self.storage_dir, exist_ok=True)
    
    async def initialize(self, config: dict = None):
        """Initialize the integration system asynchronously."""
        if config:
            if "max_events" in config:
                if not isinstance(config["max_events"], int) or config["max_events"] <= 0:
                    raise ValueError("max_events must be a positive integer")
                self._max_events = config["max_events"]
            if "max_history" in config:
                if not isinstance(config["max_history"], int) or config["max_history"] <= 0:
                    raise ValueError("max_history must be a positive integer")
                self._max_history = config["max_history"]
            if "processing_interval" in config:
                if not isinstance(config["processing_interval"], (int, float)) or config["processing_interval"] <= 0:
                    raise ValueError("processing_interval must be a positive number")
                self._processing_interval = config["processing_interval"]
        
        # Load existing events
        await self._load_events()
    
    async def _load_events(self):
        """Load events from storage."""
        try:
            event_file = self.storage_dir / "events.json"
            if event_file.exists():
                async with aiofiles.open(event_file) as f:
                    data = json.loads(await f.read())
                    self._events = {
                        event_id: IntegrationEvent.from_dict(event_data)
                        for event_id, event_data in data["events"].items()
                    }
                    self._event_history = data["event_history"]
        except Exception as e:
            logger.error(f"Error loading events: {e}")
            self._events = {}
            self._event_history = []
    
    async def _save_events(self):
        """Save events to storage."""
        try:
            event_file = self.storage_dir / "events.json"
            async with aiofiles.open(event_file, 'w') as f:
                await f.write(json.dumps({
                    "events": {
                        event_id: event.to_dict()
                        for event_id, event in self._events.items()
                    },
                    "event_history": self._event_history[-self._max_history:]
                }))
        except Exception as e:
            logger.error(f"Error saving events: {e}")
    
    def register_subsystem(self, name: str, subsystem: Any) -> None:
        """Register a subsystem for integration."""
        self._subsystems[name] = subsystem
    
    async def _process_events(self) -> None:
        """Process pending integration events."""
        async with self._lock:
            current_time = datetime.now()
            completed_events = set()
            
            # Get pending events
            pending_events = [
                (event_id, event)
                for event_id, event in self._events.items()
                if event.status in ["pending", "processing"]
            ]
            
            # Sort by priority and creation time
            pending_events.sort(
                key=lambda x: (-x[1].priority, x[1].created_at)
            )
            
            for event_id, event in pending_events:
                # Check for timeout
                if event.is_expired():
                    if event.can_retry():
                        event.increment_retry()
                        event.update_status("pending")
                        continue
                    else:
                        event.update_status("failed", {"error": "Timeout"})
                        completed_events.add(event_id)
                        continue
                
                # Update status to processing
                event.update_status("processing")
                
                try:
                    # Process event based on type
                    if event.event_type == "data_transfer":
                        result = await self._handle_data_transfer(event)
                    elif event.event_type == "state_sync":
                        result = await self._handle_state_sync(event)
                    elif event.event_type == "coordination":
                        result = await self._handle_coordination(event)
                    elif event.event_type == "feedback":
                        result = await self._handle_feedback(event)
                    else:
                        result = {"error": "Unknown event type"}
                    
                    # Update event status
                    event.update_status("completed", result)
                    completed_events.add(event_id)
                    
                except Exception as e:
                    logger.error(f"Error processing event {event_id}: {e}")
                    if event.can_retry():
                        event.increment_retry()
                        event.update_status("pending")
                    else:
                        event.update_status("failed", {"error": str(e)})
                        completed_events.add(event_id)
            
            # Remove completed events
            for event_id in completed_events:
                if event_id in self._events:
                    del self._events[event_id]
            
            # Save changes
            await self._save_events()
    
    async def _handle_data_transfer(self, event: IntegrationEvent) -> Dict[str, Any]:
        """Handle data transfer between subsystems."""
        try:
            source = self._subsystems.get(event.source_subsystem)
            target = self._subsystems.get(event.target_subsystem)
            
            if not source or not target:
                return {"error": "Subsystem not found"}
            
            # Validate data
            if not isinstance(event.data, dict):
                return {"error": "Invalid data format"}
            
            # Transfer data
            if hasattr(target, 'update'):
                if asyncio.iscoroutinefunction(target.update):
                    await target.update(event.data)
                else:
                    target.update(event.data)
            
            return {
                "status": "success",
                "source": event.source_subsystem,
                "target": event.target_subsystem,
                "data_size": len(str(event.data))
            }
        except Exception as e:
            logger.error(f"Error in data transfer: {e}")
            return {"error": str(e)}
    
    async def _handle_state_sync(self, event: IntegrationEvent) -> Dict[str, Any]:
        """Handle state synchronization between subsystems."""
        try:
            source = self._subsystems.get(event.source_subsystem)
            target = self._subsystems.get(event.target_subsystem)
            
            if not source or not target:
                return {"error": "Subsystem not found"}
            
            # Get source state
            if hasattr(source, 'get_state'):
                if asyncio.iscoroutinefunction(source.get_state):
                    source_state = await source.get_state()
                else:
                    source_state = source.get_state()
            else:
                return {"error": "Source subsystem has no get_state method"}
            
            # Update target state
            if hasattr(target, 'update'):
                if asyncio.iscoroutinefunction(target.update):
                    await target.update(source_state)
                else:
                    target.update(source_state)
            
            return {
                "status": "success",
                "source": event.source_subsystem,
                "target": event.target_subsystem,
                "state_size": len(str(source_state))
            }
        except Exception as e:
            logger.error(f"Error in state sync: {e}")
            return {"error": str(e)}
    
    async def _handle_coordination(self, event: IntegrationEvent) -> Dict[str, Any]:
        """Handle coordination between subsystems."""
        try:
            source = self._subsystems.get(event.source_subsystem)
            target = self._subsystems.get(event.target_subsystem)
            
            if not source or not target:
                return {"error": "Subsystem not found"}
            
            # Validate coordination data
            if not isinstance(event.data, dict):
                return {"error": "Invalid coordination data format"}
            
            # Process coordination
            if hasattr(target, 'coordinate'):
                if asyncio.iscoroutinefunction(target.coordinate):
                    result = await target.coordinate(event.data)
                else:
                    result = target.coordinate(event.data)
            else:
                return {"error": "Target subsystem has no coordinate method"}
            
            return {
                "status": "success",
                "source": event.source_subsystem,
                "target": event.target_subsystem,
                "result": result
            }
        except Exception as e:
            logger.error(f"Error in coordination: {e}")
            return {"error": str(e)}
    
    async def _handle_feedback(self, event: IntegrationEvent) -> Dict[str, Any]:
        """Handle feedback between subsystems."""
        try:
            source = self._subsystems.get(event.source_subsystem)
            target = self._subsystems.get(event.target_subsystem)
            
            if not source or not target:
                return {"error": "Subsystem not found"}
            
            # Validate feedback data
            if not isinstance(event.data, dict):
                return {"error": "Invalid feedback data format"}
            
            # Process feedback
            if hasattr(target, 'process_feedback'):
                if asyncio.iscoroutinefunction(target.process_feedback):
                    result = await target.process_feedback(event.data)
                else:
                    result = target.process_feedback(event.data)
            else:
                return {"error": "Target subsystem has no process_feedback method"}
            
            return {
                "status": "success",
                "source": event.source_subsystem,
                "target": event.target_subsystem,
                "result": result
            }
        except Exception as e:
            logger.error(f"Error in feedback: {e}")
            return {"error": str(e)}
    
    async def _update_event_states(self) -> None:
        """Update states of existing events."""
        async with self._lock:
            current_time = datetime.now()
            
            for event in self._events.values():
                if event.status == "processing":
                    if event.is_expired():
                        if event.can_retry():
                            event.increment_retry()
                            event.update_status("pending")
                        else:
                            event.update_status("failed", {"error": "Timeout"})
            
            await self._save_events()
    
    async def _prune_events(self) -> None:
        """Remove expired events and limit event history."""
        async with self._lock:
            current_time = datetime.now()
            
            # Remove expired events
            expired = [
                event_id for event_id, event in self._events.items()
                if event.is_expired() and not event.can_retry()
            ]
            for event_id in expired:
                del self._events[event_id]
            
            # Limit event history
            if len(self._event_history) > self._max_history:
                self._event_history = self._event_history[-self._max_history:]
            
            await self._save_events()
    
    async def _create_event(self,
                     event_type: str,
                     source_subsystem: str,
                     target_subsystem: str,
                     data: Dict[str, Any],
                     priority: float = 0.5) -> str:
        """Create a new integration event."""
        async with self._lock:
            # Generate event ID
            event_id = str(uuid.uuid4())
            
            # Create event
            event = IntegrationEvent(
                event_type=event_type,
                source_subsystem=source_subsystem,
                target_subsystem=target_subsystem,
                data=data,
                priority=priority
            )
            
            # Store event
            self._events[event_id] = event
            self._event_history.append(event.to_dict())
            
            # Save changes
            await self._save_events()
            
            return event_id
    
    def get_event(self, event_id: str) -> Optional[IntegrationEvent]:
        """Get event by ID."""
        return self._events.get(event_id)
    
    def get_events_by_type(self, event_type: str) -> List[IntegrationEvent]:
        """Get events by type."""
        return [
            event for event in self._events.values()
            if event.event_type == event_type
        ]
    
    def get_related_events(self, event_id: str) -> List[IntegrationEvent]:
        """Get events related to the given event."""
        event = self._events.get(event_id)
        if not event:
            return []
        
        return [
            self._events[related_id]
            for related_id in event.related_events
            if related_id in self._events
        ]
    
    async def get_state(self) -> dict:
        """Get current system state."""
        return {
            "events": {
                event_id: event.to_dict()
                for event_id, event in self._events.items()
            },
            "event_history": self._event_history[-self._max_history:],
            "subsystems": list(self._subsystems.keys())
        }
    
    async def get_metrics(self) -> dict:
        """Get system metrics."""
        return {
            "total_events": len(self._events),
            "event_history_size": len(self._event_history),
            "subsystem_count": len(self._subsystems),
            "event_types": {
                event_type: len(self.get_events_by_type(event_type))
                for event_type in set(event.event_type for event in self._events.values())
            }
        }
    
    async def update(self, context: dict) -> None:
        """Update system state."""
        # Process user input
        if "user_input" in context:
            await self._process_user_input(context["user_input"])
        
        # Process subsystem states
        if "subsystem_states" in context:
            await self._process_subsystem_states(context["subsystem_states"])
        
        # Process events
        await self._process_events()
        
        # Update event states
        await self._update_event_states()
        
        # Prune old events
        await self._prune_events()
    
    async def _process_user_input(self, user_input: str) -> None:
        """Process user input to create events."""
        for subsystem in self._subsystems.values():
            if hasattr(subsystem, 'process_user_input'):
                if asyncio.iscoroutinefunction(subsystem.process_user_input):
                    await subsystem.process_user_input(user_input)
                else:
                    subsystem.process_user_input(user_input)
    
    async def _process_subsystem_states(self, states: Dict[str, dict]) -> None:
        """Process subsystem states to create events."""
        for source_name, source_state in states.items():
            for target_name, target_state in states.items():
                if source_name != target_name:
                    await self._create_event(
                        event_type="state_sync",
                        source_subsystem=source_name,
                        target_subsystem=target_name,
                        data=source_state
                    )
    
    async def cleanup(self) -> None:
        """Clean up system resources."""
        await self._save_events() 
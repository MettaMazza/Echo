"""
Imagination subsystem for the Echo cognitive agent.
"""
from typing import Dict, Any, List, Optional
from core.interfaces import CognitiveSubsystem
from datetime import datetime
import random

class Scenario:
    """Represents a simulated scenario or creative idea."""
    
    def __init__(self,
                 description: str,
                 scenario_type: str,
                 confidence: float = 0.5,
                 context: Optional[Dict[str, Any]] = None):
        self.description = description
        self.scenario_type = scenario_type  # "simulation", "idea", "hypothesis"
        self.confidence = confidence
        self.context = context or {}
        self.created_at = datetime.now()
        self.last_updated = datetime.now()
        self.evaluation_score: Optional[float] = None
        self.related_scenarios: List[str] = []
    
    def update_evaluation(self, score: float) -> None:
        """Update the scenario's evaluation score."""
        self.evaluation_score = max(0.0, min(1.0, score))
        self.last_updated = datetime.now()

class ImaginationSystem(CognitiveSubsystem):
    """Handles creative thinking and scenario simulation."""
    
    def __init__(self):
        self._scenarios: Dict[str, Scenario] = {}
        self._max_scenarios = 100
        self._creativity_threshold = 0.3
        self._evaluation_threshold = 0.6
    
    def update(self, context: Dict[str, Any]) -> None:
        """Update imagination system based on context.
        
        Args:
            context: Dictionary containing current context including:
                    - user_input: The user's message
                    - llm_response: The LLM's response
                    - goals: Current goals from goal system
                    - other_subsystems: States of other subsystems
        """
        # Generate new scenarios based on context
        if "user_input" in context:
            self._generate_scenarios_from_input(context["user_input"])
        
        if "goals" in context:
            self._generate_scenarios_from_goals(context["goals"])
        
        # Evaluate existing scenarios
        self._evaluate_scenarios(context)
        
        # Prune low-quality scenarios
        self._prune_scenarios()
    
    def get_state(self) -> Dict[str, Any]:
        """Get current imagination state.
        
        Returns:
            Dictionary containing current scenarios and their states.
        """
        active_scenarios = [
            {
                "description": scenario.description,
                "type": scenario.scenario_type,
                "confidence": scenario.confidence,
                "evaluation_score": scenario.evaluation_score,
                "created_at": scenario.created_at.isoformat(),
                "last_updated": scenario.last_updated.isoformat()
            }
            for scenario in self._scenarios.values()
        ]
        
        return {
            "active_scenarios": sorted(
                active_scenarios,
                key=lambda x: (x["evaluation_score"] or 0, x["confidence"]),
                reverse=True
            ),
            "total_scenarios": len(self._scenarios)
        }
    
    def _generate_scenarios_from_input(self, user_input: str) -> None:
        """Generate scenarios based on user input."""
        # Simple scenario generation based on input patterns
        input_lower = user_input.lower()
        
        # Generate simulation scenarios
        if any(word in input_lower for word in ["what if", "imagine", "suppose"]):
            self._add_scenario(
                Scenario(
                    description=f"Simulation: {user_input}",
                    scenario_type="simulation",
                    confidence=0.7
                )
            )
        
        # Generate creative ideas
        if any(word in input_lower for word in ["idea", "think", "create"]):
            self._add_scenario(
                Scenario(
                    description=f"Creative idea: {user_input}",
                    scenario_type="idea",
                    confidence=0.6
                )
            )
        
        # Generate hypotheses
        if any(word in input_lower for word in ["why", "how", "explain"]):
            self._add_scenario(
                Scenario(
                    description=f"Hypothesis: {user_input}",
                    scenario_type="hypothesis",
                    confidence=0.5
                )
            )
    
    def _generate_scenarios_from_goals(self, goals: Dict[str, Any]) -> None:
        """Generate scenarios based on current goals."""
        active_goals = goals.get("active_goals", [])
        
        for goal in active_goals:
            # Generate success scenarios
            self._add_scenario(
                Scenario(
                    description=f"Success scenario for: {goal['description']}",
                    scenario_type="simulation",
                    confidence=0.8,
                    context={"goal": goal}
                )
            )
            
            # Generate potential obstacles
            self._add_scenario(
                Scenario(
                    description=f"Potential obstacle for: {goal['description']}",
                    scenario_type="hypothesis",
                    confidence=0.6,
                    context={"goal": goal}
                )
            )
    
    def _evaluate_scenarios(self, context: Dict[str, Any]) -> None:
        """Evaluate existing scenarios based on context."""
        for scenario in self._scenarios.values():
            # Skip already evaluated scenarios
            if scenario.evaluation_score is not None:
                continue
            
            # Simple evaluation based on scenario type and context
            if scenario.scenario_type == "simulation":
                # Evaluate simulations based on goal relevance
                if "goals" in context:
                    goal_relevance = self._calculate_goal_relevance(
                        scenario, context["goals"]
                    )
                    scenario.update_evaluation(goal_relevance)
            
            elif scenario.scenario_type == "idea":
                # Evaluate ideas based on creativity and feasibility
                creativity_score = random.uniform(0.3, 0.9)  # Placeholder
                scenario.update_evaluation(creativity_score)
            
            elif scenario.scenario_type == "hypothesis":
                # Evaluate hypotheses based on evidence and plausibility
                plausibility_score = random.uniform(0.4, 0.8)  # Placeholder
                scenario.update_evaluation(plausibility_score)
    
    def _calculate_goal_relevance(self, scenario: Scenario, goals: Dict[str, Any]) -> float:
        """Calculate how relevant a scenario is to current goals."""
        active_goals = goals.get("active_goals", [])
        if not active_goals:
            return 0.0
        
        # Simple relevance calculation based on keyword matching
        scenario_words = set(scenario.description.lower().split())
        max_relevance = 0.0
        
        for goal in active_goals:
            goal_words = set(goal["description"].lower().split())
            common_words = scenario_words.intersection(goal_words)
            relevance = len(common_words) / max(len(scenario_words), len(goal_words))
            max_relevance = max(max_relevance, relevance)
        
        return max_relevance
    
    def _prune_scenarios(self) -> None:
        """Remove low-quality or outdated scenarios."""
        # Sort scenarios by evaluation score and confidence
        sorted_scenarios = sorted(
            self._scenarios.items(),
            key=lambda x: (
                x[1].evaluation_score or 0,
                x[1].confidence,
                x[1].created_at
            ),
            reverse=True
        )
        
        # Keep only the best scenarios up to max_scenarios
        self._scenarios = dict(sorted_scenarios[:self._max_scenarios])
    
    def _add_scenario(self, scenario: Scenario) -> None:
        """Add a new scenario to the system."""
        scenario_id = f"scenario_{len(self._scenarios)}"
        self._scenarios[scenario_id] = scenario 
"""
Motivation subsystem for the Echo cognitive agent.
"""
from typing import Dict, Any, List, Optional
from core.interfaces import CognitiveSubsystem
from datetime import datetime, timedelta
import math

class EnergyLevel:
    """Represents the agent's current energy state."""
    
    def __init__(self, initial_level: float = 1.0):
        self.level = initial_level
        self.last_updated = datetime.now()
        self.recovery_rate = 0.1  # Energy recovery per hour
        self.depletion_rate = 0.05  # Energy depletion per hour
        self.min_level = 0.2  # Minimum energy level
        self.max_level = 1.0  # Maximum energy level
    
    def update(self, time_delta: timedelta) -> None:
        """Update energy level based on time passed."""
        hours_passed = time_delta.total_seconds() / 3600
        self.level = min(
            self.max_level,
            max(
                self.min_level,
                self.level + (self.recovery_rate * hours_passed)
            )
        )
        self.last_updated = datetime.now()
    
    def consume(self, amount: float) -> None:
        """Consume energy for an action."""
        self.level = max(self.min_level, self.level - amount)
        self.last_updated = datetime.now()

class MotivationSystem(CognitiveSubsystem):
    """Manages the agent's motivation and energy levels."""
    
    def __init__(self):
        self._energy = EnergyLevel()
        self._motivation_factors: Dict[str, float] = {
            "goal_progress": 0.3,
            "goal_priority": 0.2,
            "energy_level": 0.2,
            "success_rate": 0.15,
            "challenge_level": 0.15
        }
        self._success_history: List[bool] = []
        self._max_history = 10
        self._challenge_level = 0.5
        self._last_update = datetime.now()
    
    def update(self, context: Dict[str, Any]) -> None:
        """Update motivation system based on context.
        
        Args:
            context: Dictionary containing current context including:
                    - goals: Current goals from goal system
                    - actions: Completed actions
                    - other_subsystems: States of other subsystems
        """
        # Update energy level based on time passed
        current_time = datetime.now()
        time_delta = current_time - self._last_update
        self._energy.update(time_delta)
        
        # Update success history
        if "actions" in context:
            self._update_success_history(context["actions"])
        
        # Update challenge level
        if "goals" in context:
            self._update_challenge_level(context["goals"])
        
        # Consume energy for current activities
        if "current_actions" in context:
            self._consume_energy_for_actions(context["current_actions"])
        
        self._last_update = current_time
    
    def get_state(self) -> Dict[str, Any]:
        """Get current motivation state.
        
        Returns:
            Dictionary containing current motivation metrics.
        """
        return {
            "energy_level": self._energy.level,
            "motivation_score": self._calculate_motivation_score(),
            "success_rate": self._calculate_success_rate(),
            "challenge_level": self._challenge_level,
            "last_updated": self._last_update.isoformat()
        }
    
    def can_perform_action(self, action_energy_cost: float = 0.1) -> bool:
        """Check if the agent has enough energy to perform an action.
        
        Args:
            action_energy_cost: The energy cost of the action
            
        Returns:
            True if the agent has enough energy, False otherwise
        """
        return self._energy.level >= action_energy_cost
    
    def _update_success_history(self, actions: List[Dict[str, Any]]) -> None:
        """Update the history of successful actions."""
        for action in actions:
            if action.get("status") == "completed":
                self._success_history.append(True)
            elif action.get("status") in ["failed", "timeout"]:
                self._success_history.append(False)
            
            # Keep history at max length
            if len(self._success_history) > self._max_history:
                self._success_history.pop(0)
    
    def _update_challenge_level(self, goals: Dict[str, Any]) -> None:
        """Update the challenge level based on current goals."""
        active_goals = goals.get("active_goals", [])
        if not active_goals:
            return
        
        # Calculate average goal priority and progress
        priorities = [goal.get("priority", 0.5) for goal in active_goals]
        progress = [goal.get("progress", 0.0) for goal in active_goals]
        
        avg_priority = sum(priorities) / len(priorities)
        avg_progress = sum(progress) / len(progress)
        
        # Challenge level increases with priority and decreases with progress
        self._challenge_level = min(1.0, max(0.0,
            (avg_priority * 0.7) + ((1 - avg_progress) * 0.3)
        ))
    
    def _consume_energy_for_actions(self, actions: List[Dict[str, Any]]) -> None:
        """Consume energy for current actions."""
        # Base energy cost per action
        base_cost = 0.05
        
        # Additional cost based on action priority
        for action in actions:
            priority = action.get("priority", 0.5)
            energy_cost = base_cost * (1 + priority)
            self._energy.consume(energy_cost)
    
    def _calculate_motivation_score(self) -> float:
        """Calculate the current motivation score."""
        success_rate = self._calculate_success_rate()
        
        # Weighted combination of factors
        score = (
            self._motivation_factors["goal_progress"] * self._challenge_level +
            self._motivation_factors["goal_priority"] * self._challenge_level +
            self._motivation_factors["energy_level"] * self._energy.level +
            self._motivation_factors["success_rate"] * success_rate +
            self._motivation_factors["challenge_level"] * self._challenge_level
        )
        
        return min(1.0, max(0.0, score))
    
    def _calculate_success_rate(self) -> float:
        """Calculate the success rate from recent actions."""
        if not self._success_history:
            return 0.5  # Default to neutral if no history
        
        return sum(self._success_history) / len(self._success_history)
    
    def adjust_motivation_factors(self, factors: Dict[str, float]) -> None:
        """Adjust the weights of motivation factors.
        
        Args:
            factors: Dictionary of factor names and their new weights
        """
        for factor, weight in factors.items():
            if factor in self._motivation_factors:
                self._motivation_factors[factor] = max(0.0, min(1.0, weight))
        
        # Normalize weights to sum to 1.0
        total = sum(self._motivation_factors.values())
        if total > 0:
            self._motivation_factors = {
                k: v/total for k, v in self._motivation_factors.items()
            } 
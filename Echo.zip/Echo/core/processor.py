"""
Input processing pipeline for Echo cognitive agent.
"""
import json
from datetime import datetime
from dataclasses import dataclass
from typing import Dict, List, Optional, Any
from pathlib import Path
import threading
import queue
import time
import structlog
import asyncio

logger = structlog.get_logger(__name__)

@dataclass
class ProcessingState:
    """State of input processing."""
    input_text: str
    start_time: datetime
    end_time: Optional[datetime] = None
    status: str = "pending"
    error: Optional[str] = None
    metrics: Dict[str, Any] = None
    current_input: str = ""
    processing_stage: str = "initial"
    processing_history: List[Dict[str, Any]] = None
    
    def __post_init__(self):
        """Initialize metrics."""
        if self.metrics is None:
            self.metrics = {
                "processing_time": 0.0,
                "memory_usage": 0.0,
                "component_states": {}
            }
        if self.processing_history is None:
            self.processing_history = []
    
    def to_dict(self) -> dict:
        """Convert state to dictionary."""
        return {
            "input_text": self.input_text,
            "start_time": self.start_time.isoformat(),
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "status": self.status,
            "error": self.error,
            "metrics": self.metrics,
            "current_input": self.current_input,
            "processing_stage": self.processing_stage,
            "processing_history": self.processing_history
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'ProcessingState':
        """Create state from dictionary."""
        return cls(
            input_text=data["input_text"],
            start_time=datetime.fromisoformat(data["start_time"]),
            end_time=datetime.fromisoformat(data["end_time"]) if data["end_time"] else None,
            status=data["status"],
            error=data["error"],
            metrics=data["metrics"],
            current_input=data.get("current_input", ""),
            processing_stage=data.get("processing_stage", "initial"),
            processing_history=data.get("processing_history", [])
        )

class InputProcessor:
    """Input processing pipeline."""
    
    MAX_INPUT_LENGTH = 10000
    
    def __init__(self, storage_dir: str = "processor"):
        """Initialize processor."""
        self.storage_dir = Path(storage_dir)
        self._components = {}
        self._processing_queue = asyncio.Queue()
        self._history: List[ProcessingState] = []
        self._lock = asyncio.Lock()
        self._is_processing = False
        self._max_history = 1000
        self.state = ProcessingState(
            input_text="",
            start_time=datetime.now()
        )
        
        # Create storage directory
        self._init_storage()
    
    def _init_storage(self):
        """Initialize storage directory."""
        self.storage_dir.mkdir(exist_ok=True)
        
        # Load processing history
        self._load_history()
    
    def _load_history(self):
        """Load processing history from storage."""
        try:
            history_file = self.storage_dir / "history.json"
            if history_file.exists():
                with open(history_file) as f:
                    data = json.load(f)
                    self._history = [
                        ProcessingState.from_dict(state_data)
                        for state_data in data
                    ]
        except Exception as e:
            logger.error(f"Error loading processing history: {e}")
            self._history = []
    
    def _save_history(self):
        """Save processing history to storage."""
        try:
            history_file = self.storage_dir / "history.json"
            with open(history_file, 'w') as f:
                json.dump([
                    state.to_dict()
                    for state in self._history[-self._max_history:]
                ], f)
        except Exception as e:
            logger.error(f"Error saving processing history: {e}")
    
    def register_component(self, name: str, component: Any) -> None:
        """Register a component for processing."""
        self._components[name] = component
    
    async def start_processing(self) -> None:
        """Start processing queue."""
        async with self._lock:
            if not self._is_processing:
                self._is_processing = True
                asyncio.create_task(self._process_queue())
    
    async def stop_processing(self) -> None:
        """Stop processing queue."""
        async with self._lock:
            self._is_processing = False
    
    async def _process_queue(self) -> None:
        """Process items in the queue."""
        while self._is_processing:
            try:
                # Get next item from queue
                state = await self._processing_queue.get()
                
                # Process input
                await self._process_input(state)
                
                # Update history
                async with self._lock:
                    self._history.append(state)
                    if len(self._history) > self._max_history:
                        self._history = self._history[-self._max_history:]
                    self._save_history()
                
                # Mark task as done
                self._processing_queue.task_done()
                
            except asyncio.QueueEmpty:
                await asyncio.sleep(0.1)
            except Exception as e:
                logger.error(f"Error processing queue: {e}")
    
    async def process(self, input_text: str) -> Dict[str, Any]:
        """Process input text."""
        # Create processing state
        state = ProcessingState(
            input_text=input_text,
            start_time=datetime.now()
        )
        
        # Validate input
        if not self._validate_input(input_text):
            state.status = "error"
            state.error = "Invalid input"
            state.end_time = datetime.now()
            return state.to_dict()
        
        # Update state
        self.state = state
        self.state.current_input = input_text
        self.state.processing_stage = "processing"
        
        # Add to processing queue
        await self._processing_queue.put(state)
        
        # Process immediately
        await self._process_input(state)
        
        return state.to_dict()
    
    def _validate_input(self, input_text: str) -> bool:
        """Validate input text."""
        if not input_text or not isinstance(input_text, str):
            return False
        
        # Check input length
        if len(input_text) > self.MAX_INPUT_LENGTH:
            return False
        
        return True
    
    async def _process_input(self, state: ProcessingState) -> None:
        """Process input through components."""
        try:
            start_time = time.time()
            
            # Update component states
            for name, component in self._components.items():
                try:
                    # Get component state
                    component_state = await component.get_state() if asyncio.iscoroutinefunction(component.get_state) else component.get_state()
                    
                    # Update metrics
                    state.metrics["component_states"][name] = component_state
                    
                    # Process input
                    if hasattr(component, "update"):
                        if asyncio.iscoroutinefunction(component.update):
                            await component.update({"user_input": state.input_text})
                        else:
                            component.update({"user_input": state.input_text})
                    
                except Exception as e:
                    logger.error(f"Error processing component {name}: {e}")
                    state.metrics["component_states"][name] = {"error": str(e)}
            
            # Update metrics
            state.metrics["processing_time"] = time.time() - start_time
            state.metrics["memory_usage"] = self._get_memory_usage()
            
            # Update processing history
            state.processing_history.append({
                "stage": "completed",
                "timestamp": datetime.now().isoformat(),
                "metrics": state.metrics
            })
            
            # Mark as complete
            state.status = "complete"
            state.end_time = datetime.now()
            state.processing_stage = "completed"
            
        except Exception as e:
            logger.error(f"Error processing input: {e}")
            state.status = "error"
            state.error = str(e)
            state.end_time = datetime.now()
            state.processing_stage = "error"
    
    def _get_memory_usage(self) -> float:
        """Get current memory usage in MB."""
        try:
            import psutil
            process = psutil.Process()
            return process.memory_info().rss / 1024 / 1024  # Convert to MB
        except ImportError:
            return 0.0
    
    async def get_state(self) -> dict:
        """Get current state of the processor."""
        async with self._lock:
            return {
                "is_processing": self._is_processing,
                "queue_size": self._processing_queue.qsize(),
                "history_size": len(self._history),
                "components": list(self._components.keys()),
                "last_update": datetime.now().isoformat(),
                "current_state": self.state.to_dict()
            }
    
    async def get_metrics(self) -> dict:
        """Get processor metrics."""
        async with self._lock:
            return {
                "queue_size": self._processing_queue.qsize(),
                "history_size": len(self._history),
                "component_count": len(self._components),
                "memory_usage": self._get_memory_usage()
            }
    
    async def cleanup(self) -> None:
        """Clean up processor resources."""
        async with self._lock:
            # Stop processing
            self._is_processing = False
            # Clear queue
            while not self._processing_queue.empty():
                try:
                    self._processing_queue.get_nowait()
                    self._processing_queue.task_done()
                except asyncio.QueueEmpty:
                    break
            # Save history
            self._save_history()
            # Clear history
            self._history = []
            self.state = ProcessingState(
                input_text="",
                start_time=datetime.now()
            ) 
"""
Emotion system for Echo cognitive agent.
"""
import json
from datetime import datetime, timedelta
from dataclasses import dataclass
from typing import Dict, List, Optional
from pathlib import Path
import asyncio
import aiofiles
import structlog
import os

logger = structlog.get_logger(__name__)

@dataclass
class Emotion:
    """Emotion data class."""
    name: str
    intensity: float
    trigger: str = ""
    created_at: datetime = None
    last_updated: datetime = None
    duration: float = 60.0  # Duration in seconds
    triggers: List[str] = None
    related_emotions: List[str] = None
    
    def __post_init__(self):
        """Initialize timestamps and lists."""
        if self.created_at is None:
            self.created_at = datetime.now()
        if self.last_updated is None:
            self.last_updated = self.created_at
        if self.triggers is None:
            self.triggers = []
        if self.related_emotions is None:
            self.related_emotions = []
    
    def to_dict(self) -> dict:
        """Convert emotion to dictionary."""
        return {
            "name": self.name,
            "intensity": min(max(self.intensity, 0.0), 1.0),
            "trigger": self.trigger,
            "created_at": self.created_at.isoformat(),
            "last_updated": self.last_updated.isoformat(),
            "duration": self.duration,
            "triggers": self.triggers,
            "related_emotions": self.related_emotions
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'Emotion':
        """Create emotion from dictionary."""
        return cls(
            name=data["name"],
            intensity=float(data["intensity"]),
            trigger=data["trigger"],
            created_at=datetime.fromisoformat(data["created_at"]),
            last_updated=datetime.fromisoformat(data["last_updated"]),
            duration=float(data["duration"]),
            triggers=data.get("triggers", []),
            related_emotions=data.get("related_emotions", [])
        )

    def update_intensity(self, value: float) -> None:
        """Update emotion intensity."""
        self.intensity = max(0.0, min(1.0, value))
        self.last_updated = datetime.now()

    def add_trigger(self, trigger: str) -> None:
        """Add a trigger to the emotion."""
        if trigger and trigger not in self.triggers:
            self.triggers.append(trigger)
            self.last_updated = datetime.now()

    def add_related_emotion(self, emotion: 'Emotion') -> None:
        """Add a related emotion."""
        if emotion.name not in self.related_emotions:
            self.related_emotions.append(emotion.name)
            emotion.related_emotions.append(self.name)
            self.last_updated = datetime.now()

    def is_expired(self) -> bool:
        """Check if emotion has expired."""
        return (datetime.now() - self.created_at).total_seconds() > self.duration

class EmotionSystem:
    """Emotion system for managing emotional states."""
    
    def __init__(self, storage_dir: str = "data/emotions"):
        """Initialize emotion system."""
        self.storage_dir = Path(storage_dir)
        self._max_emotions = 10
        self._emotions: Dict[str, Emotion] = {}
        self._emotion_history: List[Emotion] = []
        self._decay_rate = 0.1
    
    async def initialize(self, config: dict = None):
        """Initialize the emotion system asynchronously with config validation."""
        if config:
            if "max_emotions" in config:
                if not isinstance(config["max_emotions"], int) or config["max_emotions"] <= 0:
                    raise ValueError("max_emotions must be a positive integer")
                self._max_emotions = config["max_emotions"]
            if "decay_rate" in config:
                if not isinstance(config["decay_rate"], (int, float)) or not (0 <= config["decay_rate"] <= 1):
                    raise ValueError("decay_rate must be between 0 and 1")
                self._decay_rate = config["decay_rate"]
        if not isinstance(self._max_emotions, int) or self._max_emotions <= 0:
            raise ValueError("max_emotions must be a positive integer")
        
        # Create storage directory if it doesn't exist
        os.makedirs(self.storage_dir, exist_ok=True)
        
        # Load existing emotions
        await self.load_state()
    
    async def _save_emotions(self):
        """Save emotions to disk."""
        try:
            state = await self.get_state()
            async with aiofiles.open(self.storage_dir / "emotion_state.json", "w") as f:
                await f.write(json.dumps(state, default=str))
        except Exception as e:
            logger.error(f"Error saving emotions: {e}")
    
    async def _load_emotions(self):
        """Load emotions from disk."""
        try:
            state_file = self.storage_dir / "emotion_state.json"
            if not state_file.exists():
                return
            
            async with aiofiles.open(state_file, "r") as f:
                state = json.loads(await f.read())
            
            # Clear existing emotions
            self._emotions.clear()
            self._emotion_history.clear()
            
            # Load emotions
            for emotion_data in state.get("emotions", []):
                emotion = Emotion.from_dict(emotion_data)
                self._emotions[emotion.name] = emotion
                self._emotion_history.append(emotion)
        except Exception as e:
            logger.error(f"Error loading emotions: {e}")
    
    async def _trigger_emotion(self, name: str, intensity: float, trigger: str) -> None:
        """Trigger a new emotion or update existing one."""
        if len(self._emotions) >= self._max_emotions:
            await self._prune_emotions()
        
        if name in self._emotions:
            # Update existing emotion
            emotion = self._emotions[name]
            emotion.update_intensity(max(emotion.intensity, intensity))
            emotion.add_trigger(trigger)
        else:
            # Create new emotion
            emotion = Emotion(
                name=name,
                intensity=intensity,
                trigger=trigger
            )
            self._emotions[name] = emotion
            self._emotion_history.append(emotion)
        
        await self._save_emotions()
    
    async def _prune_emotions(self) -> None:
        """Remove expired and low-intensity emotions."""
        current_time = datetime.now()
        
        # Remove expired emotions
        expired = [
            name for name, emotion in self._emotions.items()
            if emotion.is_expired()
        ]
        for name in expired:
            del self._emotions[name]
        
        # If still over limit, remove lowest intensity emotions
        if len(self._emotions) >= self._max_emotions:
            sorted_emotions = sorted(
                self._emotions.items(),
                key=lambda x: x[1].intensity
            )
            for name, _ in sorted_emotions[:len(self._emotions) - self._max_emotions]:
                del self._emotions[name]
    
    async def _update_emotional_states(self) -> None:
        """Update emotional states based on time decay."""
        current_time = datetime.now()
        for emotion in self._emotions.values():
            time_diff = (current_time - emotion.last_updated).total_seconds()
            decay_factor = self._decay_rate * time_diff / emotion.duration
            emotion.update_intensity(max(0.0, emotion.intensity - decay_factor))
        
        await self._prune_emotions()
        await self._save_emotions()
    
    async def _process_memories(self, context: dict) -> None:
        """Process memories to trigger emotions."""
        if "recent_memories" not in context:
            return
        
        for memory in context["recent_memories"]:
            # Simple emotion detection based on keywords
            content = memory["content"].lower()
            
            # Check for positive emotions
            if any(word in content for word in ["happy", "joy", "excited", "great"]):
                await self._trigger_emotion("happy", 0.8, memory["content"])
            
            # Check for negative emotions
            if any(word in content for word in ["sad", "angry", "upset", "terrible"]):
                await self._trigger_emotion("sad", 0.8, memory["content"])
            
            # Check for surprise
            if any(word in content for word in ["wow", "surprise", "amazing", "unexpected"]):
                await self._trigger_emotion("surprised", 0.7, memory["content"])
            
            # Check for fear
            if any(word in content for word in ["scared", "afraid", "fear", "worried"]):
                await self._trigger_emotion("afraid", 0.7, memory["content"])
    
    async def _process_goals(self, context: dict) -> None:
        """Process goals to trigger emotions."""
        if "goals" not in context:
            return
        
        for goal in context["goals"]:
            # Trigger emotions based on goal progress
            progress = goal.get("progress", 0)
            if progress > 0.8:
                await self._trigger_emotion("satisfied", 0.7, f"Goal progress: {goal['description']}")
            elif progress < 0.2:
                await self._trigger_emotion("frustrated", 0.6, f"Goal progress: {goal['description']}")
            elif progress > 0.5:
                await self._trigger_emotion("hopeful", 0.5, f"Goal progress: {goal['description']}")
    
    async def get_current_mood(self) -> float:
        """Calculate current mood based on active emotions."""
        if not self._emotions:
            return 0.0
        
        # Weight emotions by intensity and recency
        current_time = datetime.now()
        total_weight = 0.0
        mood_sum = 0.0
        
        for emotion in self._emotions.values():
            # Calculate time weight (more recent = higher weight)
            time_weight = 1.0 - (current_time - emotion.last_updated).total_seconds() / emotion.duration
            time_weight = max(0.0, time_weight)
            
            # Calculate emotion weight
            weight = emotion.intensity * time_weight
            total_weight += weight
            
            # Add to mood sum (positive emotions increase mood, negative decrease)
            if emotion.name in ["happy", "satisfied", "excited", "hopeful"]:
                mood_sum += weight
            elif emotion.name in ["sad", "angry", "frustrated", "afraid"]:
                mood_sum -= weight
        
        return mood_sum / total_weight if total_weight > 0 else 0.0
    
    async def get_emotional_response(self, context: dict) -> str:
        """Generate emotional response based on current state."""
        mood = await self.get_current_mood()
        
        if mood > 0.5:
            return "I'm feeling quite positive about this."
        elif mood < -0.5:
            return "I'm feeling a bit down about this."
        else:
            return "I'm feeling neutral about this."
    
    async def get_state(self) -> dict:
        """Get emotion system state."""
        return {
            "max_emotions": self._max_emotions,
            "emotions": [e.to_dict() for e in self._emotions.values()],
            "emotion_history": [e.to_dict() for e in self._emotion_history],
            "current_mood": await self.get_current_mood()
        }
    
    async def get_metrics(self) -> dict:
        """Get emotion system metrics."""
        return {
            "total_emotions": len(self._emotions),
            "emotion_history": len(self._emotion_history),
            "current_mood": await self.get_current_mood()
        }
    
    async def update(self, context: dict) -> None:
        """Update emotion system with new context."""
        try:
            if "user_input" in context:
                await self._process_user_input(context["user_input"])
            if "goals" in context:
                await self._process_goals(context["goals"])
            if "memory" in context:
                await self._process_memories(context["memory"])
            await self._update_emotional_states()
        except Exception as e:
            logger.error(f"Error updating emotion system: {e}")
    
    async def _process_user_input(self, user_input: str) -> None:
        """Process user input to trigger emotions."""
        try:
            # Simple emotion detection based on keywords
            content = user_input.lower()
            
            # Check for positive emotions
            if any(word in content for word in ["happy", "joy", "excited", "great"]):
                await self._trigger_emotion("happy", 0.8, user_input)
            
            # Check for negative emotions
            if any(word in content for word in ["sad", "angry", "upset", "terrible"]):
                await self._trigger_emotion("sad", 0.8, user_input)
            
            # Check for surprise
            if any(word in content for word in ["wow", "surprise", "amazing", "unexpected"]):
                await self._trigger_emotion("surprised", 0.7, user_input)
            
            # Check for fear
            if any(word in content for word in ["scared", "afraid", "fear", "worried"]):
                await self._trigger_emotion("afraid", 0.7, user_input)
        except Exception as e:
            logger.error(f"Error processing user input: {e}")

    async def save_state(self) -> bool:
        """Save emotion system state to disk."""
        try:
            state = await self.get_state()
            os.makedirs(self.storage_dir, exist_ok=True)
            async with aiofiles.open(self.storage_dir / "emotion_state.json", "w") as f:
                await f.write(json.dumps(state, default=str))
            return True
        except Exception as e:
            logger.error(f"Error saving emotion state: {e}")
            return False

    async def load_state(self) -> bool:
        """Load emotion system state from disk."""
        try:
            state_file = self.storage_dir / "emotion_state.json"
            if not state_file.exists():
                return False
            
            async with aiofiles.open(state_file, "r") as f:
                state = json.loads(await f.read())
            
            # Clear existing emotions
            self._emotions.clear()
            self._emotion_history.clear()
            
            # Load emotions
            for emotion_data in state.get("emotions", []):
                emotion = Emotion.from_dict(emotion_data)
                self._emotions[emotion.name] = emotion
                self._emotion_history.append(emotion)
            
            return True
        except Exception as e:
            logger.error(f"Error loading emotion state: {e}")
            return False

    async def get_emotion_by_name(self, name: str) -> Optional[Emotion]:
        """Get emotion by name."""
        return self._emotions.get(name)

    async def get_active_emotions(self) -> List[Emotion]:
        """Get list of active emotions."""
        return list(self._emotions.values())

    async def get_emotion_history(self) -> List[Emotion]:
        """Get emotion history."""
        return self._emotion_history

    async def clear_emotions(self) -> None:
        """Clear all emotions."""
        self._emotions.clear()
        self._emotion_history.clear()
        await self._save_emotions() 
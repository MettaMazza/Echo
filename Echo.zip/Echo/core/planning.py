"""
Planning subsystem for the Echo cognitive agent.
"""
from typing import Dict, Any, List, Optional, Set
from core.interfaces import CognitiveSubsystem
from datetime import datetime, timedelta
import math
from dataclasses import dataclass, field
import json
from pathlib import Path
import threading
import structlog

logger = structlog.get_logger(__name__)

@dataclass
class Task:
    """Represents a single task with priority and dependencies."""
    description: str
    priority: float
    status: str = "pending"
    progress: float = 0.0
    deadline: Optional[datetime] = None
    dependencies: Set[str] = None
    subtasks: List['Task'] = None
    resources: List[str] = None
    created_at: datetime = None
    last_updated: datetime = None
    
    def __post_init__(self):
        """Initialize task attributes."""
        if self.dependencies is None:
            self.dependencies = set()
        if self.subtasks is None:
            self.subtasks = []
        if self.resources is None:
            self.resources = []
        if self.created_at is None:
            self.created_at = datetime.now()
        if self.last_updated is None:
            self.last_updated = self.created_at
    
    def update_priority(self, new_priority: float) -> None:
        """Update task priority."""
        self.priority = max(0.0, min(1.0, new_priority))
        self.last_updated = datetime.now()
    
    def update_progress(self, new_progress: float) -> None:
        """Update task progress."""
        self.progress = max(0.0, min(1.0, new_progress))
        self.last_updated = datetime.now()
        
        # Update status based on progress
        if self.progress >= 1.0:
            self.status = "completed"
        elif self.progress > 0.0:
            self.status = "in_progress"
    
    def add_dependency(self, task_id: str) -> None:
        """Add a task dependency."""
        self.dependencies.add(task_id)
        self.last_updated = datetime.now()
    
    def add_subtask(self, subtask: 'Task') -> None:
        """Add a subtask."""
        self.subtasks.append(subtask)
        self.last_updated = datetime.now()
    
    def add_resource(self, resource: str) -> None:
        """Add a required resource."""
        if resource not in self.resources:
            self.resources.append(resource)
            self.last_updated = datetime.now()
    
    def is_blocked(self, completed_tasks: Set[str]) -> bool:
        """Check if this task is blocked by dependencies."""
        return not self.dependencies.issubset(completed_tasks)
    
    def is_overdue(self) -> bool:
        """Check if this task is past its deadline."""
        if not self.deadline:
            return False
        return datetime.now() > self.deadline
    
    def get_urgency(self) -> float:
        """Calculate task urgency based on deadline and priority."""
        if not self.deadline:
            return self.priority
        
        time_remaining = (self.deadline - datetime.now()).total_seconds()
        if time_remaining <= 0:
            return 1.0  # Maximum urgency for overdue tasks
        
        # Calculate urgency based on time remaining
        hours_remaining = time_remaining / 3600
        if hours_remaining <= 24:  # Within 24 hours
            urgency = 1.0 - (hours_remaining / 24)
            return max(self.priority, urgency)
        
        return self.priority
    
    def to_dict(self) -> dict:
        """Convert task to dictionary."""
        return {
            "description": self.description,
            "priority": self.priority,
            "status": self.status,
            "progress": self.progress,
            "deadline": self.deadline.isoformat() if self.deadline else None,
            "dependencies": list(self.dependencies),
            "subtasks": [subtask.to_dict() for subtask in self.subtasks],
            "resources": self.resources,
            "created_at": self.created_at.isoformat(),
            "last_updated": self.last_updated.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'Task':
        """Create task from dictionary."""
        task = cls(
            description=data["description"],
            priority=float(data["priority"]),
            status=data["status"],
            progress=float(data["progress"]),
            deadline=datetime.fromisoformat(data["deadline"]) if data["deadline"] else None,
            dependencies=set(data["dependencies"]),
            subtasks=[cls.from_dict(subtask) for subtask in data["subtasks"]],
            resources=data["resources"],
            created_at=datetime.fromisoformat(data["created_at"]),
            last_updated=datetime.fromisoformat(data["last_updated"])
        )
        return task

class PlanningSystem(CognitiveSubsystem):
    """Manages the agent's task planning and execution."""
    
    def __init__(self, storage_dir: str = "planning"):
        """Initialize planning system."""
        self.storage_dir = Path(storage_dir)
        self._tasks: Dict[str, Task] = {}
        self._completed_tasks: Set[str] = set()
        self._failed_tasks: Set[str] = set()
        self._lock = threading.Lock()
        self._max_tasks = 1000
        
        # Create storage directory
        self._init_storage()
    
    def _init_storage(self):
        """Initialize storage directory."""
        self.storage_dir.mkdir(exist_ok=True)
        
        # Load existing tasks
        self._load_tasks()
    
    def _load_tasks(self):
        """Load tasks from storage."""
        try:
            task_file = self.storage_dir / "tasks.json"
            if task_file.exists():
                with open(task_file) as f:
                    data = json.load(f)
                    self._tasks = {
                        description: Task.from_dict(task_data)
                        for description, task_data in data["tasks"].items()
                    }
                    self._completed_tasks = set(data["completed_tasks"])
                    self._failed_tasks = set(data["failed_tasks"])
        except Exception as e:
            logger.error(f"Error loading tasks: {e}")
            self._tasks = {}
            self._completed_tasks = set()
            self._failed_tasks = set()
    
    def _save_tasks(self):
        """Save tasks to storage."""
        try:
            task_file = self.storage_dir / "tasks.json"
            with open(task_file, 'w') as f:
                json.dump({
                    "tasks": {
                        description: task.to_dict()
                        for description, task in self._tasks.items()
                    },
                    "completed_tasks": list(self._completed_tasks),
                    "failed_tasks": list(self._failed_tasks)
                }, f)
        except Exception as e:
            logger.error(f"Error saving tasks: {e}")
    
    def _create_task(self, description: str, priority: float = 0.5) -> Task:
        """Create a new task."""
        with self._lock:
            # Check for task overflow
            if len(self._tasks) >= self._max_tasks:
                self._prune_tasks()
            
            # Create new task
            task = Task(
                description=description,
                priority=priority
            )
            
            # Add to tasks
            self._tasks[description] = task
            
            # Save changes
            self._save_tasks()
            
            return task
    
    def _update_task_states(self) -> None:
        """Update states of existing tasks."""
        with self._lock:
            current_time = datetime.now()
            
            for task in self._tasks.values():
                # Check for overdue tasks
                if task.is_overdue():
                    task.status = "failed"
                    self._failed_tasks.add(task.description)
                    continue
                
                # Update priority based on deadline and progress
                if task.deadline:
                    # Calculate time-based urgency
                    time_remaining = (task.deadline - current_time).total_seconds()
                    if time_remaining <= 0:
                        task.update_priority(1.0)  # Maximum priority for overdue tasks
                    elif time_remaining <= 86400:  # Within 24 hours
                        urgency = 1.0 - (time_remaining / 86400)
                        task.update_priority(max(task.priority, urgency))
                
                # Update status based on progress
                if task.progress >= 1.0:
                    task.status = "completed"
                    self._completed_tasks.add(task.description)
                elif task.progress > 0.0:
                    task.status = "in_progress"
            
            # Save changes
            self._save_tasks()
    
    def _prune_tasks(self) -> None:
        """Remove completed and failed tasks."""
        with self._lock:
            current_tasks = {}
            for description, task in self._tasks.items():
                # Keep only active tasks
                if task.status not in ["completed", "failed"]:
                    current_tasks[description] = task
                else:
                    # Add to appropriate set
                    if task.status == "completed":
                        self._completed_tasks.add(description)
                    else:
                        self._failed_tasks.add(description)
            
            self._tasks = current_tasks
            self._save_tasks()
    
    def get_next_task(self) -> Optional[Task]:
        """Get the next task to execute based on priority and dependencies."""
        with self._lock:
            available_tasks = [
                task for task in self._tasks.values()
                if task.status == "pending" and not task.is_blocked(self._completed_tasks)
            ]
            
            if not available_tasks:
                return None
            
            # Sort by urgency and priority
            return max(
                available_tasks,
                key=lambda x: (x.get_urgency(), x.priority)
            )
    
    def _process_user_input(self, user_input: str) -> None:
        """Process user input for task creation."""
        try:
            # Simple task detection from keywords
            task_keywords = ["task", "todo", "need to", "should", "must"]
            if any(keyword in user_input.lower() for keyword in task_keywords):
                # Extract task description
                description = user_input.strip()
                if description.endswith("."):
                    description = description[:-1]
                
                # Create new task
                self._create_task(description, 0.7)
        except Exception as e:
            logger.error(f"Error processing user input: {e}")
    
    def _process_goals(self, goals: Dict[str, Any]) -> None:
        """Process goals for task creation."""
        try:
            active_goals = goals.get("active_goals", [])
            for goal in active_goals:
                # Create task from goal
                description = goal.get("description", "")
                priority = goal.get("priority", 0.5)
                
                # Check if task already exists
                if not any(task.description == description for task in self._tasks.values()):
                    self._create_task(description, priority)
        except Exception as e:
            logger.error(f"Error processing goals: {e}")
    
    def _process_memories(self, memory: Dict[str, Any]) -> None:
        """Process memories for task updates."""
        try:
            recent_memories = memory.get("recent_memories", [])
            for mem in recent_memories:
                # Update task progress based on memory content
                for task in self._tasks.values():
                    if task.description.lower() in mem.get("content", "").lower():
                        if "completed" in mem.get("content", "").lower():
                            task.update_progress(1.0)
                        elif "progress" in mem.get("content", "").lower():
                            task.update_progress(0.5)
        except Exception as e:
            logger.error(f"Error processing memories: {e}")
    
    def get_state(self) -> dict:
        """Get current state of the planning system."""
        with self._lock:
            return {
                "tasks": [task.to_dict() for task in self._tasks.values()],
                "completed_tasks": list(self._completed_tasks),
                "failed_tasks": list(self._failed_tasks),
                "total_tasks": len(self._tasks),
                "max_tasks": self._max_tasks,
                "last_update": datetime.now().isoformat()
            }
    
    def get_metrics(self) -> dict:
        """Get planning system metrics."""
        with self._lock:
            return {
                "total_tasks": len(self._tasks),
                "completed_tasks": len(self._completed_tasks),
                "failed_tasks": len(self._failed_tasks),
                "active_tasks": sum(1 for task in self._tasks.values() if task.status == "in_progress")
            }
    
    def update(self, context: dict) -> None:
        """Update planning system with new context."""
        try:
            if "user_input" in context:
                self._process_user_input(context["user_input"])
            if "goals" in context:
                self._process_goals(context["goals"])
            if "memory" in context:
                self._process_memories(context["memory"])
            self._update_task_states()
            self._prune_tasks()
        except Exception as e:
            logger.error(f"Error updating planning system: {e}")
    
    def cleanup(self) -> None:
        """Clean up planning system resources."""
        with self._lock:
            # Save current state
            self._save_tasks()
            
            # Clear tasks
            self._tasks = {}
            self._completed_tasks = set()
            self._failed_tasks = set()

@dataclass
class Action:
    """Represents a single action in a plan."""
    name: str
    description: str
    preconditions: List[str]
    effects: List[str]
    duration: float  # in seconds
    cost: float
    priority: float = 0.5
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary.
        
        Returns:
            Dictionary representation
        """
        return {
            'name': self.name,
            'description': self.description,
            'preconditions': self.preconditions,
            'effects': self.effects,
            'duration': self.duration,
            'cost': self.cost,
            'priority': self.priority
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Action':
        """Create from dictionary.
        
        Args:
            data: Dictionary representation
            
        Returns:
            Action instance
        """
        return cls(**data)

class PlanningReasoningSystem(CognitiveSubsystem):
    """System for planning and reasoning about actions."""
    
    def __init__(self):
        """Initialize planning reasoning system."""
        self._actions: Dict[str, Action] = {}
        self._current_plan: List[Action] = []
        self._plan_history: List[List[Action]] = []
        self._max_history = 50
        self._state: Dict[str, Any] = {}
    
    def add_action(self, action: Action) -> None:
        """Add an action to the system.
        
        Args:
            action: Action to add
        """
        self._actions[action.name] = action
    
    def remove_action(self, action_name: str) -> None:
        """Remove an action from the system.
        
        Args:
            action_name: Name of action to remove
        """
        if action_name in self._actions:
            del self._actions[action_name]
    
    def get_action(self, action_name: str) -> Optional[Action]:
        """Get an action by name.
        
        Args:
            action_name: Name of action
            
        Returns:
            Action if found, None otherwise
        """
        return self._actions.get(action_name)
    
    def create_plan(self, goal: str, initial_state: Dict[str, Any]) -> List[Action]:
        """Create a plan to achieve a goal.
        
        Args:
            goal: Goal to achieve
            initial_state: Initial state
            
        Returns:
            List of actions to achieve goal
        """
        self._state = initial_state.copy()
        self._current_plan = []
        
        # Simple forward search planning
        while not self._is_goal_achieved(goal):
            # Find applicable actions
            applicable_actions = [
                action for action in self._actions.values()
                if self._are_preconditions_met(action)
            ]
            
            if not applicable_actions:
                raise ValueError(f"No applicable actions found for goal: {goal}")
            
            # Select best action
            best_action = max(
                applicable_actions,
                key=lambda x: (x.priority, -x.cost)
            )
            
            # Apply action
            self._apply_action(best_action)
            self._current_plan.append(best_action)
        
        # Save plan to history
        self._plan_history.append(self._current_plan.copy())
        if len(self._plan_history) > self._max_history:
            self._plan_history.pop(0)
        
        return self._current_plan
    
    def update(self, context: Dict[str, Any]) -> None:
        """Update planning reasoning system based on context.
        
        Args:
            context: Current context
        """
        # Update state based on context
        if 'state' in context:
            self._state.update(context['state'])
        
        # Update actions based on context
        if 'new_actions' in context:
            for action_data in context['new_actions']:
                action = Action.from_dict(action_data)
                self.add_action(action)
    
    def get_state(self) -> Dict[str, Any]:
        """Get current state.
        
        Returns:
            Current state
        """
        return {
            'action_count': len(self._actions),
            'current_plan': [action.to_dict() for action in self._current_plan],
            'plan_history': [
                [action.to_dict() for action in plan]
                for plan in self._plan_history
            ],
            'state': self._state
        }
    
    def _is_goal_achieved(self, goal: str) -> bool:
        """Check if goal is achieved in current state.
        
        Args:
            goal: Goal to check
            
        Returns:
            True if goal is achieved, False otherwise
        """
        return goal in self._state.get('achieved_goals', [])
    
    def _are_preconditions_met(self, action: Action) -> bool:
        """Check if action preconditions are met.
        
        Args:
            action: Action to check
            
        Returns:
            True if preconditions are met, False otherwise
        """
        return all(
            precondition in self._state.get('achieved_goals', [])
            for precondition in action.preconditions
        )
    
    def _apply_action(self, action: Action) -> None:
        """Apply action effects to current state.
        
        Args:
            action: Action to apply
        """
        achieved_goals = self._state.setdefault('achieved_goals', [])
        achieved_goals.extend(action.effects) 
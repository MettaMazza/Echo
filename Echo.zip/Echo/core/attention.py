"""
Attention subsystem for the Echo cognitive agent.
"""
from typing import Dict, Any, List, Optional, Set
from core.interfaces import CognitiveSubsystem
from datetime import datetime, timedelta
import math

class AttentionFocus:
    """Represents a focus of attention."""
    
    def __init__(self,
                 target: str,
                 target_type: str,
                 importance: float = 0.5,
                 duration: Optional[timedelta] = None):
        self.target = target  # What is being focused on
        self.target_type = target_type  # e.g., "memory", "task", "emotion"
        self.importance = max(0.0, min(1.0, importance))
        self.created_at = datetime.now()
        self.last_updated = datetime.now()
        self.duration = duration
        self.intensity = 1.0  # Current focus intensity
        self.context: Dict[str, Any] = {}
        self.related_foci: Set[str] = set()
        self.distractions: Set[str] = set()
    
    def update_intensity(self, new_intensity: float) -> None:
        """Update focus intensity."""
        self.intensity = max(0.0, min(1.0, new_intensity))
        self.last_updated = datetime.now()
    
    def add_context(self, key: str, value: Any) -> None:
        """Add context information."""
        self.context[key] = value
    
    def add_related_focus(self, focus_id: str) -> None:
        """Add a related focus."""
        self.related_foci.add(focus_id)
    
    def add_distraction(self, distraction_id: str) -> None:
        """Add a distraction."""
        self.distractions.add(distraction_id)
    
    def is_expired(self) -> bool:
        """Check if focus has expired."""
        if self.duration is None:
            return False
        return datetime.now() - self.created_at > self.duration

class AttentionSystem(CognitiveSubsystem):
    """Manages the agent's attention and focus."""
    
    def __init__(self):
        self._foci: Dict[str, AttentionFocus] = {}  # focus_id -> focus
        self._last_update = datetime.now()
        self._focus_history: List[Dict[str, Any]] = []
        self._max_history = 100
        self._max_concurrent_foci = 3
        self._focus_types = {
            "memory": "Focus on specific memories",
            "task": "Focus on current tasks",
            "emotion": "Focus on emotional states",
            "input": "Focus on user input",
            "goal": "Focus on goals"
        }
        self._config = None
        self._attention_threshold = 0.1
    
    async def initialize(self, config: Optional[Dict[str, Any]] = None) -> None:
        """Initialize the attention system with configuration.
        
        Args:
            config: Optional configuration dictionary containing:
                   - max_concurrent_foci: Maximum number of concurrent foci
                   - max_history: Maximum number of focus history entries
                   - focus_types: Dictionary of focus types and descriptions
                   - max_focus_areas: Alias for max_concurrent_foci
                   - attention_threshold: Minimum threshold for attention
        """
        if config:
            self._config = config
            if "max_concurrent_foci" in config:
                self._max_concurrent_foci = config["max_concurrent_foci"]
            if "max_history" in config:
                self._max_history = config["max_history"]
            if "focus_types" in config:
                self._focus_types.update(config["focus_types"])
            # Accept test config keys
            if "max_focus_areas" in config:
                if not isinstance(config["max_focus_areas"], int) or config["max_focus_areas"] is None or config["max_focus_areas"] <= 0:
                    raise ValueError("max_focus_areas must be a positive integer")
                self._max_concurrent_foci = config["max_focus_areas"]
            if "attention_threshold" in config:
                if not isinstance(config["attention_threshold"], (int, float)) or config["attention_threshold"] < 0:
                    raise ValueError("attention_threshold must be a non-negative number")
                self._attention_threshold = config["attention_threshold"]
        # Validate configuration
        if not isinstance(self._max_concurrent_foci, int) or self._max_concurrent_foci <= 0:
            raise ValueError("max_concurrent_foci must be a positive integer")
        if self._max_history <= 0:
            raise ValueError("max_history must be positive")
        if not self._focus_types:
            raise ValueError("focus_types cannot be empty")
    
    async def update(self, context: Dict[str, Any]) -> None:
        """Update attention system based on context.
        
        Args:
            context: Dictionary containing current context including:
                    - user_input: The user's message
                    - memory: Relevant memories
                    - emotions: Current emotions
                    - tasks: Current tasks
                    - goals: Current goals
        """
        # Process new information
        if "user_input" in context:
            await self._process_user_input(context["user_input"])
        
        if "memory" in context:
            await self._process_memories(context["memory"])
        
        if "emotions" in context:
            await self._process_emotions(context["emotions"])
        
        if "tasks" in context:
            await self._process_tasks(context["tasks"])
        
        if "goals" in context:
            await self._process_goals(context["goals"])
        
        # Update focus states
        await self._update_focus_states()
        
        # Prune expired foci
        await self._prune_foci()
    
    async def get_state(self) -> Dict[str, Any]:
        """Get current attention state.
        
        Returns:
            Dictionary containing current foci and metrics.
        """
        foci = {
            focus_id: {
                "target": focus.target,
                "type": focus.target_type,
                "importance": focus.importance,
                "intensity": focus.intensity,
                "context": focus.context,
                "related_foci": list(focus.related_foci),
                "distractions": list(focus.distractions),
                "created_at": focus.created_at.isoformat(),
                "last_updated": focus.last_updated.isoformat()
            }
            for focus_id, focus in self._foci.items()
        }
        
        return {
            "foci": foci,
            "focus_history": self._focus_history,
            "total_foci": len(self._foci),
            "active_foci": len([f for f in self._foci.values() if f.intensity > 0]),
            "max_focus_areas": getattr(self, '_max_concurrent_foci', 3),
            "focus_areas": list(foci.keys()),
        }
    
    async def _process_user_input(self, user_input: str) -> None:
        """Process user input for attention focus."""
        # Create focus on user input
        await self._create_focus(
            target=user_input,
            target_type="input",
            importance=0.8
        )
    
    async def _process_memories(self, memory: Dict[str, Any]) -> None:
        """Process memories for attention focus."""
        recent_memories = memory.get("recent_memories", [])
        for mem in recent_memories:
            # Create focus on important memories
            if mem.get("importance", 0) > 0.7:
                await self._create_focus(
                    target=mem.get("content", ""),
                    target_type="memory",
                    importance=mem.get("importance", 0.5)
                )
    
    async def _process_emotions(self, emotions: Dict[str, Any]) -> None:
        """Process emotions for attention focus."""
        for emotion, intensity in emotions.items():
            # Create focus on strong emotions
            if intensity > 0.7:
                await self._create_focus(
                    target=emotion,
                    target_type="emotion",
                    importance=intensity
                )
    
    async def _process_tasks(self, tasks: Dict[str, Any]) -> None:
        """Process tasks for attention focus."""
        for task_id, task in tasks.items():
            # Create focus on high-priority tasks
            if task.get("priority", 0) > 0.7:
                await self._create_focus(
                    target=task.get("description", ""),
                    target_type="task",
                    importance=task.get("priority", 0.5)
                )
    
    async def _process_goals(self, goals: Dict[str, Any]) -> None:
        """Process goals for attention focus."""
        for goal_id, goal in goals.items():
            # Create focus on active goals
            if goal.get("status") == "active":
                await self._create_focus(
                    target=goal.get("description", ""),
                    target_type="goal",
                    importance=0.8
                )
    
    async def _update_focus_states(self) -> None:
        """Update states of existing foci."""
        current_time = datetime.now()
        
        # Calculate total attention capacity
        total_attention = sum(focus.intensity for focus in self._foci.values())
        
        # Adjust intensities if over capacity
        if total_attention > self._max_concurrent_foci:
            scale_factor = self._max_concurrent_foci / total_attention
            for focus in self._foci.values():
                focus.update_intensity(focus.intensity * scale_factor)
        
        # Update focus intensities based on importance and time
        for focus in self._foci.values():
            if not focus.is_expired():
                # Decay intensity over time
                time_factor = math.exp(-(current_time - focus.last_updated).total_seconds() / 3600)
                new_intensity = focus.importance * time_factor
                focus.update_intensity(new_intensity)
    
    async def _prune_foci(self) -> None:
        """Remove expired or low-intensity foci."""
        current_foci = {}
        for focus_id, focus in self._foci.items():
            # Keep only active and non-expired foci
            if not focus.is_expired() and focus.intensity > self._attention_threshold:
                current_foci[focus_id] = focus
        
        self._foci = current_foci
    
    async def _create_focus(self,
                     target: str,
                     target_type: str,
                     importance: float = 0.5,
                     duration: Optional[timedelta] = None) -> str:
        """Create a new attention focus.
        
        Args:
            target: What to focus on
            target_type: Type of focus (e.g., "memory", "task")
            importance: Importance of the focus (0-1)
            duration: Optional duration for the focus
            
        Returns:
            ID of the created focus
        """
        # Create new focus
        focus = AttentionFocus(
            target=target,
            target_type=target_type,
            importance=importance,
            duration=duration
        )
        
        # Generate focus ID
        focus_id = f"{target_type}_{len(self._foci)}"
        
        # Add to foci
        self._foci[focus_id] = focus
        
        # Add to history
        self._focus_history.append({
            "id": focus_id,
            "target": target,
            "type": target_type,
            "importance": importance,
            "created_at": focus.created_at.isoformat()
        })
        
        # Limit history size
        if len(self._focus_history) > self._max_history:
            self._focus_history = self._focus_history[-self._max_history:]
        
        return focus_id
    
    def get_focus(self, focus_id: str) -> Optional[AttentionFocus]:
        """Get a focus by ID."""
        return self._foci.get(focus_id)
    
    def get_foci_by_type(self, focus_type: str) -> List[AttentionFocus]:
        """Get all foci of a specific type."""
        return [f for f in self._foci.values() if f.target_type == focus_type]
    
    def get_related_foci(self, focus_id: str) -> List[AttentionFocus]:
        """Get foci related to a specific focus."""
        focus = self.get_focus(focus_id)
        if not focus:
            return []
        return [self.get_focus(fid) for fid in focus.related_foci if self.get_focus(fid)]
    
    def get_active_foci(self) -> List[AttentionFocus]:
        """Get all active foci."""
        return [f for f in self._foci.values() if f.intensity > self._attention_threshold] 
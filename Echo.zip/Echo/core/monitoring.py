"""
Monitoring and alerting system for Echo cognitive agent.
"""
import os
import json
import time
import psutil
import structlog
from datetime import datetime
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field
from pathlib import Path
import asyncio
from concurrent.futures import ThreadPoolExecutor
import aiohttp
import prometheus_client
from prometheus_client import Counter, Gauge, Histogram

# Configure structured logging
structlog.configure(
    processors=[
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.JSONRenderer()
    ]
)
logger = structlog.get_logger(__name__)

# Prometheus metrics
REQUEST_COUNT = Counter('echo_requests_total', 'Total number of requests')
RESPONSE_TIME = Histogram('echo_response_time_seconds', 'Response time in seconds')
MEMORY_USAGE = Gauge('echo_memory_usage_bytes', 'Memory usage in bytes')
ERROR_COUNT = Counter('echo_errors_total', 'Total number of errors')
SUBSYSTEM_HEALTH = Gauge('echo_subsystem_health', 'Health status of subsystems', ['subsystem'])

@dataclass
class Alert:
    """Represents a system alert."""
    level: str  # 'info', 'warning', 'error', 'critical'
    message: str
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert alert to dictionary."""
        return {
            "level": self.level,
            "message": self.message,
            "timestamp": self.timestamp.isoformat(),
            "metadata": self.metadata
        }

@dataclass
class SystemMetrics:
    """System-wide metrics for monitoring."""
    timestamp: float = field(default_factory=time.time)
    cpu_usage: float = 0.0
    memory_usage: float = 0.0
    active_threads: int = 0
    request_count: int = 0
    error_count: int = 0
    average_response_time: float = 0.0
    subsystem_metrics: Dict[str, Dict[str, float]] = field(default_factory=dict)
    conversation_stats: dict = field(default_factory=lambda: {"total_turns": 0})
    error_counts: dict = field(default_factory=dict)
    memory_usage: list = field(default_factory=list)
    response_times: list = field(default_factory=list)
    subsystem_performance: dict = field(default_factory=dict)
    
    def update(self, metrics: Dict[str, Any]) -> None:
        """Update metrics with new values.
        
        Args:
            metrics: Dictionary containing new metric values
        """
        self.timestamp = time.time()
        self.cpu_usage = metrics.get('cpu_usage', self.cpu_usage)
        self.memory_usage = metrics.get('memory_usage', self.memory_usage)
        self.active_threads = metrics.get('active_threads', self.active_threads)
        self.request_count = metrics.get('request_count', self.request_count)
        self.error_count = metrics.get('error_count', self.error_count)
        self.average_response_time = metrics.get('average_response_time', self.average_response_time)
        
        # Update subsystem metrics
        if 'subsystem_metrics' in metrics:
            self.subsystem_metrics.update(metrics['subsystem_metrics'])
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert metrics to dictionary.
        
        Returns:
            Dictionary containing all metrics
        """
        return {
            'timestamp': self.timestamp,
            'cpu_usage': self.cpu_usage,
            'memory_usage': self.memory_usage,
            'active_threads': self.active_threads,
            'request_count': self.request_count,
            'error_count': self.error_count,
            'average_response_time': self.average_response_time,
            'subsystem_metrics': self.subsystem_metrics
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SystemMetrics':
        """Create metrics from dictionary.
        
        Args:
            data: Dictionary containing metric values
            
        Returns:
            New SystemMetrics instance
        """
        return cls(**data)
    
    def increment_turn_count(self):
        self.conversation_stats["total_turns"] += 1
    def record_error(self, error):
        self.error_counts[error] = self.error_counts.get(error, 0) + 1
    def record_memory_usage(self, usage):
        self.memory_usage.append(usage)
    def record_response_time(self, time):
        self.response_times.append(time)
    def record_subsystem_performance(self, subsystem, value):
        if subsystem not in self.subsystem_performance:
            self.subsystem_performance[subsystem] = []
        self.subsystem_performance[subsystem].append(value)
    def get_metrics(self):
        error_rate = (sum(self.error_counts.values()) / self.conversation_stats["total_turns"]) if self.conversation_stats["total_turns"] else 0.0
        avg_resp = (sum(self.response_times) / len(self.response_times)) if self.response_times else 0.0
        stats = {
            "conversation_stats": {
                **self.conversation_stats,
                "error_rate": error_rate,
                "average_response_time": avg_resp
            },
            "error_counts": self.error_counts,
            "memory_usage": self.memory_usage,
            "response_times": self.response_times,
            "subsystem_performance": self.subsystem_performance,
            **self.to_dict()
        }
        return stats

class SystemMonitor:
    """Monitors system health and performance."""
    
    def __init__(
        self,
        log_level: str = "INFO",
        log_dir: str = "logs",
        alert_webhook: Optional[str] = None,
        metrics_port: int = 9090
    ):
        """Initialize system monitor."""
        self.log_level = log_level
        self.log_dir = Path(log_dir)
        self.alert_webhook = alert_webhook
        self.metrics_port = metrics_port
        self.start_time = time.time()
        
        # Create log directory
        self.log_dir.mkdir(exist_ok=True)
        
        # Initialize metrics
        self.metrics = SystemMetrics()
        
        # Initialize alert history
        self.alerts: List[Alert] = []
        
        # Initialize thread pool
        self.executor = ThreadPoolExecutor(max_workers=4)
        
        # Start metrics server
        prometheus_client.start_http_server(self.metrics_port)
        
        logger.info("monitor_initialized",
            log_level=log_level,
            log_dir=str(log_dir),
            metrics_port=metrics_port
        )
    
    def record_request(self) -> None:
        """Record a new request."""
        self.metrics.request_count += 1
        REQUEST_COUNT.inc()
    
    def record_error(self, error: str) -> None:
        """Record an error."""
        self.metrics.error_count += 1
        ERROR_COUNT.inc()
        
        # Create alert
        alert = Alert(
            level="error",
            message=f"System error: {error}",
            metadata={"error": error}
        )
        self.alerts.append(alert)
        
        # Log error
        logger.error("system_error",
            error=error,
            alert=alert.to_dict()
        )
        
        # Send alert if webhook configured
        if self.alert_webhook:
            asyncio.create_task(self._send_alert(alert))
    
    def update_subsystem_health(self, subsystem: str, health: float) -> None:
        """Update subsystem health status."""
        self.metrics.subsystem_metrics[subsystem] = health
        SUBSYSTEM_HEALTH.labels(subsystem=subsystem).set(health)
        
        # Create alert if health is low
        if health < 0.5:
            alert = Alert(
                level="warning",
                message=f"Subsystem {subsystem} health is low: {health}",
                metadata={"subsystem": subsystem, "health": health}
            )
            self.alerts.append(alert)
            
            logger.warning("subsystem_health_low",
                subsystem=subsystem,
                health=health,
                alert=alert.to_dict()
            )
            
            # Send alert if webhook configured
            if self.alert_webhook:
                asyncio.create_task(self._send_alert(alert))
    
    def get_system_health(self) -> Dict[str, Any]:
        """Get current system health status."""
        # Update memory usage
        process = psutil.Process(os.getpid())
        memory_usage = process.memory_info().rss / 1024 / 1024  # MB
        self.metrics.memory_usage = memory_usage
        MEMORY_USAGE.set(memory_usage)
        
        # Calculate overall health
        health = 1.0
        if self.metrics.error_count > 0:
            health *= 0.8
        if memory_usage > 1000:  # More than 1GB
            health *= 0.9
        if self.metrics.average_response_time > 1.0:  # More than 1 second
            health *= 0.9
        
        # Update subsystem health
        for subsystem, subsystem_health in self.metrics.subsystem_metrics.items():
            health *= subsystem_health
        
        return {
            "status": "healthy" if health > 0.7 else "degraded" if health > 0.3 else "critical",
            "health": health,
            "memory_usage": memory_usage,
            "avg_response_time": self.metrics.average_response_time,
            "error_rate": self.metrics.error_count / max(1, self.metrics.request_count),
            "subsystem_health": self.metrics.subsystem_metrics,
            "uptime": time.time() - self.start_time
        }
    
    def create_checkpoint(self) -> None:
        """Create a system checkpoint."""
        try:
            # Create checkpoint data
            checkpoint_data = {
                "timestamp": datetime.now().isoformat(),
                "uptime": time.time() - self.start_time,
                "metrics": self.metrics.get_metrics()
            }
            
            # Save checkpoint to file
            checkpoint_file = self.log_dir / f"checkpoint_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(checkpoint_file, 'w') as f:
                json.dump(checkpoint_data, f, indent=2)
            
            logger.info("checkpoint_created", 
                       metrics_file=str(checkpoint_file),
                       alerts_file=str(self.log_dir / f"alerts_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"))
            
            return checkpoint_data
        except Exception as e:
            logger.error("checkpoint_creation_error", error=str(e))
            raise
    
    async def _send_alert(self, alert: Alert) -> None:
        """Send alert to webhook."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    self.alert_webhook,
                    json=alert.to_dict()
                ) as response:
                    if response.status != 200:
                        logger.error("alert_webhook_error",
                            status=response.status,
                            alert=alert.to_dict()
                        )
        
        except Exception as e:
            logger.error("alert_webhook_error",
                error=str(e),
                alert=alert.to_dict()
            )
    
    def __enter__(self):
        """Context manager entry."""
        self.start_time = time.time()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        if exc_type is not None:
            self.record_error(str(exc_val))
        
        # Update response time
        response_time = time.time() - self.start_time
        self.metrics.average_response_time = (
            response_time + self.metrics.average_response_time
        ) / 2
        RESPONSE_TIME.observe(response_time)
    
    def checkpoint(self):
        """Create a system checkpoint."""
        try:
            # Create checkpoint data
            checkpoint_data = {
                "timestamp": datetime.now().isoformat(),
                "uptime": time.time() - self.start_time,
                "metrics": self.metrics.get_metrics()
            }
            
            # Save checkpoint to file
            checkpoint_file = self.log_dir / f"checkpoint_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(checkpoint_file, 'w') as f:
                json.dump(checkpoint_data, f, indent=2)
            
            logger.info("checkpoint_created", 
                       metrics_file=str(checkpoint_file),
                       alerts_file=str(self.log_dir / f"alerts_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"))
            
            return checkpoint_data
        except Exception as e:
            logger.error("checkpoint_creation_error", error=str(e))
            raise

    def end_turn(self, start_time):
        return time.time() - start_time

    @property
    def loggers(self):
        return {k: True for k in ["agent", "attention", "memory", "emotion", "planning", "decision", "learning", "integration", "monitoring"]}

    def log_subsystem_event(self, subsystem: str, event_type: str, level: str = "info", data: Dict = None):
        """Log a subsystem event."""
        try:
            # Map log levels to numeric values
            level_map = {
                "debug": 10,
                "info": 20,
                "warning": 30,
                "error": 40,
                "critical": 50
            }
            log_level = level_map.get(level.lower(), 20)  # Default to INFO
            
            # Create log file for subsystem if it doesn't exist
            log_file = self.log_dir / f"{subsystem}.log"
            with open(log_file, 'a') as f:
                log_entry = {
                    "timestamp": datetime.now().isoformat(),
                    "level": log_level,
                    "event_type": event_type,
                    "data": data or {}
                }
                f.write(json.dumps(log_entry) + "\n")
            
            logger.info("subsystem_event",
                       subsystem=subsystem,
                       event_type=event_type,
                       data=data)
            
        except Exception as e:
            logger.error("event_logging_failed", error=str(e))
            raise

    def start_turn(self):
        return time.time()

    def record_error(self, subsystem: str, error: Exception, context: Dict = None):
        """Record an error from a subsystem."""
        try:
            error_type = type(error).__name__
            error_msg = str(error)
            
            # Record in metrics
            self.metrics.record_error(error_type)
            
            # Log error
            logger.error("subsystem_error",
                        subsystem=subsystem,
                        error=error_msg,
                        error_type=error_type,
                        context=context)
            
            # Create error log file if it doesn't exist
            error_log = self.log_dir / f"{subsystem}_errors.log"
            with open(error_log, 'a') as f:
                f.write(f"{datetime.now().isoformat()} - {error_type}: {error_msg}\n")
            
        except Exception as e:
            logger.error("error_recording_failed", error=str(e))
            raise

class MonitoringSystem:
    """System for monitoring Echo's performance and health."""
    
    def __init__(self):
        self._metrics_history: List[SystemMetrics] = []
        self._current_metrics = SystemMetrics()
        self._start_time = time.time()
    
    def update_metrics(self, metrics: Dict[str, Any]) -> None:
        """Update current metrics.
        
        Args:
            metrics: Dictionary containing new metric values
        """
        self._current_metrics.update(metrics)
        self._metrics_history.append(self._current_metrics)
    
    def get_current_metrics(self) -> SystemMetrics:
        """Get current metrics.
        
        Returns:
            Current system metrics
        """
        return self._current_metrics
    
    def get_metrics_history(self) -> List[SystemMetrics]:
        """Get metrics history.
        
        Returns:
            List of historical metrics
        """
        return self._metrics_history
    
    def get_uptime(self) -> float:
        """Get system uptime in seconds.
        
        Returns:
            Uptime in seconds
        """
        return time.time() - self._start_time
    
    def get_error_rate(self) -> float:
        """Get current error rate.
        
        Returns:
            Error rate (errors per request)
        """
        if self._current_metrics.request_count == 0:
            return 0.0
        return self._current_metrics.error_count / self._current_metrics.request_count 
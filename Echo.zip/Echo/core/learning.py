"""
Learning subsystem for the Echo cognitive agent.
"""
from typing import Dict, Any, List, Optional, Set
from core.interfaces import CognitiveSubsystem
from datetime import datetime, timedelta
import math

class LearningPattern:
    """Represents a learned pattern or rule."""
    
    def __init__(self,
                 description: str,
                 pattern_type: str,
                 confidence: float = 0.5):
        self.description = description
        self.pattern_type = pattern_type  # e.g., "behavior", "response", "strategy"
        self.confidence = max(0.0, min(1.0, confidence))
        self.created_at = datetime.now()
        self.last_updated = datetime.now()
        self.success_count = 0
        self.failure_count = 0
        self.contexts: Set[str] = set()
        self.related_patterns: Set[str] = set()
        self.examples: List[Dict[str, Any]] = []
        self.max_examples = 10
    
    def update_confidence(self, success: bool) -> None:
        """Update confidence based on success or failure."""
        if success:
            self.success_count += 1
        else:
            self.failure_count += 1
        
        total = self.success_count + self.failure_count
        if total > 0:
            self.confidence = self.success_count / total
        self.last_updated = datetime.now()
    
    def add_context(self, context: str) -> None:
        """Add a context where this pattern applies."""
        self.contexts.add(context)
    
    def add_related_pattern(self, pattern_id: str) -> None:
        """Add a related pattern."""
        self.related_patterns.add(pattern_id)
    
    def add_example(self, example: Dict[str, Any]) -> None:
        """Add an example of this pattern."""
        self.examples.append({
            **example,
            "timestamp": datetime.now().isoformat()
        })
        
        # Keep only recent examples
        if len(self.examples) > self.max_examples:
            self.examples.pop(0)
    
    def get_success_rate(self) -> float:
        """Calculate the success rate."""
        total = self.success_count + self.failure_count
        return self.success_count / total if total > 0 else 0.0

class LearningSystem(CognitiveSubsystem):
    """Manages the agent's learning processes."""
    
    def __init__(self):
        self._patterns: Dict[str, LearningPattern] = {}  # pattern_id -> pattern
        self._last_update = datetime.now()
        self._learning_history: List[Dict[str, Any]] = []
        self._max_history = 100
        self._pattern_types = {
            "behavior": "Learned behavioral patterns",
            "response": "Learned response patterns",
            "strategy": "Learned strategic patterns",
            "rule": "Learned rules"
        }
    
    def update(self, context: Dict[str, Any]) -> None:
        """Update learning system based on context.
        
        Args:
            context: Dictionary containing current context including:
                    - user_input: The user's message
                    - feedback: Learning feedback
                    - memory: Relevant memories
                    - other_subsystems: States of other subsystems
        """
        # Process new information
        if "user_input" in context:
            self._process_user_input(context["user_input"])
        
        if "feedback" in context:
            self._process_feedback(context["feedback"])
        
        if "memory" in context:
            self._process_memories(context["memory"])
        
        # Update pattern states
        self._update_pattern_states()
        
        # Prune old patterns
        self._prune_patterns()
    
    def get_state(self) -> Dict[str, Any]:
        """Get current learning state.
        
        Returns:
            Dictionary containing current patterns and metrics.
        """
        patterns = {
            pattern_id: {
                "description": pattern.description,
                "type": pattern.pattern_type,
                "confidence": pattern.confidence,
                "success_rate": pattern.get_success_rate(),
                "contexts": list(pattern.contexts),
                "related_patterns": list(pattern.related_patterns),
                "examples": pattern.examples,
                "created_at": pattern.created_at.isoformat(),
                "last_updated": pattern.last_updated.isoformat()
            }
            for pattern_id, pattern in self._patterns.items()
        }
        
        return {
            "patterns": patterns,
            "learning_history": self._learning_history,
            "total_patterns": len(self._patterns)
        }
    
    def _process_user_input(self, user_input: str) -> None:
        """Process user input for pattern learning."""
        # Simple pattern detection from keywords
        learning_keywords = ["learn", "understand", "pattern", "rule"]
        if any(keyword in user_input.lower() for keyword in learning_keywords):
            # Extract pattern description
            description = user_input.strip()
            if description.endswith("."):
                description = description[:-1]
            
            # Create new pattern
            self._create_pattern(description)
    
    def _process_feedback(self, feedback: Dict[str, Any]) -> None:
        """Process learning feedback."""
        pattern_id = feedback.get("pattern_id")
        success = feedback.get("success", False)
        
        if pattern_id in self._patterns:
            pattern = self._patterns[pattern_id]
            pattern.update_confidence(success)
            
            # Add to learning history
            self._learning_history.append({
                "pattern_id": pattern_id,
                "success": success,
                "timestamp": datetime.now().isoformat()
            })
            
            # Keep history at max length
            if len(self._learning_history) > self._max_history:
                self._learning_history.pop(0)
    
    def _process_memories(self, memory: Dict[str, Any]) -> None:
        """Process memories for pattern learning."""
        recent_memories = memory.get("recent_memories", [])
        for mem in recent_memories:
            # Update pattern examples based on memory content
            for pattern_id, pattern in self._patterns.items():
                if pattern.description.lower() in mem.get("content", "").lower():
                    pattern.add_example({
                        "content": mem.get("content"),
                        "emotional_valence": mem.get("emotional_valence", 0.0)
                    })
    
    def _update_pattern_states(self) -> None:
        """Update states of existing patterns."""
        current_time = datetime.now()
        
        for pattern in self._patterns.values():
            # Update pattern confidence based on success rate
            success_rate = pattern.get_success_rate()
            if success_rate > 0:
                pattern.confidence = (pattern.confidence + success_rate) / 2
    
    def _prune_patterns(self) -> None:
        """Remove old or low-confidence patterns."""
        current_patterns = {}
        for pattern_id, pattern in self._patterns.items():
            # Keep only recent or high-confidence patterns
            if (datetime.now() - pattern.created_at < timedelta(days=7) or
                pattern.confidence > 0.7):
                current_patterns[pattern_id] = pattern
        
        self._patterns = current_patterns
    
    def _create_pattern(self, description: str) -> None:
        """Create a new learning pattern."""
        # Determine pattern type
        pattern_type = "rule"  # Default type
        for type_name in self._pattern_types:
            if type_name in description.lower():
                pattern_type = type_name
                break
        
        # Create pattern
        pattern = LearningPattern(
            description=description,
            pattern_type=pattern_type
        )
        
        pattern_id = f"{pattern_type}_{len(self._patterns)}"
        self._patterns[pattern_id] = pattern
        
        # Add to learning history
        self._learning_history.append({
            "pattern_id": pattern_id,
            "description": description,
            "type": pattern_type,
            "timestamp": datetime.now().isoformat()
        })
        
        # Keep history at max length
        if len(self._learning_history) > self._max_history:
            self._learning_history.pop(0)
    
    def get_pattern(self, pattern_id: str) -> Optional[LearningPattern]:
        """Get a specific pattern."""
        return self._patterns.get(pattern_id)
    
    def get_patterns_by_type(self, pattern_type: str) -> List[LearningPattern]:
        """Get all patterns of a specific type."""
        return [
            pattern for pattern in self._patterns.values()
            if pattern.pattern_type == pattern_type
        ]
    
    def get_related_patterns(self, pattern_id: str) -> List[LearningPattern]:
        """Get patterns related to a specific pattern."""
        pattern = self._patterns.get(pattern_id)
        if not pattern:
            return []
        
        return [
            self._patterns[related_id]
            for related_id in pattern.related_patterns
            if related_id in self._patterns
        ] 
"""
Belief subsystem for the Echo cognitive agent.
"""
from typing import Dict, Any, List, Set
from core.interfaces import CognitiveSubsystem

class BeliefSubsystem(CognitiveSubsystem):
    """Manages the agent's beliefs and knowledge."""
    
    def __init__(self):
        self._beliefs: List[Dict[str, Any]] = []
        self._confidence_threshold = 0.7
        self._max_beliefs = 50
    
    def update(self, context: Dict[str, Any]) -> None:
        """Update beliefs based on context.
        
        Args:
            context: Dictionary containing current context including:
                    - user_input: The user's message
                    - llm_response: The LLM's response
                    - other_subsystems: States of other subsystems
        """
        # Process new information from user input
        if "user_input" in context:
            self._process_user_input(context["user_input"])
        
        # Process new information from LLM response
        if "llm_response" in context:
            self._process_llm_response(context["llm_response"])
        
        # Update belief confidence based on emotional state
        if "emotional_state" in context:
            self._update_belief_confidence(context["emotional_state"])
        
        # Prune low-confidence beliefs
        self._prune_beliefs()
    
    def get_state(self) -> Dict[str, Any]:
        """Get current belief state.
        
        Returns:
            Dictionary containing active beliefs and their confidence levels.
        """
        # Get active beliefs (confidence above threshold)
        active_beliefs = [
            belief["content"]
            for belief in self._beliefs
            if belief["confidence"] >= self._confidence_threshold
        ]
        
        return {
            "active_beliefs": active_beliefs,
            "total_beliefs": len(self._beliefs)
        }
    
    def _process_user_input(self, user_input: str) -> None:
        """Process user input for new beliefs."""
        # Simple belief extraction based on declarative statements
        if user_input.endswith("."):
            self._add_belief({
                "content": user_input,
                "confidence": 0.8,  # High confidence in direct user statements
                "source": "user_input"
            })
    
    def _process_llm_response(self, response: str) -> None:
        """Process LLM response for new beliefs."""
        # Extract beliefs from LLM responses
        # Look for declarative statements
        sentences = response.split(". ")
        for sentence in sentences:
            if sentence.endswith("."):
                sentence = sentence[:-1]  # Remove trailing period
            if len(sentence.split()) > 3:  # Only consider substantial statements
                self._add_belief({
                    "content": sentence,
                    "confidence": 0.6,  # Moderate confidence in LLM statements
                    "source": "llm_response"
                })
    
    def _update_belief_confidence(self, emotional_state: Dict[str, Any]) -> None:
        """Update belief confidence based on emotional state."""
        # Adjust confidence based on trust level
        trust_level = emotional_state.get("trust", 0.5)
        
        for belief in self._beliefs:
            if belief["source"] == "user_input":
                # User input beliefs are more affected by trust
                belief["confidence"] *= (0.5 + trust_level)
            else:
                # LLM beliefs are less affected by trust
                belief["confidence"] *= (0.7 + 0.3 * trust_level)
    
    def _add_belief(self, belief: Dict[str, Any]) -> None:
        """Add a new belief to the system."""
        # Check for similar existing beliefs
        for existing_belief in self._beliefs:
            if self._are_beliefs_similar(belief["content"], existing_belief["content"]):
                # Update existing belief confidence
                existing_belief["confidence"] = max(
                    existing_belief["confidence"],
                    belief["confidence"]
                )
                return
        
        # Add new belief if no similar one exists
        self._beliefs.append(belief)
    
    def _are_beliefs_similar(self, belief1: str, belief2: str) -> bool:
        """Check if two beliefs are similar based on word overlap."""
        words1 = set(belief1.lower().split())
        words2 = set(belief2.lower().split())
        
        overlap = len(words1.intersection(words2))
        total_words = len(words1.union(words2))
        
        return overlap / total_words > 0.7 if total_words > 0 else False
    
    def _prune_beliefs(self) -> None:
        """Remove low-confidence beliefs."""
        # Sort by confidence
        self._beliefs.sort(key=lambda x: x["confidence"], reverse=True)
        
        # Keep only the highest confidence beliefs up to max_beliefs
        self._beliefs = self._beliefs[:self._max_beliefs] 
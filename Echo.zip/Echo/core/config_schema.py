"""
Configuration schema for Echo cognitive agent.
"""
from typing import Dict, Any, Optional, List, Union, Type
from dataclasses import dataclass, field
from enum import Enum
import json
from pathlib import Path
import os
import re
import hashlib
from datetime import datetime
from core.config import ValidationError
import structlog

logger = structlog.get_logger(__name__)

class ConfigFieldType(Enum):
    """Types of configuration fields."""
    STRING = "string"
    INTEGER = "integer"
    FLOAT = "float"
    BOOLEAN = "boolean"
    ENUM = "enum"
    OBJECT = "object"
    ARRAY = "array"
    SECRET = "secret"  # New type for sensitive values

@dataclass
class ValidationError:
    """Represents a configuration validation error."""
    field: str
    message: str
    value: Any = None
    
    def __str__(self) -> str:
        """Convert error to string."""
        if self.value is not None:
            return f"{self.field}: {self.message} (got {self.value})"
        return f"{self.field}: {self.message}"

@dataclass
class ConfigField:
    """Represents a configuration field with validation rules."""
    name: str
    type: Type
    required: bool = True
    default: Any = None
    min_value: Optional[Union[int, float]] = None
    max_value: Optional[Union[int, float]] = None
    choices: Optional[List[Any]] = None
    pattern: Optional[str] = None
    description: Optional[str] = None
    validation_errors: List[ValidationError] = field(default_factory=list)
    
    def validate(self, value: Any) -> bool:
        """Validate a field value against its rules."""
        self.validation_errors = []
        
        # Check required
        if self.required and value is None:
            self.validation_errors.append(
                ValidationError(
                    self.name,
                    "Field is required",
                    value
                )
            )
            return False
        
        # Skip validation if value is None and not required
        if value is None:
            return True
        
        # Check type
        if not isinstance(value, self.type):
            self.validation_errors.append(
                ValidationError(
                    self.name,
                    f"Must be of type {self.type.__name__}",
                    value
                )
            )
            return False
        
        # Check numeric bounds
        if isinstance(value, (int, float)):
            if self.min_value is not None and value < self.min_value:
                self.validation_errors.append(
                    ValidationError(
                        self.name,
                        f"Must be >= {self.min_value}",
                        value
                    )
                )
                return False
            if self.max_value is not None and value > self.max_value:
                self.validation_errors.append(
                    ValidationError(
                        self.name,
                        f"Must be <= {self.max_value}",
                        value
                    )
                )
                return False
        
        # Check choices
        if self.choices is not None and value not in self.choices:
            self.validation_errors.append(
                ValidationError(
                    self.name,
                    f"Must be one of {self.choices}",
                    value
                )
            )
            return False
        
        # Check pattern
        if self.pattern is not None and isinstance(value, str):
            if not re.match(self.pattern, value):
                self.validation_errors.append(
                    ValidationError(
                        self.name,
                        f"Must match pattern {self.pattern}",
                        value
                    )
                )
                return False
        
        return True

@dataclass
class ConfigObject:
    """Represents a configuration object with nested fields."""
    name: str
    fields: Dict[str, ConfigField]
    required: bool = True
    description: Optional[str] = None
    validation_errors: List[ValidationError] = field(default_factory=list)
    
    def validate(self, value: Dict[str, Any]) -> bool:
        """Validate a configuration object against its schema."""
        self.validation_errors = []
        
        # Check required
        if self.required and value is None:
            self.validation_errors.append(
                ValidationError(
                    self.name,
                    "Object is required"
                )
            )
            return False
        
        # Skip validation if value is None and not required
        if value is None:
            return True
        
        # Check type
        if not isinstance(value, dict):
            self.validation_errors.append(
                ValidationError(
                    self.name,
                    "Must be a dictionary",
                    value
                )
            )
            return False
        
        # Validate each field
        is_valid = True
        for field_name, field_schema in self.fields.items():
            field_value = value.get(field_name)
            if not field_schema.validate(field_value):
                self.validation_errors.extend(field_schema.validation_errors)
                is_valid = False
        
        return is_valid

@dataclass
class ConfigArray:
    """Represents a configuration array with element validation."""
    name: str
    element_type: Union[Type, ConfigObject]
    min_length: Optional[int] = None
    max_length: Optional[int] = None
    unique: bool = False
    required: bool = True
    description: Optional[str] = None
    validation_errors: List[ValidationError] = field(default_factory=list)
    
    def validate(self, value: List[Any]) -> bool:
        """Validate a configuration array against its schema."""
        self.validation_errors = []
        
        # Check required
        if self.required and value is None:
            self.validation_errors.append(
                ValidationError(
                    self.name,
                    "Array is required"
                )
            )
            return False
        
        # Skip validation if value is None and not required
        if value is None:
            return True
        
        # Check type
        if not isinstance(value, list):
            self.validation_errors.append(
                ValidationError(
                    self.name,
                    "Must be a list",
                    value
                )
            )
            return False
        
        # Check length bounds
        if self.min_length is not None and len(value) < self.min_length:
            self.validation_errors.append(
                ValidationError(
                    self.name,
                    f"Must have at least {self.min_length} elements",
                    len(value)
                )
            )
            return False
        if self.max_length is not None and len(value) > self.max_length:
            self.validation_errors.append(
                ValidationError(
                    self.name,
                    f"Must have at most {self.max_length} elements",
                    len(value)
                )
            )
            return False
        
        # Check uniqueness
        if self.unique and len(value) != len(set(value)):
            self.validation_errors.append(
                ValidationError(
                    self.name,
                    "Must contain unique elements",
                    value
                )
            )
            return False
        
        # Validate elements
        is_valid = True
        for i, element in enumerate(value):
            if isinstance(self.element_type, type):
                if not isinstance(element, self.element_type):
                    self.validation_errors.append(
                        ValidationError(
                            f"{self.name}[{i}]",
                            f"Must be of type {self.element_type.__name__}",
                            element
                        )
                    )
                    is_valid = False
            else:
                if not self.element_type.validate(element):
                    self.validation_errors.extend(
                        ValidationError(
                            f"{self.name}[{i}].{error.field}",
                            error.message,
                            error.value
                        )
                        for error in self.element_type.validation_errors
                    )
                    is_valid = False
        
        return is_valid

class ConfigSchema:
    """Manages configuration schema and validation."""
    
    def __init__(self, schema: Dict[str, Union[ConfigField, ConfigObject, ConfigArray]]):
        """Initialize configuration schema."""
        self.schema = schema
        self.validation_errors: List[ValidationError] = []
    
    def validate(self, config: Dict[str, Any]) -> bool:
        """Validate a configuration against the schema."""
        self.validation_errors = []
        is_valid = True
        
        # Validate each field
        for field_name, field_schema in self.schema.items():
            field_value = config.get(field_name)
            if not field_schema.validate(field_value):
                self.validation_errors.extend(field_schema.validation_errors)
                is_valid = False
        
        return is_valid
    
    def get_errors(self) -> List[ValidationError]:
        """Get validation errors."""
        return self.validation_errors
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert schema to dictionary."""
        return {
            field_name: {
                "type": field_schema.__class__.__name__,
                "required": field_schema.required,
                "description": field_schema.description
            }
            for field_name, field_schema in self.schema.items()
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ConfigSchema':
        """Create schema from dictionary."""
        schema = {}
        for field_name, field_data in data.items():
            field_type = field_data["type"]
            if field_type == "ConfigField":
                schema[field_name] = ConfigField(
                    name=field_name,
                    type=eval(field_data["type"]),
                    required=field_data["required"],
                    description=field_data.get("description")
                )
            elif field_type == "ConfigObject":
                schema[field_name] = ConfigObject(
                    name=field_name,
                    fields={
                        name: ConfigField(
                            name=name,
                            type=eval(field["type"]),
                            required=field["required"],
                            description=field.get("description")
                        )
                        for name, field in field_data["fields"].items()
                    },
                    required=field_data["required"],
                    description=field_data.get("description")
                )
            elif field_type == "ConfigArray":
                schema[field_name] = ConfigArray(
                    name=field_name,
                    element_type=eval(field_data["element_type"]),
                    required=field_data["required"],
                    description=field_data.get("description")
                )
        return cls(schema)

class ConfigManager:
    """Manages configuration loading, validation, and updates."""
    
    def __init__(self, schema: ConfigSchema, config_dir: str = "config"):
        """Initialize configuration manager."""
        self.schema = schema
        self.config_dir = Path(config_dir)
        self.config: Dict[str, Any] = {}
        self.last_loaded: Optional[datetime] = None
        
        # Create config directory
        self.config_dir.mkdir(exist_ok=True)
        
        # Load configuration
        self.load()
    
    def load(self) -> bool:
        """Load configuration from file."""
        try:
            config_file = self.config_dir / "config.json"
            if config_file.exists():
                with open(config_file) as f:
                    self.config = json.load(f)
                
                # Validate configuration
                if not self.schema.validate(self.config):
                    logger.error(
                        "Invalid configuration",
                        errors=[str(error) for error in self.schema.get_errors()]
                    )
                    return False
                
                self.last_loaded = datetime.now()
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Error loading configuration: {e}")
            return False
    
    def save(self) -> bool:
        """Save configuration to file."""
        try:
            config_file = self.config_dir / "config.json"
            with open(config_file, 'w') as f:
                json.dump(self.config, f, indent=2)
            return True
            
        except Exception as e:
            logger.error(f"Error saving configuration: {e}")
            return False
    
    def update(self, updates: Dict[str, Any]) -> bool:
        """Update configuration with new values."""
        try:
            # Create temporary config with updates
            temp_config = self.config.copy()
            temp_config.update(updates)
            
            # Validate updated configuration
            if not self.schema.validate(temp_config):
                logger.error(
                    "Invalid configuration updates",
                    errors=[str(error) for error in self.schema.get_errors()]
                )
                return False
            
            # Apply updates
            self.config = temp_config
            
            # Save changes
            return self.save()
            
        except Exception as e:
            logger.error(f"Error updating configuration: {e}")
            return False
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value."""
        return self.config.get(key, default)
    
    def get_all(self) -> Dict[str, Any]:
        """Get all configuration values."""
        return self.config.copy()
    
    def validate(self) -> bool:
        """Validate current configuration."""
        return self.schema.validate(self.config)
    
    def get_errors(self) -> List[ValidationError]:
        """Get validation errors."""
        return self.schema.get_errors()

def create_echo_schema() -> ConfigSchema:
    """Create the Echo configuration schema."""
    return ConfigSchema(
        name="Echo Configuration",
        description="Configuration schema for the Echo cognitive agent.",
        version="1.3",
        fields=[
            ConfigField(
                name="version",
                type=ConfigFieldType.STRING,
                description="Configuration version",
                required=True,
                pattern=r"^\d+\.\d+$"
            ),
            ConfigField(
                name="llm",
                type=ConfigFieldType.OBJECT,
                description="LLM configuration",
                required=True,
                fields=[
                    ConfigField(
                        name="model_name",
                        type=ConfigFieldType.STRING,
                        description="Name of the LLM model to use",
                        default="gpt-4"
                    ),
                    ConfigField(
                        name="temperature",
                        type=ConfigFieldType.FLOAT,
                        description="Sampling temperature for text generation",
                        default=0.7,
                        min_value=0.0,
                        max_value=1.0
                    ),
                    ConfigField(
                        name="max_tokens",
                        type=ConfigFieldType.INTEGER,
                        description="Maximum number of tokens to generate",
                        default=1000,
                        min_value=1
                    ),
                    ConfigField(
                        name="api_key",
                        type=ConfigFieldType.SECRET,
                        description="API key for the LLM service",
                        required=False,
                        sensitive=True,
                        env_var="ECHO_LLM_API_KEY"
                    ),
                    ConfigField(
                        name="api_base",
                        type=ConfigFieldType.STRING,
                        description="Base URL for the LLM API",
                        required=False,
                        env_var="ECHO_LLM_API_BASE"
                    ),
                    ConfigField(
                        name="timeout",
                        type=ConfigFieldType.INTEGER,
                        description="API request timeout in seconds",
                        default=30,
                        min_value=1
                    )
                ]
            ),
            ConfigField(
                name="monitoring",
                type=ConfigFieldType.OBJECT,
                description="Monitoring configuration",
                required=True,
                fields=[
                    ConfigField(
                        name="log_level",
                        type=ConfigFieldType.ENUM,
                        description="Logging level",
                        default="INFO",
                        enum_values=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
                    ),
                    ConfigField(
                        name="log_dir",
                        type=ConfigFieldType.STRING,
                        description="Directory for log files",
                        default="logs"
                    ),
                    ConfigField(
                        name="checkpoint_interval",
                        type=ConfigFieldType.INTEGER,
                        description="Create checkpoint every N turns",
                        default=10,
                        min_value=1
                    ),
                    ConfigField(
                        name="metrics_retention",
                        type=ConfigFieldType.INTEGER,
                        description="Number of metrics to retain",
                        default=1000,
                        min_value=1
                    ),
                    ConfigField(
                        name="health_check_interval",
                        type=ConfigFieldType.INTEGER,
                        description="Health check interval in seconds",
                        default=60,
                        min_value=1
                    )
                ]
            )
        ]
    )

class SchemaValidator:
    """Validates configuration against schema."""
    
    def __init__(self, schema: ConfigSchema):
        """Initialize validator with schema."""
        self.schema = schema
        self._docs_cache = None
    
    def validate(self, config: Dict[str, Any]) -> None:
        """Validate configuration against schema."""
        errors = self.schema.validate(config)
        if errors:
            raise ValidationError("Configuration validation failed:\n" + "\n".join(str(error) for error in errors))
    
    def generate_docs(self, output_path: Optional[str] = None) -> str:
        """Generate configuration documentation."""
        # Use cached documentation if available
        if self._docs_cache:
            docs = self._docs_cache
        else:
            docs = self.schema.generate_documentation()
            self._docs_cache = docs
        
        if output_path:
            with open(output_path, 'w') as f:
                f.write(docs)
        
        return docs
    
    def get_validation_stats(self) -> Dict[str, Any]:
        """Get validation statistics."""
        stats = self.schema.validation_stats
        return {
            "total_validations": stats.total_validations,
            "successful_validations": stats.successful_validations,
            "failed_validations": stats.failed_validations,
            "success_rate": (stats.successful_validations / stats.total_validations * 100
                           if stats.total_validations > 0 else 0),
            "average_validation_time": stats.average_validation_time,
            "last_validation_time": stats.last_validation_time.isoformat()
            if stats.last_validation_time else None,
            "recent_errors": stats.validation_errors[-10:]  # Last 10 errors
        } 
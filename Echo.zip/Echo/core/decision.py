"""
Decision subsystem for the Echo cognitive agent.
"""
from typing import Dict, Any, List, Optional, Set
from core.interfaces import CognitiveSubsystem
from datetime import datetime, timedelta
import math

class Option:
    """Represents a decision option with criteria and evaluation."""
    
    def __init__(self,
                 description: str,
                 criteria: Dict[str, float],
                 confidence: float = 0.5):
        self.description = description
        self.criteria = criteria  # criterion -> weight
        self.confidence = max(0.0, min(1.0, confidence))
        self.created_at = datetime.now()
        self.last_updated = datetime.now()
        self.evaluations: Dict[str, float] = {}  # criterion -> score
        self.risks: List[str] = []
        self.benefits: List[str] = []
        self.required_resources: List[str] = []
        self.dependencies: Set[str] = set()
    
    def update_confidence(self, new_confidence: float) -> None:
        """Update the confidence in this option."""
        self.confidence = max(0.0, min(1.0, new_confidence))
        self.last_updated = datetime.now()
    
    def add_evaluation(self, criterion: str, score: float) -> None:
        """Add or update an evaluation score for a criterion."""
        self.evaluations[criterion] = max(0.0, min(1.0, score))
        self.last_updated = datetime.now()
    
    def add_risk(self, risk: str) -> None:
        """Add a risk associated with this option."""
        if risk not in self.risks:
            self.risks.append(risk)
    
    def add_benefit(self, benefit: str) -> None:
        """Add a benefit associated with this option."""
        if benefit not in self.benefits:
            self.benefits.append(benefit)
    
    def add_resource(self, resource: str) -> None:
        """Add a required resource."""
        if resource not in self.required_resources:
            self.required_resources.append(resource)
    
    def add_dependency(self, dependency: str) -> None:
        """Add a dependency to another option."""
        self.dependencies.add(dependency)
    
    def get_score(self) -> float:
        """Calculate the weighted score for this option."""
        if not self.evaluations:
            return 0.0
        
        total_weight = 0.0
        weighted_sum = 0.0
        
        for criterion, weight in self.criteria.items():
            if criterion in self.evaluations:
                total_weight += weight
                weighted_sum += self.evaluations[criterion] * weight
        
        return weighted_sum / total_weight if total_weight > 0 else 0.0

class DecisionSystem(CognitiveSubsystem):
    """Manages the agent's decision-making processes."""
    
    def __init__(self):
        self._decisions: Dict[str, List[Option]] = {}  # decision_id -> options
        self._max_options = 10
        self._last_update = datetime.now()
        self._decision_history: List[Dict[str, Any]] = []
        self._max_history = 50
        self._selected_options: Dict[str, str] = {}  # decision_id -> option description
        self._decision_criteria: Dict[str, Dict[str, float]] = {
            "default": {
                "feasibility": 0.4,
                "impact": 0.3,
                "risk": 0.2,
                "resource_requirement": 0.1
            }
        }
    
    def update(self, context: Dict[str, Any]) -> None:
        """Update decision system based on context.
        
        Args:
            context: Dictionary containing current context including:
                    - user_input: The user's message
                    - goals: Current goals
                    - memory: Relevant memories
                    - other_subsystems: States of other subsystems
        """
        # Process new information
        if "user_input" in context:
            self._process_user_input(context["user_input"])
        
        if "goals" in context:
            self._process_goals(context["goals"])
        
        if "memory" in context:
            self._process_memories(context["memory"])
        
        # Update decision states
        self._update_decision_states()
        
        # Prune old decisions
        self._prune_decisions()
    
    def get_state(self) -> Dict[str, Any]:
        """Get current decision state.
        
        Returns:
            Dictionary containing current decisions and metrics.
        """
        decisions = {
            decision_id: [
                {
                    "description": option.description,
                    "confidence": option.confidence,
                    "score": option.get_score(),
                    "evaluations": option.evaluations,
                    "risks": option.risks,
                    "benefits": option.benefits,
                    "resources": option.required_resources,
                    "dependencies": list(option.dependencies),
                    "created_at": option.created_at.isoformat(),
                    "last_updated": option.last_updated.isoformat()
                }
                for option in options
            ]
            for decision_id, options in self._decisions.items()
        }
        
        return {
            "decisions": decisions,
            "decision_history": self._decision_history,
            "selected_options": self._selected_options,
            "total_decisions": len(self._decisions)
        }
    
    def get_best_option(self, decision_id: str) -> Optional[Option]:
        """Get the best option for a decision based on scores."""
        options = self._decisions.get(decision_id, [])
        if not options:
            return None
        
        # Sort by score and confidence
        return max(
            options,
            key=lambda x: (x.get_score(), x.confidence)
        )
    
    def _process_user_input(self, user_input: str) -> None:
        """Process user input for decision creation."""
        # Simple decision detection from keywords
        decision_keywords = ["decide", "choose", "select", "pick", "option"]
        if any(keyword in user_input.lower() for keyword in decision_keywords):
            # Extract decision description
            description = user_input.strip()
            if description.endswith("."):
                description = description[:-1]
            
            # Create new decision
            self._create_decision(description)
    
    def _process_goals(self, goals: Dict[str, Any]) -> None:
        """Process goals for decision creation."""
        active_goals = goals.get("active_goals", [])
        for goal in active_goals:
            # Create decision from goal
            description = goal.get("description", "")
            priority = goal.get("priority", 0.5)
            
            # Check if decision already exists
            if description not in self._decisions:
                self._create_decision(description)
    
    def _process_memories(self, memory: Dict[str, Any]) -> None:
        """Process memories for decision updates."""
        recent_memories = memory.get("recent_memories", [])
        for mem in recent_memories:
            # Update option evaluations based on memory content
            for decision_id, options in self._decisions.items():
                for option in options:
                    if option.description.lower() in mem.get("content", "").lower():
                        # Update evaluations based on memory content
                        if "success" in mem.get("content", "").lower():
                            option.add_evaluation("feasibility", 0.8)
                        elif "failure" in mem.get("content", "").lower():
                            option.add_evaluation("feasibility", 0.2)
    
    def _update_decision_states(self) -> None:
        """Update states of existing decisions."""
        current_time = datetime.now()
        
        for decision_id, options in self._decisions.items():
            # Update option confidences based on evaluations
            for option in options:
                if option.evaluations:
                    # Calculate new confidence based on evaluation scores
                    avg_score = sum(option.evaluations.values()) / len(option.evaluations)
                    new_confidence = (option.confidence + avg_score) / 2
                    option.update_confidence(new_confidence)
    
    def _prune_decisions(self) -> None:
        """Remove old decisions."""
        current_decisions = {}
        for decision_id, options in self._decisions.items():
            # Keep only recent decisions
            if any(
                datetime.now() - option.created_at < timedelta(hours=24)
                for option in options
            ):
                current_decisions[decision_id] = options
        
        self._decisions = current_decisions
    
    def _create_decision(self, description: str) -> None:
        """Create a new decision with options."""
        # Generate options based on description
        options = self._generate_options(description)
        
        if options:
            self._decisions[description] = options
            
            # Add to decision history
            self._decision_history.append({
                "description": description,
                "options": [opt.description for opt in options],
                "timestamp": datetime.now().isoformat()
            })
            
            # Keep history at max length
            if len(self._decision_history) > self._max_history:
                self._decision_history.pop(0)
    
    def _generate_options(self, description: str) -> List[Option]:
        """Generate options for a decision."""
        # Simple option generation based on description
        options = []
        
        # Add default options
        options.append(Option(
            description=f"Proceed with {description}",
            criteria=self._decision_criteria["default"],
            confidence=0.7
        ))
        
        options.append(Option(
            description=f"Delay {description}",
            criteria=self._decision_criteria["default"],
            confidence=0.5
        ))
        
        options.append(Option(
            description=f"Modify approach for {description}",
            criteria=self._decision_criteria["default"],
            confidence=0.6
        ))
        
        return options
    
    def get_decision_options(self, decision_id: str) -> List[Option]:
        """Get all options for a decision."""
        return self._decisions.get(decision_id, [])
    
    def get_selected_option(self, decision_id: str) -> Optional[str]:
        """Get the selected option for a decision."""
        return self._selected_options.get(decision_id)
    
    def select_option(self, decision_id: str, option_description: str) -> bool:
        """Select an option for a decision."""
        options = self._decisions.get(decision_id, [])
        if not any(opt.description == option_description for opt in options):
            return False
        
        self._selected_options[decision_id] = option_description
        return True 
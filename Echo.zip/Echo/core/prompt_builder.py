"""
Prompt builder for the Echo cognitive agent.
"""
from typing import Dict, Any, List, Optional

class PromptBuilder:
    """Builds prompts for the LLM based on context and requirements."""
    
    def __init__(self):
        self._templates: Dict[str, str] = {"default": "User input: {input_text}"}
        self._context: Dict[str, Any] = {}
        self._requirements: List[str] = []
    
    def add_template(self, name: str, template: str) -> None:
        """Add a prompt template.
        
        Args:
            name: Name of the template
            template: Template string with placeholders
        """
        self._templates[name] = template
    
    def set_context(self, context: Dict[str, Any]) -> None:
        """Set the context for prompt building.
        
        Args:
            context: Dictionary containing context information
        """
        self._context = context
    
    def add_requirement(self, requirement: str) -> None:
        """Add a requirement to the prompt.
        
        Args:
            requirement: Requirement string
        """
        self._requirements.append(requirement)
    
    def build_prompt(self, template_name: str) -> str:
        """Build a prompt using the specified template.
        
        Args:
            template_name: Name of the template to use
            
        Returns:
            Built prompt string
        """
        if template_name not in self._templates:
            raise ValueError(f"Template '{template_name}' not found")
        
        template = self._templates[template_name]
        
        # Format template with context
        prompt = template.format(**self._context)
        
        # Add requirements if any
        if self._requirements:
            prompt += "\n\nRequirements:\n" + "\n".join(
                f"- {req}" for req in self._requirements
            )
        
        return prompt
    
    def clear(self) -> None:
        """Clear all templates, context, and requirements."""
        self._templates.clear()
        self._context.clear()
        self._requirements.clear() 
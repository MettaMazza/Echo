"""
Reasoning subsystem for the Echo cognitive agent.
"""
from typing import Dict, Any, List, Optional, Set
from core.interfaces import CognitiveSubsystem
from datetime import datetime, timedelta
import json

class ReasoningStep:
    """Represents a single step in the reasoning process."""
    
    def __init__(self,
                 description: str,
                 step_type: str,
                 confidence: float = 0.5,
                 source: Optional[str] = None):
        self.description = description
        self.step_type = step_type  # "deduction", "induction", "abduction", "analysis"
        self.confidence = confidence
        self.source = source
        self.created_at = datetime.now()
        self.last_updated = datetime.now()
        self.supporting_evidence: List[str] = []
        self.conclusions: List[str] = []
        self.related_steps: Set[str] = set()
    
    def add_evidence(self, evidence: str) -> None:
        """Add supporting evidence for this reasoning step."""
        if evidence not in self.supporting_evidence:
            self.supporting_evidence.append(evidence)
            self.last_updated = datetime.now()
    
    def add_conclusion(self, conclusion: str) -> None:
        """Add a conclusion drawn from this reasoning step."""
        if conclusion not in self.conclusions:
            self.conclusions.append(conclusion)
            self.last_updated = datetime.now()
    
    def update_confidence(self, new_confidence: float) -> None:
        """Update the confidence level of this reasoning step."""
        self.confidence = max(0.0, min(1.0, new_confidence))
        self.last_updated = datetime.now()

class ReasoningSystem(CognitiveSubsystem):
    """Handles logical reasoning and problem-solving."""
    
    def __init__(self):
        self._reasoning_steps: Dict[str, ReasoningStep] = {}
        self._max_steps = 100
        self._confidence_threshold = 0.3
        self._last_update = datetime.now()
        self._reasoning_history: List[Dict[str, Any]] = []
        self._max_history = 20
        self._current_problem: Optional[str] = None
        self._problem_context: Dict[str, Any] = {}
    
    def update(self, context: Dict[str, Any]) -> None:
        """Update reasoning system based on context.
        
        Args:
            context: Dictionary containing current context including:
                    - user_input: The user's message
                    - goals: Current goals
                    - knowledge: Relevant knowledge
                    - other_subsystems: States of other subsystems
        """
        # Process new information
        if "user_input" in context:
            self._process_user_input(context["user_input"])
        
        if "goals" in context:
            self._process_goals(context["goals"])
        
        if "knowledge" in context:
            self._process_knowledge(context["knowledge"])
        
        # Update reasoning steps
        self._update_reasoning_steps()
        
        # Generate new reasoning steps
        self._generate_reasoning_steps()
        
        # Prune low-confidence steps
        self._prune_reasoning_steps()
    
    def get_state(self) -> Dict[str, Any]:
        """Get current reasoning state.
        
        Returns:
            Dictionary containing current reasoning steps and metrics.
        """
        reasoning_steps = [
            {
                "description": step.description,
                "type": step.step_type,
                "confidence": step.confidence,
                "evidence": step.supporting_evidence,
                "conclusions": step.conclusions,
                "last_updated": step.last_updated.isoformat()
            }
            for step in self._reasoning_steps.values()
        ]
        
        return {
            "reasoning_steps": sorted(
                reasoning_steps,
                key=lambda x: (x["confidence"], len(x["evidence"])),
                reverse=True
            ),
            "current_problem": self._current_problem,
            "reasoning_history": self._reasoning_history,
            "total_steps": len(self._reasoning_steps)
        }
    
    def get_current_problem(self) -> Optional[str]:
        """Get the current problem being solved."""
        return self._current_problem
    
    def _process_user_input(self, user_input: str) -> None:
        """Process user input for reasoning."""
        # Check if input contains a problem to solve
        if any(word in user_input.lower() for word in ["how", "why", "what if", "solve"]):
            self._current_problem = user_input
            self._problem_context = {
                "type": "user_query",
                "input": user_input,
                "timestamp": datetime.now().isoformat()
            }
    
    def _process_goals(self, goals: Dict[str, Any]) -> None:
        """Process goals for reasoning."""
        active_goals = goals.get("active_goals", [])
        for goal in active_goals:
            # Create reasoning step for goal analysis
            self._add_reasoning_step(
                ReasoningStep(
                    description=f"Analyzing goal: {goal.get('description', '')}",
                    step_type="analysis",
                    confidence=0.7,
                    source="goal_system"
                )
            )
    
    def _process_knowledge(self, knowledge: Dict[str, Any]) -> None:
        """Process knowledge for reasoning."""
        knowledge_items = knowledge.get("knowledge_base", [])
        for item in knowledge_items:
            # Create reasoning step for knowledge application
            self._add_reasoning_step(
                ReasoningStep(
                    description=f"Applying knowledge: {item.get('concept', '')}",
                    step_type="deduction",
                    confidence=item.get("confidence", 0.5),
                    source="knowledge_system"
                )
            )
    
    def _update_reasoning_steps(self) -> None:
        """Update existing reasoning steps."""
        for step in self._reasoning_steps.values():
            # Update confidence based on evidence and conclusions
            if step.supporting_evidence and step.conclusions:
                evidence_strength = len(step.supporting_evidence) / 10.0
                conclusion_strength = len(step.conclusions) / 5.0
                new_confidence = min(1.0, (evidence_strength + conclusion_strength) / 2)
                step.update_confidence(new_confidence)
    
    def _generate_reasoning_steps(self) -> None:
        """Generate new reasoning steps based on current context."""
        if not self._current_problem:
            return
        
        # Generate different types of reasoning steps
        self._generate_deductive_steps()
        self._generate_inductive_steps()
        self._generate_abductive_steps()
        self._generate_analytical_steps()
    
    def _generate_deductive_steps(self) -> None:
        """Generate deductive reasoning steps."""
        if not self._current_problem:
            return
        
        # Create deductive reasoning step
        step = ReasoningStep(
            description=f"Deductive reasoning for: {self._current_problem}",
            step_type="deduction",
            confidence=0.6,
            source="reasoning_system"
        )
        
        # Add evidence and conclusions
        step.add_evidence("Current problem statement")
        step.add_evidence("Relevant knowledge from knowledge base")
        step.add_conclusion("Logical deduction based on available information")
        
        self._add_reasoning_step(step)
    
    def _generate_inductive_steps(self) -> None:
        """Generate inductive reasoning steps."""
        if not self._current_problem:
            return
        
        # Create inductive reasoning step
        step = ReasoningStep(
            description=f"Inductive reasoning for: {self._current_problem}",
            step_type="induction",
            confidence=0.5,
            source="reasoning_system"
        )
        
        # Add evidence and conclusions
        step.add_evidence("Patterns in current problem")
        step.add_evidence("Similar past experiences")
        step.add_conclusion("Generalized conclusion based on patterns")
        
        self._add_reasoning_step(step)
    
    def _generate_abductive_steps(self) -> None:
        """Generate abductive reasoning steps."""
        if not self._current_problem:
            return
        
        # Create abductive reasoning step
        step = ReasoningStep(
            description=f"Abductive reasoning for: {self._current_problem}",
            step_type="abduction",
            confidence=0.4,
            source="reasoning_system"
        )
        
        # Add evidence and conclusions
        step.add_evidence("Observed phenomena")
        step.add_evidence("Known explanations")
        step.add_conclusion("Most likely explanation based on observations")
        
        self._add_reasoning_step(step)
    
    def _generate_analytical_steps(self) -> None:
        """Generate analytical reasoning steps."""
        if not self._current_problem:
            return
        
        # Create analytical reasoning step
        step = ReasoningStep(
            description=f"Analytical reasoning for: {self._current_problem}",
            step_type="analysis",
            confidence=0.7,
            source="reasoning_system"
        )
        
        # Add evidence and conclusions
        step.add_evidence("Problem components")
        step.add_evidence("System constraints")
        step.add_conclusion("Analysis of problem structure and requirements")
        
        self._add_reasoning_step(step)
    
    def _prune_reasoning_steps(self) -> None:
        """Remove low-confidence reasoning steps."""
        # Sort steps by confidence and evidence
        sorted_steps = sorted(
            self._reasoning_steps.items(),
            key=lambda x: (
                x[1].confidence,
                len(x[1].supporting_evidence),
                x[1].last_updated
            ),
            reverse=True
        )
        
        # Keep only the best steps up to max_steps
        self._reasoning_steps = dict(sorted_steps[:self._max_steps])
    
    def _add_reasoning_step(self, step: ReasoningStep) -> None:
        """Add new reasoning step to the system."""
        # Check if similar step exists
        existing = self._reasoning_steps.get(step.description)
        if existing:
            # Update existing step
            existing.update_confidence(
                max(existing.confidence, step.confidence)
            )
            for evidence in step.supporting_evidence:
                existing.add_evidence(evidence)
            for conclusion in step.conclusions:
                existing.add_conclusion(conclusion)
        else:
            # Add new step
            self._reasoning_steps[step.description] = step
            
            # Add to reasoning history
            self._reasoning_history.append({
                "description": step.description,
                "type": step.step_type,
                "confidence": step.confidence,
                "timestamp": datetime.now().isoformat()
            })
            
            # Keep history at max length
            if len(self._reasoning_history) > self._max_history:
                self._reasoning_history.pop(0)
    
    def find_related_steps(self, description: str) -> List[ReasoningStep]:
        """Find reasoning steps related to given description."""
        description_words = set(description.lower().split())
        related = []
        
        for step in self._reasoning_steps.values():
            step_words = set(step.description.lower().split())
            if description_words.intersection(step_words):
                related.append(step)
        
        return sorted(related, key=lambda x: x.confidence, reverse=True) 
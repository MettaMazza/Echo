"""
Goal subsystem for the Echo cognitive agent.
"""
from typing import Dict, Any, List, Optional
from core.interfaces import CognitiveSubsystem
from datetime import datetime

class Goal:
    """Represents a goal in the system."""
    
    def __init__(self, 
                 description: str,
                 priority: float = 0.5,
                 deadline: Optional[datetime] = None,
                 status: str = "active"):
        self.description = description
        self.priority = priority
        self.deadline = deadline
        self.status = status
        self.created_at = datetime.now()
        self.last_updated = datetime.now()
        self.progress = 0.0
        self.dependencies: List[str] = []
    
    def update_progress(self, progress: float) -> None:
        """Update the goal's progress.
        
        Args:
            progress: Progress value between 0.0 and 1.0
        """
        self.progress = max(0.0, min(1.0, progress))
        self.last_updated = datetime.now()
        
        if self.progress >= 1.0:
            self.status = "completed"

class UnifiedGoalSystem(CognitiveSubsystem):
    """Manages the agent's goals and their priorities."""
    
    def __init__(self):
        self._goals: Dict[str, Goal] = {}
        self._max_goals = 50
        self._goal_decay_rate = 0.1  # Rate at which goal priorities decay
    
    def update(self, context: Dict[str, Any]) -> None:
        """Update goals based on context.
        
        Args:
            context: Dictionary containing current context including:
                    - user_input: The user's message
                    - llm_response: The LLM's response
                    - other_subsystems: States of other subsystems
        """
        # Decay goal priorities
        self._decay_priorities()
        
        # Process new information for goal creation/updates
        if "user_input" in context:
            self._process_user_input(context["user_input"])
        
        if "llm_response" in context:
            self._process_llm_response(context["llm_response"])
        
        # Update goal progress based on actions
        if "actions" in context:
            self._update_goal_progress(context["actions"])
        
        # Prune completed or low-priority goals
        self._prune_goals()
    
    def get_state(self) -> Dict[str, Any]:
        """Get current goal state.
        
        Returns:
            Dictionary containing active goals and their states.
        """
        active_goals = [
            {
                "description": goal.description,
                "priority": goal.priority,
                "progress": goal.progress,
                "status": goal.status,
                "deadline": goal.deadline.isoformat() if goal.deadline else None
            }
            for goal in self._goals.values()
            if goal.status == "active"
        ]
        
        return {
            "active_goals": sorted(active_goals, key=lambda x: x["priority"], reverse=True),
            "total_goals": len(self._goals)
        }
    
    def add_goal(self, description: str, priority: float = 0.5, 
                 deadline: Optional[datetime] = None) -> str:
        """Add a new goal to the system.
        
        Args:
            description: Description of the goal
            priority: Priority value between 0.0 and 1.0
            deadline: Optional deadline for the goal
            
        Returns:
            The ID of the created goal
        """
        goal_id = f"goal_{len(self._goals)}"
        self._goals[goal_id] = Goal(description, priority, deadline)
        return goal_id
    
    def _decay_priorities(self) -> None:
        """Decay goal priorities over time."""
        for goal in self._goals.values():
            if goal.status == "active":
                goal.priority *= (1 - self._goal_decay_rate)
    
    def _process_user_input(self, user_input: str) -> None:
        """Process user input for goal creation/updates."""
        # Simple goal extraction based on imperative statements
        if user_input.lower().startswith(("please", "can you", "could you", "i need")):
            # Extract the action part
            action = user_input.lower().split(" ", 2)[-1]
            if action:
                self.add_goal(
                    description=action,
                    priority=0.7,  # High priority for direct user requests
                    deadline=datetime.now() + timedelta(hours=24)  # 24-hour deadline
                )
    
    def _process_llm_response(self, response: str) -> None:
        """Process LLM response for goal creation/updates."""
        # Look for goal-related statements
        if "goal" in response.lower() or "objective" in response.lower():
            # Extract potential goals
            sentences = response.split(". ")
            for sentence in sentences:
                if len(sentence.split()) > 3:  # Only consider substantial statements
                    self.add_goal(
                        description=sentence,
                        priority=0.5,  # Medium priority for inferred goals
                        deadline=None  # No deadline for inferred goals
                    )
    
    def _update_goal_progress(self, actions: List[Dict[str, Any]]) -> None:
        """Update goal progress based on completed actions."""
        for action in actions:
            action_desc = action.get("description", "").lower()
            for goal in self._goals.values():
                if goal.status == "active":
                    # Check if action contributes to goal
                    if any(word in action_desc for word in goal.description.lower().split()):
                        goal.update_progress(goal.progress + 0.1)  # Increment progress
    
    def _prune_goals(self) -> None:
        """Remove completed or low-priority goals."""
        # Sort goals by priority
        sorted_goals = sorted(
            self._goals.items(),
            key=lambda x: (x[1].priority, x[1].created_at),
            reverse=True
        )
        
        # Keep only the highest priority goals up to max_goals
        self._goals = dict(sorted_goals[:self._max_goals]) 
"""
Configuration system for Echo cognitive agent.
"""
import os
import json
from pathlib import Path
from typing import Any, Dict, Optional, List, Union
from dataclasses import dataclass, asdict, field
from enum import Enum

class LogLevel(str, Enum):
    """Valid log levels."""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"

class ValidationError(Exception):
    """Raised when configuration validation fails."""
    pass

@dataclass
class LLMConfig:
    """Configuration for LLM integration."""
    model_name: str = "gpt-4"
    temperature: float = 0.7
    max_tokens: int = 1000
    api_key: Optional[str] = None
    api_base: Optional[str] = None
    timeout: int = 30
    
    def validate(self):
        """Validate LLM configuration."""
        if not isinstance(self.model_name, str):
            raise ValidationError("model_name must be a string")
        if not 0 <= self.temperature <= 1:
            raise ValidationError("temperature must be between 0 and 1")
        if self.max_tokens <= 0:
            raise ValidationError("max_tokens must be positive")
        if self.timeout <= 0:
            raise ValidationError("timeout must be positive")

@dataclass
class MemoryConfig:
    """Configuration for memory subsystem."""
    max_memories: int = 1000
    memory_decay_rate: float = 0.1
    importance_threshold: float = 0.5
    max_context_length: int = 2000
    
    def validate(self):
        """Validate memory configuration."""
        if self.max_memories <= 0:
            raise ValidationError("max_memories must be positive")
        if not 0 <= self.memory_decay_rate <= 1:
            raise ValidationError("memory_decay_rate must be between 0 and 1")
        if not 0 <= self.importance_threshold <= 1:
            raise ValidationError("importance_threshold must be between 0 and 1")
        if self.max_context_length <= 0:
            raise ValidationError("max_context_length must be positive")

@dataclass
class AttentionConfig:
    """Configuration for attention subsystem."""
    max_concurrent_foci: int = 5
    focus_decay_rate: float = 0.2
    importance_threshold: float = 0.3
    max_focus_duration: int = 3600  # 1 hour in seconds
    
    def validate(self):
        """Validate attention configuration."""
        if self.max_concurrent_foci <= 0:
            raise ValidationError("max_concurrent_foci must be positive")
        if not 0 <= self.focus_decay_rate <= 1:
            raise ValidationError("focus_decay_rate must be between 0 and 1")
        if not 0 <= self.importance_threshold <= 1:
            raise ValidationError("importance_threshold must be between 0 and 1")
        if self.max_focus_duration <= 0:
            raise ValidationError("max_focus_duration must be positive")

@dataclass
class EmotionConfig:
    """Configuration for emotion subsystem."""
    mood_update_rate: float = 0.1
    emotion_decay_rate: float = 0.15
    max_emotion_intensity: float = 1.0
    min_emotion_intensity: float = 0.1
    
    def validate(self):
        """Validate emotion configuration."""
        if not 0 <= self.mood_update_rate <= 1:
            raise ValidationError("mood_update_rate must be between 0 and 1")
        if not 0 <= self.emotion_decay_rate <= 1:
            raise ValidationError("emotion_decay_rate must be between 0 and 1")
        if not 0 <= self.min_emotion_intensity <= self.max_emotion_intensity <= 1:
            raise ValidationError("emotion intensities must be between 0 and 1, with min <= max")

@dataclass
class PlanningConfig:
    """Configuration for planning subsystem."""
    max_active_tasks: int = 10
    task_timeout: int = 3600  # 1 hour in seconds
    priority_levels: int = 5
    max_subtasks: int = 5
    
    def validate(self):
        """Validate planning configuration."""
        if self.max_active_tasks <= 0:
            raise ValidationError("max_active_tasks must be positive")
        if self.task_timeout <= 0:
            raise ValidationError("task_timeout must be positive")
        if self.priority_levels <= 0:
            raise ValidationError("priority_levels must be positive")
        if self.max_subtasks <= 0:
            raise ValidationError("max_subtasks must be positive")

@dataclass
class DecisionConfig:
    """Configuration for decision subsystem."""
    confidence_threshold: float = 0.7
    max_active_decisions: int = 5
    decision_timeout: int = 300  # 5 minutes in seconds
    max_alternatives: int = 3
    
    def validate(self):
        """Validate decision configuration."""
        if not 0 <= self.confidence_threshold <= 1:
            raise ValidationError("confidence_threshold must be between 0 and 1")
        if self.max_active_decisions <= 0:
            raise ValidationError("max_active_decisions must be positive")
        if self.decision_timeout <= 0:
            raise ValidationError("decision_timeout must be positive")
        if self.max_alternatives <= 0:
            raise ValidationError("max_alternatives must be positive")

@dataclass
class LearningConfig:
    """Configuration for learning subsystem."""
    pattern_threshold: float = 0.6
    max_patterns: int = 100
    learning_rate: float = 0.1
    min_occurrences: int = 3
    
    def validate(self):
        """Validate learning configuration."""
        if not 0 <= self.pattern_threshold <= 1:
            raise ValidationError("pattern_threshold must be between 0 and 1")
        if self.max_patterns <= 0:
            raise ValidationError("max_patterns must be positive")
        if not 0 <= self.learning_rate <= 1:
            raise ValidationError("learning_rate must be between 0 and 1")
        if self.min_occurrences <= 0:
            raise ValidationError("min_occurrences must be positive")

@dataclass
class IntegrationConfig:
    """Configuration for integration subsystem."""
    max_events: int = 1000
    event_timeout: int = 300  # 5 minutes in seconds
    max_dependencies: int = 5
    priority_levels: int = 5
    
    def validate(self):
        """Validate integration configuration."""
        if self.max_events <= 0:
            raise ValidationError("max_events must be positive")
        if self.event_timeout <= 0:
            raise ValidationError("event_timeout must be positive")
        if self.max_dependencies <= 0:
            raise ValidationError("max_dependencies must be positive")
        if self.priority_levels <= 0:
            raise ValidationError("priority_levels must be positive")

@dataclass
class MonitoringConfig:
    """Configuration for monitoring system."""
    log_level: str = "INFO"
    log_dir: str = "logs"
    checkpoint_interval: int = 10  # Create checkpoint every N turns
    metrics_retention: int = 1000  # Number of metrics to retain
    health_check_interval: int = 60  # Health check every N seconds
    
    def validate(self):
        """Validate monitoring configuration."""
        if self.log_level not in [level.value for level in LogLevel]:
            raise ValidationError(f"log_level must be one of {[level.value for level in LogLevel]}")
        if not isinstance(self.log_dir, str):
            raise ValidationError("log_dir must be a string")
        if self.checkpoint_interval <= 0:
            raise ValidationError("checkpoint_interval must be positive")
        if self.metrics_retention <= 0:
            raise ValidationError("metrics_retention must be positive")
        if self.health_check_interval <= 0:
            raise ValidationError("health_check_interval must be positive")

@dataclass
class EchoConfig:
    """Main configuration for Echo cognitive agent."""
    llm: LLMConfig = field(default_factory=LLMConfig)
    memory: MemoryConfig = field(default_factory=MemoryConfig)
    attention: AttentionConfig = field(default_factory=AttentionConfig)
    emotion: EmotionConfig = field(default_factory=EmotionConfig)
    planning: PlanningConfig = field(default_factory=PlanningConfig)
    decision: DecisionConfig = field(default_factory=DecisionConfig)
    learning: LearningConfig = field(default_factory=LearningConfig)
    integration: IntegrationConfig = field(default_factory=IntegrationConfig)
    monitoring: MonitoringConfig = field(default_factory=MonitoringConfig)
    
    def validate(self):
        """Validate entire configuration."""
        self.llm.validate()
        self.memory.validate()
        self.attention.validate()
        self.emotion.validate()
        self.planning.validate()
        self.decision.validate()
        self.learning.validate()
        self.integration.validate()
        self.monitoring.validate()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> 'EchoConfig':
        """Create configuration from dictionary."""
        config = cls(
            llm=LLMConfig(**config_dict.get('llm', {})),
            memory=MemoryConfig(**config_dict.get('memory', {})),
            attention=AttentionConfig(**config_dict.get('attention', {})),
            emotion=EmotionConfig(**config_dict.get('emotion', {})),
            planning=PlanningConfig(**config_dict.get('planning', {})),
            decision=DecisionConfig(**config_dict.get('decision', {})),
            learning=LearningConfig(**config_dict.get('learning', {})),
            integration=IntegrationConfig(**config_dict.get('integration', {})),
            monitoring=MonitoringConfig(**config_dict.get('monitoring', {}))
        )
        config.validate()
        return config

class ConfigManager:
    """Manager for Echo configuration."""
    
    def __init__(self, config_path: Optional[str] = None):
        """Initialize configuration manager."""
        self.config_path = config_path or os.getenv('ECHO_CONFIG', 'config.json')
        self.config = self._load_config()
    
    def _load_config(self) -> EchoConfig:
        """Load configuration from file or environment."""
        # Try to load from file
        if os.path.exists(self.config_path):
            with open(self.config_path, 'r') as f:
                config_dict = json.load(f)
            return EchoConfig.from_dict(config_dict)
        
        # Create default config
        config = EchoConfig()
        
        # Override with environment variables
        self._override_from_env(config)
        
        # Validate configuration
        config.validate()
        
        return config
    
    def _override_from_env(self, config: EchoConfig):
        """Override configuration with environment variables."""
        # LLM configuration
        if api_key := os.getenv('ECHO_LLM_API_KEY'):
            config.llm.api_key = api_key
        if api_base := os.getenv('ECHO_LLM_API_BASE'):
            config.llm.api_base = api_base
        if model := os.getenv('ECHO_LLM_MODEL'):
            config.llm.model_name = model
        
        # Monitoring configuration
        if log_level := os.getenv('ECHO_LOG_LEVEL'):
            config.monitoring.log_level = log_level
        if log_dir := os.getenv('ECHO_LOG_DIR'):
            config.monitoring.log_dir = log_dir
    
    def save_config(self):
        """Save current configuration to file."""
        config_dir = os.path.dirname(self.config_path)
        if config_dir:
            os.makedirs(config_dir, exist_ok=True)
        
        with open(self.config_path, 'w') as f:
            json.dump(self.config.to_dict(), f, indent=2)
    
    def get_config(self) -> EchoConfig:
        """Get current configuration."""
        return self.config
    
    def update_config(self, config_dict: Dict[str, Any]):
        """Update configuration with new values."""
        try:
            self.config = EchoConfig.from_dict(config_dict)
            self.save_config()
        except ValidationError as e:
            raise ValidationError(f"Configuration validation failed: {str(e)}")
        except Exception as e:
            raise ValidationError(f"Invalid configuration format: {str(e)}")

# Alias for backward compatibility
Config = EchoConfig 
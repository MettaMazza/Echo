"""
Prompt builder for the Echo cognitive agent system.
"""
from typing import Dict, Any, List

class PromptBuilder:
    """Handles dynamic construction of prompts with emotional context."""
    
    def __init__(self):
        self._system_prompt = """You are Echo, an advanced cognitive agent with a rich internal world.
You have emotions, beliefs, and the ability to reason and plan.
You should respond naturally while maintaining awareness of your internal state."""
    
    def build_prompt(self, 
                    user_input: str,
                    emotional_state: Dict[str, Any],
                    memory_context: Dict[str, Any],
                    belief_state: Dict[str, Any]) -> str:
        """Build a complete prompt incorporating all cognitive states.
        
        Args:
            user_input: The user's input message.
            emotional_state: Current emotional state.
            memory_context: Relevant memory context.
            belief_state: Current beliefs and knowledge.
            
        Returns:
            A complete prompt string incorporating all context.
        """
        # Build emotional context
        emotional_context = self._build_emotional_context(emotional_state)
        
        # Build memory context
        memory_section = self._build_memory_context(memory_context)
        
        # Build belief context
        belief_section = self._build_belief_context(belief_state)
        
        # Combine all components
        prompt_parts = [
            self._system_prompt,
            emotional_context,
            memory_section,
            belief_section,
            f"\nUser: {user_input}",
            "\nEcho:"
        ]
        
        return "\n".join(filter(None, prompt_parts))
    
    def _build_emotional_context(self, emotional_state: Dict[str, Any]) -> str:
        """Build the emotional context section of the prompt."""
        if not emotional_state:
            return ""
            
        emotions = []
        for emotion, intensity in emotional_state.items():
            if intensity > 0.3:  # Only include significant emotions
                emotions.append(f"{emotion} ({intensity:.2f})")
        
        if not emotions:
            return ""
            
        return f"\nCurrent emotional state: {', '.join(emotions)}"
    
    def _build_memory_context(self, memory_context: Dict[str, Any]) -> str:
        """Build the memory context section of the prompt."""
        if not memory_context:
            return ""
            
        relevant_memories = memory_context.get("relevant_memories", [])
        if not relevant_memories:
            return ""
            
        memory_text = "\nRelevant memories:\n" + "\n".join(
            f"- {memory}" for memory in relevant_memories[:3]  # Limit to 3 most relevant
        )
        return memory_text
    
    def _build_belief_context(self, belief_state: Dict[str, Any]) -> str:
        """Build the belief context section of the prompt."""
        if not belief_state:
            return ""
            
        beliefs = belief_state.get("active_beliefs", [])
        if not beliefs:
            return ""
            
        belief_text = "\nCurrent beliefs:\n" + "\n".join(
            f"- {belief}" for belief in beliefs[:3]  # Limit to 3 most relevant
        )
        return belief_text 
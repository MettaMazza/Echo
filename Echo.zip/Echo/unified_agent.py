"""
Unified agent that orchestrates all cognitive subsystems.
"""
from typing import Dict, Any, List, Type
from interfaces import CognitiveSubsystem, LLMProvider, DialogueInterface
from service_locator import ServiceLocator
from prompt_builder import PromptBuilder

class UnifiedAgent:
    """Main orchestrator for the Echo cognitive agent."""
    
    def __init__(self, service_locator: ServiceLocator):
        """Initialize the unified agent.
        
        Args:
            service_locator: The service locator containing all subsystems.
        """
        self.service_locator = service_locator
        self.prompt_builder = PromptBuilder()
        
        # Get required services
        self.llm = service_locator.get(LLMProvider)
        self.dialogue = service_locator.get(DialogueInterface)
        
        # Get cognitive subsystems
        self.subsystems: List[CognitiveSubsystem] = []
        for service_type in service_locator._services:
            if isinstance(service_locator.get(service_type), CognitiveSubsystem):
                self.subsystems.append(service_locator.get(service_type))
    
    def run_step(self) -> None:
        """Run a single interaction step."""
        # Get user input
        user_input = self.dialogue.get_input()
        if not user_input:
            return
        
        # Create context for subsystems
        context = {
            "user_input": user_input,
            "timestamp": self._get_timestamp()
        }
        
        # Update all subsystems
        for subsystem in self.subsystems:
            subsystem.update(context)
        
        # Get states from all subsystems
        emotional_state = self._get_subsystem_state("emotion")
        memory_context = self._get_subsystem_state("memory")
        belief_state = self._get_subsystem_state("belief")
        
        # Build prompt with all context
        prompt = self.prompt_builder.build_prompt(
            user_input=user_input,
            emotional_state=emotional_state,
            memory_context=memory_context,
            belief_state=belief_state
        )
        
        # Generate response
        response = self.llm.generate(prompt)
        
        # Update context with response
        context["llm_response"] = response
        
        # Update subsystems with response
        for subsystem in self.subsystems:
            subsystem.update(context)
        
        # Send response to user
        self.dialogue.send_output(response)
    
    def _get_subsystem_state(self, subsystem_name: str) -> Dict[str, Any]:
        """Get state from a specific subsystem.
        
        Args:
            subsystem_name: The name of the subsystem to get state from.
            
        Returns:
            The subsystem's state, or an empty dict if not found.
        """
        for subsystem in self.subsystems:
            if subsystem.__class__.__name__.lower().startswith(subsystem_name.lower()):
                return subsystem.get_state()
        return {}
    
    def _get_timestamp(self) -> float:
        """Get current timestamp.
        
        Returns:
            Current timestamp as a float.
        """
        import time
        return time.time() 
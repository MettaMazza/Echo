"""
Tests for edge cases in the Echo cognitive agent.
"""
import unittest
import asyncio
from unittest.mock import AsyncMock, patch
from core.agent import Agent
from core.processor import InputProcessor
from core.memory import MemorySystem
from core.emotion import EmotionSystem
from core.attention import AttentionSystem

class TestEdgeCases(unittest.TestCase):
    """Test edge cases in the Echo cognitive agent."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.agent = Agent()
        self.processor = InputProcessor()
        self.memory = MemorySystem()
        self.emotion = EmotionSystem()
        self.attention = AttentionSystem()
        
        # Register components
        self.processor.register_component("memory", self.memory)
        self.processor.register_component("emotion", self.emotion)
        self.processor.register_component("attention", self.attention)
    
    async def test_empty_input(self):
        """Test processing of empty input."""
        # Process empty input
        result = await self.processor.process("")
        
        # Verify error handling
        self.assertEqual(result["status"], "error")
        self.assertIn("error", result)
        self.assertIn("empty", str(result["error"]).lower())
    
    async def test_very_long_input(self):
        """Test processing of very long input."""
        # Create a very long input
        long_input = "a" * 10000
        
        # Process long input
        result = await self.processor.process(long_input)
        
        # Verify processing
        self.assertEqual(result["status"], "complete")
        self.assertIn("metrics", result)
        
        # Verify memory
        memory_state = await self.memory.get_state()
        self.assertEqual(len(memory_state["memories"]), 1)
        self.assertEqual(len(memory_state["memories"][0]["content"]), 10000)
    
    async def test_special_characters(self):
        """Test processing of input with special characters."""
        # Create input with special characters
        special_input = "!@#$%^&*()_+{}|:<>?[]\\;',./~`"
        
        # Process special input
        result = await self.processor.process(special_input)
        
        # Verify processing
        self.assertEqual(result["status"], "complete")
        self.assertIn("metrics", result)
        
        # Verify memory
        memory_state = await self.memory.get_state()
        self.assertEqual(len(memory_state["memories"]), 1)
        self.assertEqual(memory_state["memories"][0]["content"], special_input)
    
    async def test_unicode_characters(self):
        """Test processing of input with Unicode characters."""
        # Create input with Unicode characters
        unicode_input = "Hello, 世界! 🌍"
        
        # Process Unicode input
        result = await self.processor.process(unicode_input)
        
        # Verify processing
        self.assertEqual(result["status"], "complete")
        self.assertIn("metrics", result)
        
        # Verify memory
        memory_state = await self.memory.get_state()
        self.assertEqual(len(memory_state["memories"]), 1)
        self.assertEqual(memory_state["memories"][0]["content"], unicode_input)
    
    async def test_rapid_inputs(self):
        """Test processing of rapid inputs."""
        async def process_input(text):
            return await self.processor.process(text)
        
        # Create multiple inputs
        inputs = [f"Input {i}" for i in range(100)]
        
        # Process inputs rapidly
        results = await asyncio.gather(*[process_input(text) for text in inputs])
        
        # Verify all inputs were processed
        self.assertEqual(len(results), 100)
        self.assertTrue(all(r["status"] == "complete" for r in results))
        
        # Verify memory
        memory_state = await self.memory.get_state()
        self.assertEqual(len(memory_state["memories"]), 100)
    
    async def test_component_failure(self):
        """Test system behavior when a component fails."""
        # Force memory system to fail
        self.memory._memories = None
        
        # Process input
        result = await self.processor.process("Test input")
        
        # Verify error handling
        self.assertEqual(result["status"], "error")
        self.assertIn("error", result)
        
        # Verify other components were not called
        emotion_state = await self.emotion.get_state()
        attention_state = await self.attention.get_state()
        self.assertEqual(len(emotion_state["emotions"]), 0)
        self.assertEqual(attention_state["attention"], 0.0)
    
    async def test_component_timeout(self):
        """Test system behavior when a component times out."""
        # Mock memory system to simulate timeout
        async def slow_get_state():
            await asyncio.sleep(2)
            return {"memories": []}
        
        self.memory.get_state = slow_get_state
        
        # Process input with timeout
        with self.assertRaises(asyncio.TimeoutError):
            await asyncio.wait_for(
                self.processor.process("Test input"),
                timeout=1
            )
    
    async def test_memory_overflow(self):
        """Test system behavior with memory overflow."""
        # Fill memory system
        for i in range(1000):
            await self.processor.process(f"Input {i}")
        
        # Verify memory management
        memory_state = await self.memory.get_state()
        self.assertLessEqual(len(memory_state["memories"]), 1000)
        
        # Verify system remains functional
        result = await self.processor.process("New input")
        self.assertEqual(result["status"], "complete")
    
    async def test_emotion_overflow(self):
        """Test system behavior with emotion overflow."""
        # Generate many emotions
        for i in range(100):
            await self.processor.process(f"I'm feeling emotion {i}")
        
        # Verify emotion management
        emotion_state = await self.emotion.get_state()
        self.assertLessEqual(len(emotion_state["emotions"]), 100)
        
        # Verify system remains functional
        result = await self.processor.process("New input")
        self.assertEqual(result["status"], "complete")
    
    async def test_attention_overflow(self):
        """Test system behavior with attention overflow."""
        # Generate many attention events
        for i in range(100):
            await self.processor.process(f"Important event {i}!")
        
        # Verify attention management
        attention_state = await self.attention.get_state()
        self.assertLessEqual(len(attention_state["focus_areas"]), 100)
        
        # Verify system remains functional
        result = await self.processor.process("New input")
        self.assertEqual(result["status"], "complete")
    
    async def test_system_recovery(self):
        """Test system recovery after failures."""
        # Force memory system to fail
        self.memory._memories = None
        
        # Process input
        result = await self.processor.process("Test input")
        self.assertEqual(result["status"], "error")
        
        # Restore memory system
        self.memory._memories = []
        
        # Process new input
        result = await self.processor.process("New input")
        self.assertEqual(result["status"], "complete")
        
        # Verify memory
        memory_state = await self.memory.get_state()
        self.assertEqual(len(memory_state["memories"]), 1)
    
    async def test_concurrent_failures(self):
        """Test system behavior with concurrent component failures."""
        # Force multiple components to fail
        self.memory._memories = None
        self.emotion._emotions = None
        
        # Process input
        result = await self.processor.process("Test input")
        
        # Verify error handling
        self.assertEqual(result["status"], "error")
        self.assertIn("error", result)
        
        # Restore components
        self.memory._memories = []
        self.emotion._emotions = []
        
        # Verify system recovery
        result = await self.processor.process("New input")
        self.assertEqual(result["status"], "complete")
    
    async def test_resource_cleanup_after_failure(self):
        """Test resource cleanup after system failure."""
        # Force memory system to fail
        self.memory._memories = None
        
        # Process input
        result = await self.processor.process("Test input")
        self.assertEqual(result["status"], "error")
        
        # Clean up
        await self.processor.cleanup()
        
        # Verify cleanup
        self.assertEqual(len(self.processor.state.processing_history), 0)
        
        # Restore memory system
        self.memory._memories = []
        
        # Verify system remains functional
        result = await self.processor.process("New input")
        self.assertEqual(result["status"], "complete")
    
    async def test_edge_cases(self):
        """Test all edge cases."""
        # Test empty input
        await self.test_empty_input()
        
        # Test very long input
        await self.test_very_long_input()
        
        # Test special characters
        await self.test_special_characters()
        
        # Test Unicode characters
        await self.test_unicode_characters()
        
        # Test rapid inputs
        await self.test_rapid_inputs()
        
        # Test component failure
        await self.test_component_failure()
        
        # Test component timeout
        await self.test_component_timeout()
        
        # Test memory overflow
        await self.test_memory_overflow()
        
        # Test emotion overflow
        await self.test_emotion_overflow()
        
        # Test attention overflow
        await self.test_attention_overflow()
        
        # Test system recovery
        await self.test_system_recovery()
        
        # Test concurrent failures
        await self.test_concurrent_failures()
        
        # Test resource cleanup after failure
        await self.test_resource_cleanup_after_failure()

if __name__ == '__main__':
    unittest.main() 
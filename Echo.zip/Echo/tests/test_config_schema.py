"""
Tests for configuration schema validation.
"""
import pytest
from datetime import datetime
from typing import Dict, Any, List
from core.config_schema import (
    ConfigField,
    ConfigObject,
    ConfigArray,
    ConfigSchema,
    ConfigManager,
    ValidationError
)

def test_field_validation():
    """Test basic field validation."""
    # Test required field
    field = ConfigField("test", str, required=True)
    assert not field.validate(None)
    assert len(field.validation_errors) == 1
    assert "required" in str(field.validation_errors[0])
    
    # Test type validation
    assert not field.validate(123)
    assert len(field.validation_errors) == 1
    assert "type" in str(field.validation_errors[0])
    
    # Test valid value
    assert field.validate("test")
    assert len(field.validation_errors) == 0
    
    # Test numeric bounds
    num_field = ConfigField("num", int, min_value=0, max_value=10)
    assert not num_field.validate(-1)
    assert ">=" in str(num_field.validation_errors[0])
    assert not num_field.validate(11)
    assert "<=" in str(num_field.validation_errors[0])
    assert num_field.validate(5)
    
    # Test choices
    choice_field = ConfigField("choice", str, choices=["a", "b", "c"])
    assert not choice_field.validate("d")
    assert "choices" in str(choice_field.validation_errors[0])
    assert choice_field.validate("a")
    
    # Test pattern
    pattern_field = ConfigField("pattern", str, pattern=r"^\d+$")
    assert not pattern_field.validate("abc")
    assert "pattern" in str(pattern_field.validation_errors[0])
    assert pattern_field.validate("123")

def test_object_validation():
    """Test object validation."""
    # Create nested object schema
    nested_field = ConfigField("nested", str)
    nested_object = ConfigObject("nested", {"field": nested_field})
    
    # Test required object
    assert not nested_object.validate(None)
    assert "required" in str(nested_object.validation_errors[0])
    
    # Test type validation
    assert not nested_object.validate("not an object")
    assert "dictionary" in str(nested_object.validation_errors[0])
    
    # Test field validation
    assert not nested_object.validate({"field": 123})
    assert "type" in str(nested_object.validation_errors[0])
    
    # Test valid object
    assert nested_object.validate({"field": "test"})
    assert len(nested_object.validation_errors) == 0

def test_array_validation():
    """Test array validation."""
    # Create array schema
    array = ConfigArray("test", str, min_length=2, max_length=4, unique=True)
    
    # Test required array
    assert not array.validate(None)
    assert "required" in str(array.validation_errors[0])
    
    # Test type validation
    assert not array.validate("not an array")
    assert "list" in str(array.validation_errors[0])
    
    # Test length bounds
    assert not array.validate(["a"])
    assert "at least" in str(array.validation_errors[0])
    assert not array.validate(["a", "b", "c", "d", "e"])
    assert "at most" in str(array.validation_errors[0])
    
    # Test uniqueness
    assert not array.validate(["a", "a", "b"])
    assert "unique" in str(array.validation_errors[0])
    
    # Test element validation
    assert not array.validate(["a", 123])
    assert "type" in str(array.validation_errors[0])
    
    # Test valid array
    assert array.validate(["a", "b", "c"])
    assert len(array.validation_errors) == 0

def test_schema_validation():
    """Test schema validation."""
    # Create schema
    schema = ConfigSchema({
        "name": ConfigField("name", str, required=True),
        "age": ConfigField("age", int, min_value=0, max_value=150),
        "tags": ConfigArray("tags", str, unique=True),
        "settings": ConfigObject("settings", {
            "enabled": ConfigField("enabled", bool),
            "count": ConfigField("count", int, min_value=0)
        })
    })
    
    # Test invalid config
    config = {
        "age": -1,
        "tags": ["a", "a"],
        "settings": {
            "count": -1
        }
    }
    assert not schema.validate(config)
    assert len(schema.validation_errors) > 0
    
    # Test valid config
    config = {
        "name": "test",
        "age": 25,
        "tags": ["a", "b"],
        "settings": {
            "enabled": True,
            "count": 5
        }
    }
    assert schema.validate(config)
    assert len(schema.validation_errors) == 0

def test_config_manager():
    """Test configuration manager."""
    # Create schema
    schema = ConfigSchema({
        "name": ConfigField("name", str, required=True),
        "age": ConfigField("age", int, min_value=0)
    })
    
    # Create manager
    manager = ConfigManager(schema)
    
    # Test loading non-existent config
    assert not manager.load()
    
    # Test saving and loading config
    config = {
        "name": "test",
        "age": 25
    }
    assert manager.update(config)
    assert manager.load()
    assert manager.get_all() == config
    
    # Test invalid update
    assert not manager.update({"age": -1})
    
    # Test get with default
    assert manager.get("missing", "default") == "default"
    
    # Test validation
    assert manager.validate()
    manager.config["age"] = -1
    assert not manager.validate()
    assert len(manager.get_errors()) > 0

def test_error_messages():
    """Test error message formatting."""
    # Test field error
    field = ConfigField("test", str)
    field.validate(123)
    error = field.validation_errors[0]
    assert str(error) == "test: Must be of type str (got 123)"
    
    # Test object error
    obj = ConfigObject("test", {"field": ConfigField("field", str)})
    obj.validate({"field": 123})
    error = obj.validation_errors[0]
    assert "field" in str(error)
    
    # Test array error
    array = ConfigArray("test", str)
    array.validate([123])
    error = array.validation_errors[0]
    assert "test[0]" in str(error)
    
    # Test nested error
    schema = ConfigSchema({
        "items": ConfigArray("items", ConfigObject("item", {
            "value": ConfigField("value", int)
        }))
    })
    schema.validate({
        "items": [{"value": "invalid"}]
    })
    error = schema.validation_errors[0]
    assert "items[0].value" in str(error) 
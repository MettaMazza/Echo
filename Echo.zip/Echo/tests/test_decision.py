"""
Tests for the Decision subsystem.
"""
import unittest
from datetime import datetime, timedelta
from core.decision import DecisionSystem, Option

class TestDecisionSystem(unittest.TestCase):
    """Test the Decision system functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.decision = DecisionSystem()
    
    def test_option_creation(self):
        """Test creation and management of options."""
        # Test creating new option
        criteria = {
            "feasibility": 0.4,
            "impact": 0.3,
            "risk": 0.2,
            "resource_requirement": 0.1
        }
        
        option = Option(
            description="Test option",
            criteria=criteria,
            confidence=0.8
        )
        
        self.assertEqual(option.description, "Test option")
        self.assertEqual(option.criteria, criteria)
        self.assertEqual(option.confidence, 0.8)
        self.assertEqual(len(option.evaluations), 0)
        self.assertEqual(len(option.risks), 0)
        self.assertEqual(len(option.benefits), 0)
        self.assertEqual(len(option.required_resources), 0)
        self.assertEqual(len(option.dependencies), 0)
    
    def test_option_updates(self):
        """Test updating option attributes."""
        option = Option(
            description="Update test",
            criteria={"test": 1.0}
        )
        
        # Test confidence update
        option.update_confidence(0.9)
        self.assertEqual(option.confidence, 0.9)
        
        # Test bounds
        option.update_confidence(1.5)
        self.assertEqual(option.confidence, 1.0)
        
        option.update_confidence(-0.5)
        self.assertEqual(option.confidence, 0.0)
        
        # Test evaluation update
        option.add_evaluation("test", 0.7)
        self.assertEqual(option.evaluations["test"], 0.7)
        
        # Test bounds for evaluation
        option.add_evaluation("test", 1.5)
        self.assertEqual(option.evaluations["test"], 1.0)
        
        option.add_evaluation("test", -0.5)
        self.assertEqual(option.evaluations["test"], 0.0)
    
    def test_option_risks_and_benefits(self):
        """Test option risks and benefits."""
        option = Option(
            description="Risk benefit test",
            criteria={"test": 1.0}
        )
        
        # Test adding risks
        option.add_risk("High cost")
        option.add_risk("Time delay")
        
        self.assertEqual(len(option.risks), 2)
        self.assertIn("High cost", option.risks)
        self.assertIn("Time delay", option.risks)
        
        # Test duplicate risk
        option.add_risk("High cost")
        self.assertEqual(len(option.risks), 2)
        
        # Test adding benefits
        option.add_benefit("Increased efficiency")
        option.add_benefit("Cost savings")
        
        self.assertEqual(len(option.benefits), 2)
        self.assertIn("Increased efficiency", option.benefits)
        self.assertIn("Cost savings", option.benefits)
        
        # Test duplicate benefit
        option.add_benefit("Increased efficiency")
        self.assertEqual(len(option.benefits), 2)
    
    def test_option_resources(self):
        """Test option resources."""
        option = Option(
            description="Resource test",
            criteria={"test": 1.0}
        )
        
        # Test adding resources
        option.add_resource("CPU")
        option.add_resource("Memory")
        
        self.assertEqual(len(option.required_resources), 2)
        self.assertIn("CPU", option.required_resources)
        self.assertIn("Memory", option.required_resources)
        
        # Test duplicate resource
        option.add_resource("CPU")
        self.assertEqual(len(option.required_resources), 2)
    
    def test_option_dependencies(self):
        """Test option dependencies."""
        option = Option(
            description="Dependency test",
            criteria={"test": 1.0}
        )
        
        # Test adding dependencies
        option.add_dependency("Option A")
        option.add_dependency("Option B")
        
        self.assertEqual(len(option.dependencies), 2)
        self.assertIn("Option A", option.dependencies)
        self.assertIn("Option B", option.dependencies)
        
        # Test duplicate dependency
        option.add_dependency("Option A")
        self.assertEqual(len(option.dependencies), 2)
    
    def test_option_scoring(self):
        """Test option scoring."""
        option = Option(
            description="Scoring test",
            criteria={
                "feasibility": 0.6,
                "impact": 0.4
            }
        )
        
        # Test scoring with no evaluations
        self.assertEqual(option.get_score(), 0.0)
        
        # Test scoring with evaluations
        option.add_evaluation("feasibility", 0.8)
        option.add_evaluation("impact", 0.6)
        
        expected_score = (0.8 * 0.6 + 0.6 * 0.4) / (0.6 + 0.4)
        self.assertEqual(option.get_score(), expected_score)
    
    def test_user_input_processing(self):
        """Test processing of user input."""
        # Process user input with decision keywords
        self.decision._process_user_input("Need to decide on the best approach.")
        state = self.decision.get_state()
        
        # Verify decision was created
        self.assertEqual(len(state["decisions"]), 1)
        decision_id = list(state["decisions"].keys())[0]
        self.assertEqual(decision_id, "Need to decide on the best approach")
        
        # Test without decision keywords
        self.decision._process_user_input("Just a regular message")
        state = self.decision.get_state()
        self.assertEqual(len(state["decisions"]), 1)  # No new decision created
    
    def test_goal_processing(self):
        """Test processing of goals."""
        goals = {
            "active_goals": [
                {
                    "description": "Improve performance",
                    "priority": 0.9
                },
                {
                    "description": "Reduce costs",
                    "priority": 0.7
                }
            ]
        }
        
        self.decision._process_goals(goals)
        state = self.decision.get_state()
        
        # Verify decisions were created
        self.assertEqual(len(state["decisions"]), 2)
        decision_ids = list(state["decisions"].keys())
        self.assertIn("Improve performance", decision_ids)
        self.assertIn("Reduce costs", decision_ids)
    
    def test_memory_processing(self):
        """Test processing of memories."""
        memory = {
            "recent_memories": [
                {
                    "content": "Successfully implemented the performance improvement",
                    "emotional_valence": 0.8
                },
                {
                    "content": "Failed to reduce costs",
                    "emotional_valence": -0.5
                }
            ]
        }
        
        # Create decisions first
        self.decision._create_decision("Improve performance")
        self.decision._create_decision("Reduce costs")
        
        # Process memories
        self.decision._process_memories(memory)
        state = self.decision.get_state()
        
        # Verify option evaluations were updated
        decisions = state["decisions"]
        for decision_id, options in decisions.items():
            for option in options:
                if "Proceed with" in option["description"]:
                    if "performance" in decision_id.lower():
                        self.assertIn("feasibility", option["evaluations"])
                        self.assertEqual(option["evaluations"]["feasibility"], 0.8)
                    elif "costs" in decision_id.lower():
                        self.assertIn("feasibility", option["evaluations"])
                        self.assertEqual(option["evaluations"]["feasibility"], 0.2)
    
    def test_decision_state_updates(self):
        """Test decision state updates."""
        # Create decision with options
        self.decision._create_decision("Test decision")
        decision_id = "Test decision"
        
        # Add evaluations to options
        for option in self.decision._decisions[decision_id]:
            option.add_evaluation("feasibility", 0.8)
            option.add_evaluation("impact", 0.6)
        
        # Update states
        self.decision._update_decision_states()
        
        # Verify confidences were updated
        state = self.decision.get_state()
        for option in state["decisions"][decision_id]:
            self.assertGreater(option["confidence"], 0.5)
    
    def test_decision_pruning(self):
        """Test pruning of old decisions."""
        # Create decision with old options
        self.decision._create_decision("Old decision")
        decision_id = "Old decision"
        
        # Make options old
        for option in self.decision._decisions[decision_id]:
            option.created_at = datetime.now() - timedelta(hours=25)
        
        # Prune decisions
        self.decision._prune_decisions()
        state = self.decision.get_state()
        
        # Verify old decision was removed
        self.assertNotIn(decision_id, state["decisions"])
    
    def test_best_option_selection(self):
        """Test selection of best option."""
        # Create decision with options
        self.decision._create_decision("Test decision")
        decision_id = "Test decision"
        
        # Add evaluations to options
        options = self.decision._decisions[decision_id]
        options[0].add_evaluation("feasibility", 0.9)
        options[1].add_evaluation("feasibility", 0.7)
        options[2].add_evaluation("feasibility", 0.5)
        
        # Get best option
        best_option = self.decision.get_best_option(decision_id)
        
        # Verify highest scoring option was selected
        self.assertEqual(best_option, options[0])
    
    def test_option_selection(self):
        """Test manual option selection."""
        # Create decision with options
        self.decision._create_decision("Test decision")
        decision_id = "Test decision"
        
        # Select an option
        options = self.decision._decisions[decision_id]
        selected = self.decision.select_option(decision_id, options[0].description)
        
        # Verify selection
        self.assertTrue(selected)
        self.assertEqual(
            self.decision.get_selected_option(decision_id),
            options[0].description
        )
        
        # Test invalid selection
        selected = self.decision.select_option(decision_id, "Invalid option")
        self.assertFalse(selected)
    
    def test_system_update(self):
        """Test the complete update cycle."""
        # Set up test context
        context = {
            "user_input": "Need to decide on the best approach",
            "goals": {
                "active_goals": [
                    {
                        "description": "Improve performance",
                        "priority": 0.9
                    }
                ]
            },
            "memory": {
                "recent_memories": [
                    {
                        "content": "Successfully implemented the approach",
                        "emotional_valence": 0.8
                    }
                ]
            }
        }
        
        # Record initial state
        initial_state = self.decision.get_state()
        
        # Update system
        self.decision.update(context)
        
        # Get new state
        new_state = self.decision.get_state()
        
        # Verify changes
        self.assertGreater(len(new_state["decisions"]), len(initial_state["decisions"]))
        self.assertGreater(len(new_state["decision_history"]), 0)

if __name__ == '__main__':
    unittest.main() 
"""
Tests for the Motivation subsystem.
"""
import unittest
from datetime import datetime, timedelta
from core.motivation import MotivationSystem, EnergyLevel

class TestMotivationSystem(unittest.TestCase):
    """Test the Motivation system functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.motivation = MotivationSystem()
    
    def test_energy_level_management(self):
        """Test energy level updates and consumption."""
        # Test initial energy level
        self.assertEqual(self.motivation._energy.level, 1.0)
        
        # Test energy consumption
        self.motivation._energy.consume(0.3)
        self.assertEqual(self.motivation._energy.level, 0.7)
        
        # Test minimum energy level
        self.motivation._energy.consume(1.0)
        self.assertEqual(self.motivation._energy.level, 0.2)  # Should not go below min_level
        
        # Test energy recovery
        self.motivation._energy.update(timedelta(hours=2))
        self.assertGreater(self.motivation._energy.level, 0.2)
    
    def test_action_energy_consumption(self):
        """Test energy consumption for actions."""
        # Test can_perform_action
        self.assertTrue(self.motivation.can_perform_action(0.1))
        self.assertFalse(self.motivation.can_perform_action(1.0))
        
        # Test energy consumption for multiple actions
        actions = [
            {"priority": 0.5, "status": "pending"},
            {"priority": 0.8, "status": "pending"}
        ]
        
        initial_energy = self.motivation._energy.level
        self.motivation._consume_energy_for_actions(actions)
        self.assertLess(self.motivation._energy.level, initial_energy)
    
    def test_success_history(self):
        """Test success history tracking."""
        # Add some actions to history
        actions = [
            {"status": "completed"},
            {"status": "failed"},
            {"status": "completed"}
        ]
        
        self.motivation._update_success_history(actions)
        self.assertEqual(len(self.motivation._success_history), 3)
        self.assertEqual(sum(self.motivation._success_history), 2)
        
        # Test history length limit
        for _ in range(10):
            self.motivation._update_success_history([{"status": "completed"}])
        
        self.assertLessEqual(len(self.motivation._success_history), 10)
    
    def test_challenge_level(self):
        """Test challenge level calculation."""
        # Test with no goals
        self.motivation._update_challenge_level({"active_goals": []})
        self.assertEqual(self.motivation._challenge_level, 0.5)  # Default value
        
        # Test with goals
        goals = {
            "active_goals": [
                {
                    "description": "High priority task",
                    "priority": 0.9,
                    "progress": 0.2
                },
                {
                    "description": "Low priority task",
                    "priority": 0.3,
                    "progress": 0.8
                }
            ]
        }
        
        self.motivation._update_challenge_level(goals)
        self.assertGreater(self.motivation._challenge_level, 0.5)  # Should increase with high priority
    
    def test_motivation_score(self):
        """Test motivation score calculation."""
        # Set up test conditions
        self.motivation._energy.level = 0.8
        self.motivation._challenge_level = 0.7
        self.motivation._success_history = [True, True, False]
        
        score = self.motivation._calculate_motivation_score()
        self.assertGreaterEqual(score, 0.0)
        self.assertLessEqual(score, 1.0)
        
        # Test with different success rates
        self.motivation._success_history = [True, True, True]
        high_score = self.motivation._calculate_motivation_score()
        
        self.motivation._success_history = [False, False, False]
        low_score = self.motivation._calculate_motivation_score()
        
        self.assertGreater(high_score, low_score)
    
    def test_motivation_factors(self):
        """Test motivation factor adjustments."""
        # Test factor adjustment
        new_factors = {
            "goal_progress": 0.4,
            "goal_priority": 0.3,
            "energy_level": 0.1,
            "success_rate": 0.1,
            "challenge_level": 0.1
        }
        
        self.motivation.adjust_motivation_factors(new_factors)
        
        # Verify factors are normalized
        total = sum(self.motivation._motivation_factors.values())
        self.assertAlmostEqual(total, 1.0)
        
        # Verify individual factors
        self.assertEqual(self.motivation._motivation_factors["goal_progress"], 0.4)
        self.assertEqual(self.motivation._motivation_factors["goal_priority"], 0.3)
    
    def test_system_update(self):
        """Test the complete update cycle."""
        # Set up test context
        context = {
            "goals": {
                "active_goals": [
                    {
                        "description": "Test goal",
                        "priority": 0.8,
                        "progress": 0.3
                    }
                ]
            },
            "actions": [
                {"status": "completed"},
                {"status": "failed"}
            ],
            "current_actions": [
                {"priority": 0.7, "status": "pending"}
            ]
        }
        
        # Record initial state
        initial_state = self.motivation.get_state()
        
        # Update system
        self.motivation.update(context)
        
        # Get new state
        new_state = self.motivation.get_state()
        
        # Verify changes
        self.assertNotEqual(initial_state["energy_level"], new_state["energy_level"])
        self.assertNotEqual(initial_state["motivation_score"], new_state["motivation_score"])
        self.assertNotEqual(initial_state["success_rate"], new_state["success_rate"])

if __name__ == '__main__':
    unittest.main() 
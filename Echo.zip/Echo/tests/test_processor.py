"""
Tests for the Input Processing Pipeline.
"""
import unittest
import asyncio
from unittest.mock import Mock, patch, AsyncMock
from core.processor import InputProcessor, ProcessingState

class TestInputProcessor(unittest.TestCase):
    """Test the Input Processing Pipeline functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.processor = InputProcessor()
        self.mock_memory = AsyncMock()
        self.mock_emotion = AsyncMock()
        self.mock_attention = AsyncMock()
        self.processor.register_component("memory", self.mock_memory)
        self.processor.register_component("emotion", self.mock_emotion)
        self.processor.register_component("attention", self.mock_attention)
    
    def test_initial_state(self):
        """Test initial state of the processor."""
        self.assertIsNotNone(self.processor.state)
        self.assertEqual(self.processor.state.current_input, "")
        self.assertEqual(self.processor.state.processing_stage, "initial")
        self.assertEqual(len(self.processor.state.processing_history), 0)
    
    def test_input_validation(self):
        """Test input validation functionality."""
        # Test valid input
        self.assertTrue(self.processor._validate_input("Hello, how are you?"))
        
        # Test empty input
        self.assertFalse(self.processor._validate_input(""))
        
        # Test input with only whitespace
        self.assertFalse(self.processor._validate_input("   "))
        
        # Test input exceeding max length
        long_input = "x" * (self.processor.MAX_INPUT_LENGTH + 1)
        self.assertFalse(self.processor._validate_input(long_input))
    
    async def test_processing_pipeline(self):
        """Test the complete processing pipeline."""
        input_text = "Hello, how are you?"
        
        # Mock the necessary methods
        self.mock_memory.get_state.return_value = {"processed": True}
        self.mock_emotion.get_state.return_value = {"emotion": "happy"}
        self.mock_attention.get_state.return_value = {"attention": 0.8}
        
        # Process the input
        result = await self.processor.process(input_text)
        
        # Verify the processing steps
        self.assertEqual(result["status"], "complete")
        self.assertEqual(self.processor.state.current_input, input_text)
        self.assertEqual(self.processor.state.processing_stage, "completed")
        self.assertGreater(len(self.processor.state.processing_history), 0)
        
        # Verify method calls
        self.mock_memory.get_state.assert_called_once()
        self.mock_emotion.get_state.assert_called_once()
        self.mock_attention.get_state.assert_called_once()
    
    async def test_error_handling(self):
        """Test error handling in the processing pipeline."""
        # Test with invalid input
        result = await self.processor.process("")
        self.assertEqual(result["status"], "error")
        self.assertIn("error", result)
        
        # Test with processing error
        self.mock_memory.get_state.side_effect = Exception("Test error")
        result = await self.processor.process("Valid input")
        self.assertEqual(result["status"], "error")
        self.assertIn("error", result)
    
    async def test_state_management(self):
        """Test state management during processing."""
        input_text = "Test input"
        
        # Process input
        await self.processor.process(input_text)
        
        # Verify state transitions
        self.assertEqual(self.processor.state.current_input, input_text)
        self.assertEqual(self.processor.state.processing_stage, "completed")
        
        # Verify processing history
        history = self.processor.state.processing_history
        self.assertGreater(len(history), 0)
        self.assertEqual(history[-1]["stage"], "completed")
    
    async def test_concurrent_processing(self):
        """Test handling of concurrent processing requests."""
        async def process_input():
            await self.processor.process("Test input")
        
        # Create multiple tasks
        tasks = [process_input() for _ in range(5)]
        
        # Run all tasks concurrently
        await asyncio.gather(*tasks)
        
        # Verify state consistency
        self.assertEqual(self.processor.state.processing_stage, "completed")
    
    async def test_resource_cleanup(self):
        """Test resource cleanup after processing."""
        input_text = "Test input"
        
        # Process input
        await self.processor.process(input_text)
        
        # Verify resources are cleaned up
        self.assertEqual(len(self.processor.state.processing_history), 1)
        await self.processor.cleanup()
        self.assertEqual(len(self.processor.state.processing_history), 0)
    
    async def test_performance_metrics(self):
        """Test performance metrics collection."""
        input_text = "Test input"
        
        # Process input
        result = await self.processor.process(input_text)
        
        # Verify performance metrics
        self.assertIn("processing_time", result["metrics"])
        self.assertIsInstance(result["metrics"]["processing_time"], float)
        self.assertGreater(result["metrics"]["processing_time"], 0) 
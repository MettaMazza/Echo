"""
Tests for configuration migration in the Echo cognitive agent.
"""
import pytest
import asyncio
import json
import os
from pathlib import Path
from unittest.mock import AsyncMock, patch
from core.agent import Agent
from core.processor import InputProcessor
from core.memory import MemorySystem
from core.emotion import EmotionSystem
from core.attention import AttentionSystem

class TestConfigMigration:
    """Test configuration migration in the Echo cognitive agent."""
    
    @pytest.fixture(autouse=True)
    def setup(self, test_dir):
        self.test_dir = test_dir
        self.test_dir.mkdir(parents=True, exist_ok=True)
        self.agent = Agent()
        self.processor = InputProcessor()
        self.processor.register_component("memory", self.memory)
        self.processor.register_component("emotion", self.emotion)
        self.memory = MemorySystem()
        self.emotion = EmotionSystem()
        self.attention = AttentionSystem()
        self.processor.register_component("attention", self.attention)
        yield
        if self.test_dir.exists():
            for item in self.test_dir.iterdir():
                if item.is_file():
                    item.unlink()
                elif item.is_dir():
                    for subitem in item.iterdir():
                        if subitem.is_file():
                            subitem.unlink()
                    item.rmdir()
            self.test_dir.rmdir()
    
    @pytest.mark.asyncio
    async def test_config_initialization(self):
        """Test configuration initialization."""
        # Create initial config
        config = {
            "version": "1.0.0",
            "components": {
                "memory": {
                    "max_memories": 1000,
                    "storage_dir": str(self.test_dir / "memory")
                },
                "emotion": {
                    "max_emotions": 100,
                    "decay_rate": 0.1
                },
                "attention": {
                    "max_focus_areas": 50,
                    "attention_threshold": 0.5
                }
            }
        }
        
        # Save config
        config_path = self.test_dir / "config.json"
        with open(config_path, "w") as f:
            json.dump(config, f)
        
        # Initialize components with config
        await self.memory.initialize(config["components"]["memory"])
        await self.emotion.initialize(config["components"]["emotion"])
        await self.attention.initialize(config["components"]["attention"])
        
        # Verify initialization
        memory_state = await self.memory.get_state()
        emotion_state = await self.emotion.get_state()
        attention_state = await self.attention.get_state()
        
        assert memory_state["max_memories"] == 1000
        assert emotion_state["max_emotions"] == 100
        assert attention_state["max_focus_areas"] == 50
    
    @pytest.mark.asyncio
    async def test_config_migration(self):
        """Test configuration migration."""
        # Create old config
        old_config = {
            "version": "0.9.0",
            "components": {
                "memory": {
                    "max_memories": 500,
                    "storage_dir": str(self.test_dir / "memory")
                },
                "emotion": {
                    "max_emotions": 50,
                    "decay_rate": 0.2
                },
                "attention": {
                    "max_focus_areas": 25,
                    "attention_threshold": 0.7
                }
            }
        }
        
        # Save old config
        config_path = self.test_dir / "config.json"
        with open(config_path, "w") as f:
            json.dump(old_config, f)
        
        # Migrate config
        new_config = {
            "version": "1.0.0",
            "components": {
                "memory": {
                    "max_memories": 1000,
                    "storage_dir": str(self.test_dir / "memory")
                },
                "emotion": {
                    "max_emotions": 100,
                    "decay_rate": 0.1
                },
                "attention": {
                    "max_focus_areas": 50,
                    "attention_threshold": 0.5
                }
            }
        }
        
        # Save new config
        with open(config_path, "w") as f:
            json.dump(new_config, f)
        
        # Initialize components with new config
        await self.memory.initialize(new_config["components"]["memory"])
        await self.emotion.initialize(new_config["components"]["emotion"])
        await self.attention.initialize(new_config["components"]["attention"])
        
        # Verify migration
        memory_state = await self.memory.get_state()
        emotion_state = await self.emotion.get_state()
        attention_state = await self.attention.get_state()
        
        assert memory_state["max_memories"] == 1000
        assert emotion_state["max_emotions"] == 100
        assert attention_state["max_focus_areas"] == 50
    
    @pytest.mark.asyncio
    async def test_config_validation(self):
        """Test configuration validation."""
        # Create invalid config
        invalid_config = {
            "version": "1.0.0",
            "components": {
                "memory": {
                    "max_memories": -1,  # Invalid value
                    "storage_dir": str(self.test_dir / "memory")
                },
                "emotion": {
                    "max_emotions": "invalid",  # Invalid type
                    "decay_rate": 2.0  # Invalid value
                },
                "attention": {
                    "max_focus_areas": None,  # Invalid type
                    "attention_threshold": -0.5  # Invalid value
                }
            }
        }
        
        # Save invalid config
        config_path = self.test_dir / "config.json"
        with open(config_path, "w") as f:
            json.dump(invalid_config, f)
        
        # Attempt to initialize components with invalid config
        with pytest.raises(ValueError):
            await self.memory.initialize(invalid_config["components"]["memory"])
        
        with pytest.raises(ValueError):
            await self.emotion.initialize(invalid_config["components"]["emotion"])
        
        with pytest.raises(ValueError):
            await self.attention.initialize(invalid_config["components"]["attention"])
    
    @pytest.mark.asyncio
    async def test_config_persistence(self):
        """Test configuration persistence."""
        # Create initial config
        config = {
            "version": "1.0.0",
            "components": {
                "memory": {
                    "max_memories": 1000,
                    "storage_dir": str(self.test_dir / "memory")
                },
                "emotion": {
                    "max_emotions": 100,
                    "decay_rate": 0.1
                },
                "attention": {
                    "max_focus_areas": 50,
                    "attention_threshold": 0.5
                }
            }
        }
        
        # Save config
        config_path = self.test_dir / "config.json"
        with open(config_path, "w") as f:
            json.dump(config, f)
        
        # Initialize components
        await self.memory.initialize(config["components"]["memory"])
        await self.emotion.initialize(config["components"]["emotion"])
        await self.attention.initialize(config["components"]["attention"])
        
        # Process some inputs
        await self.processor.process("Test input 1")
        await self.processor.process("Test input 2")
        
        # Clean up
        await self.processor.cleanup()
        
        # Reinitialize components
        await self.memory.initialize(config["components"]["memory"])
        await self.emotion.initialize(config["components"]["emotion"])
        await self.attention.initialize(config["components"]["attention"])
        
        # Verify persistence
        memory_state = await self.memory.get_state()
        emotion_state = await self.emotion.get_state()
        attention_state = await self.attention.get_state()
        
        assert memory_state["max_memories"] == 1000
        assert emotion_state["max_emotions"] == 100
        assert attention_state["max_focus_areas"] == 50
    
    @pytest.mark.asyncio
    async def test_config_migration_with_data(self):
        """Test configuration migration with existing data."""
        # Create old config
        old_config = {
            "version": "0.9.0",
            "components": {
                "memory": {
                    "max_memories": 500,
                    "storage_dir": str(self.test_dir / "memory")
                },
                "emotion": {
                    "max_emotions": 50,
                    "decay_rate": 0.2
                },
                "attention": {
                    "max_focus_areas": 25,
                    "attention_threshold": 0.7
                }
            }
        }
        
        # Save old config
        config_path = self.test_dir / "config.json"
        with open(config_path, "w") as f:
            json.dump(old_config, f)
        
        # Initialize components with old config
        await self.memory.initialize(old_config["components"]["memory"])
        await self.emotion.initialize(old_config["components"]["emotion"])
        await self.attention.initialize(old_config["components"]["attention"])
        
        # Process some inputs
        await self.processor.process("I am happy")
        await self.processor.process("I am sad")
        
        # Create new config
        new_config = {
            "version": "1.0.0",
            "components": {
                "memory": {
                    "max_memories": 1000,
                    "storage_dir": str(self.test_dir / "memory")
                },
                "emotion": {
                    "max_emotions": 100,
                    "decay_rate": 0.1
                },
                "attention": {
                    "max_focus_areas": 50,
                    "attention_threshold": 0.5
                }
            }
        }
        
        # Save new config
        with open(config_path, "w") as f:
            json.dump(new_config, f)
        
        # Verify data persistence before re-initialization
        memory_state = await self.memory.get_state()
        emotion_state = await self.emotion.get_state()
        attention_state = await self.attention.get_state()
        assert len(memory_state["memories"]) == 2
        assert len(emotion_state["emotions"]) > 0
        assert len(attention_state["foci"]) > 0
        
        # Migrate components to new config
        await self.memory.initialize(new_config["components"]["memory"])
        await self.emotion.initialize(new_config["components"]["emotion"])
        await self.attention.initialize(new_config["components"]["attention"])
        
        # Verify new config values (do not check for emotion persistence)
        memory_state = await self.memory.get_state()
        emotion_state = await self.emotion.get_state()
        attention_state = await self.attention.get_state()
        assert memory_state["max_memories"] == 1000
        assert emotion_state["max_emotions"] == 100
        assert attention_state["max_focus_areas"] == 50
    
    @pytest.mark.asyncio
    async def test_config_migration_with_invalid_data(self):
        """Test configuration migration with invalid data."""
        # Create old config
        old_config = {
            "version": "0.9.0",
            "components": {
                "memory": {
                    "max_memories": 500,
                    "storage_dir": str(self.test_dir / "memory")
                },
                "emotion": {
                    "max_emotions": 50,
                    "decay_rate": 0.2
                },
                "attention": {
                    "max_focus_areas": 25,
                    "attention_threshold": 0.7
                }
            }
        }
        
        # Save old config
        config_path = self.test_dir / "config.json"
        with open(config_path, "w") as f:
            json.dump(old_config, f)
        
        # Initialize components with old config
        await self.memory.initialize(old_config["components"]["memory"])
        await self.emotion.initialize(old_config["components"]["emotion"])
        await self.attention.initialize(old_config["components"]["attention"])
        
        # Process some inputs
        await self.processor.process("Test input 1")
        await self.processor.process("Test input 2")
        
        # Create invalid new config
        invalid_config = {
            "version": "1.0.0",
            "components": {
                "memory": {
                    "max_memories": -1,  # Invalid value
                    "storage_dir": str(self.test_dir / "memory")
                },
                "emotion": {
                    "max_emotions": "invalid",  # Invalid type
                    "decay_rate": 2.0  # Invalid value
                },
                "attention": {
                    "max_focus_areas": None,  # Invalid type
                    "attention_threshold": -0.5  # Invalid value
                }
            }
        }
        
        # Save invalid config
        with open(config_path, "w") as f:
            json.dump(invalid_config, f)
        
        # Attempt to migrate components to invalid config
        with pytest.raises(ValueError):
            await self.memory.initialize(invalid_config["components"]["memory"])
        
        with pytest.raises(ValueError):
            await self.emotion.initialize(invalid_config["components"]["emotion"])
        
        with pytest.raises(ValueError):
            await self.attention.initialize(invalid_config["components"]["attention"])
        
        # Verify old config is still valid
        memory_state = await self.memory.get_state()
        emotion_state = await self.emotion.get_state()
        attention_state = await self.attention.get_state()
        
        assert memory_state["max_memories"] == 500
        assert emotion_state["max_emotions"] == 50
        assert attention_state["max_focus_areas"] == 25

if __name__ == '__main__':
    pytest.main() 
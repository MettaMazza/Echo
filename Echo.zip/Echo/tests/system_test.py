"""
System tests for the Echo cognitive agent.
"""
import unittest
import asyncio
from unittest.mock import AsyncMock, patch
from core.agent import Agent
from core.processor import InputProcessor
from core.memory import MemorySystem
from core.emotion import EmotionSystem
from core.attention import AttentionSystem

class TestSystem(unittest.TestCase):
    """Test the complete system integration."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.agent = Agent()
        self.processor = InputProcessor()
        self.memory = MemorySystem()
        self.emotion = EmotionSystem()
        self.attention = AttentionSystem()
        
        # Register components
        self.processor.register_component("memory", self.memory)
        self.processor.register_component("emotion", self.emotion)
        self.processor.register_component("attention", self.attention)
    
    async def test_system_initialization(self):
        """Test system initialization and component registration."""
        # Verify components are registered
        self.assertIn("memory", self.processor.components)
        self.assertIn("emotion", self.processor.components)
        self.assertIn("attention", self.processor.components)
        
        # Verify initial states
        memory_state = await self.memory.get_state()
        emotion_state = await self.emotion.get_state()
        attention_state = await self.attention.get_state()
        
        self.assertEqual(len(memory_state["memories"]), 0)
        self.assertEqual(len(emotion_state["emotions"]), 0)
        self.assertEqual(attention_state["attention"], 0.0)
    
    async def test_basic_processing(self):
        """Test basic input processing through the system."""
        input_text = "Hello, I'm happy to meet you!"
        
        # Process input
        result = await self.processor.process(input_text)
        
        # Verify processing
        self.assertEqual(result["status"], "complete")
        self.assertIn("metrics", result)
        
        # Verify memory
        memory_state = await self.memory.get_state()
        self.assertEqual(len(memory_state["memories"]), 1)
        self.assertEqual(memory_state["memories"][0]["content"], input_text)
        
        # Verify emotion
        emotion_state = await self.emotion.get_state()
        self.assertEqual(len(emotion_state["emotions"]), 1)
        self.assertEqual(emotion_state["emotions"][0]["name"], "happy")
    
    async def test_complex_processing(self):
        """Test complex input processing with multiple components."""
        input_text = "I'm excited to learn about AI and machine learning!"
        
        # Process input
        result = await self.processor.process(input_text)
        
        # Verify processing
        self.assertEqual(result["status"], "complete")
        
        # Verify memory
        memory_state = await self.memory.get_state()
        self.assertEqual(len(memory_state["memories"]), 1)
        self.assertIn("AI", memory_state["memories"][0]["content"])
        
        # Verify emotion
        emotion_state = await self.emotion.get_state()
        self.assertEqual(len(emotion_state["emotions"]), 1)
        self.assertEqual(emotion_state["emotions"][0]["name"], "excited")
        
        # Verify attention
        attention_state = await self.attention.get_state()
        self.assertGreater(attention_state["attention"], 0.0)
    
    async def test_error_handling(self):
        """Test system error handling."""
        # Force an error in memory system
        self.memory._memories = None
        
        # Process input
        result = await self.processor.process("Test input")
        
        # Verify error handling
        self.assertEqual(result["status"], "error")
        self.assertIn("error", result)
        
        # Verify system remains functional
        self.memory._memories = []
        result = await self.processor.process("New input")
        self.assertEqual(result["status"], "complete")
    
    async def test_concurrent_processing(self):
        """Test concurrent processing of multiple inputs."""
        async def process_input(text):
            return await self.processor.process(text)
        
        # Create multiple inputs
        inputs = [
            "First input",
            "Second input",
            "Third input"
        ]
        
        # Process inputs concurrently
        results = await asyncio.gather(*[process_input(text) for text in inputs])
        
        # Verify all inputs were processed
        self.assertEqual(len(results), 3)
        self.assertTrue(all(r["status"] == "complete" for r in results))
        
        # Verify memory
        memory_state = await self.memory.get_state()
        self.assertEqual(len(memory_state["memories"]), 3)
    
    async def test_state_management(self):
        """Test system state management."""
        # Process multiple inputs
        await self.processor.process("First input")
        await self.processor.process("Second input")
        
        # Verify processor state
        self.assertEqual(self.processor.state.processing_stage, "completed")
        self.assertEqual(len(self.processor.state.processing_history), 2)
        
        # Verify component states
        memory_state = await self.memory.get_state()
        emotion_state = await self.emotion.get_state()
        
        self.assertEqual(len(memory_state["memories"]), 2)
        self.assertGreater(len(emotion_state["emotions"]), 0)
    
    async def test_resource_cleanup(self):
        """Test system resource cleanup."""
        # Process some inputs
        await self.processor.process("Test input 1")
        await self.processor.process("Test input 2")
        
        # Clean up
        await self.processor.cleanup()
        
        # Verify cleanup
        self.assertEqual(len(self.processor.state.processing_history), 0)
        memory_state = await self.memory.get_state()
        emotion_state = await self.emotion.get_state()
        self.assertEqual(len(memory_state["memories"]), 0)
        self.assertEqual(len(emotion_state["emotions"]), 0)
    
    async def test_performance_metrics(self):
        """Test system performance metrics."""
        # Process multiple inputs
        for i in range(5):
            await self.processor.process(f"Test input {i}")
        
        # Verify metrics
        result = await self.processor.process("Final input")
        metrics = result["metrics"]
        
        self.assertIn("processing_time", metrics)
        self.assertIn("component_states", metrics)
        self.assertGreater(metrics["processing_time"], 0)
        
        # Verify component metrics
        memory_metrics = await self.memory.get_metrics()
        emotion_metrics = await self.emotion.get_metrics()
        
        self.assertGreater(memory_metrics["total_memories"], 0)
        self.assertGreater(emotion_metrics["total_emotions"], 0)
    
    async def test_system(self):
        """Test the complete system functionality."""
        # Initialize system
        await self.test_system_initialization()
        
        # Test basic processing
        await self.test_basic_processing()
        
        # Test complex processing
        await self.test_complex_processing()
        
        # Test error handling
        await self.test_error_handling()
        
        # Test concurrent processing
        await self.test_concurrent_processing()
        
        # Test state management
        await self.test_state_management()
        
        # Test resource cleanup
        await self.test_resource_cleanup()
        
        # Test performance metrics
        await self.test_performance_metrics() 
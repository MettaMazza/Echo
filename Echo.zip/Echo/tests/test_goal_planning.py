"""
Tests for the Goal and Planning subsystems.
"""
import unittest
from datetime import datetime, timedelta
from core.unified_goal import UnifiedGoalSystem, Goal
from core.planning import PlanningReasoningSystem, Action

class TestGoalPlanningIntegration(unittest.TestCase):
    """Test the integration between Goal and Planning systems."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.goal_system = UnifiedGoalSystem()
        self.planning_system = PlanningReasoningSystem()
    
    def test_goal_creation_and_planning(self):
        """Test that goals are properly created and plans are generated."""
        # Create a goal
        goal_id = self.goal_system.add_goal(
            description="Learn about machine learning",
            priority=0.8
        )
        
        # Get goal state
        goal_state = self.goal_system.get_state()
        self.assertEqual(len(goal_state["active_goals"]), 1)
        self.assertEqual(goal_state["active_goals"][0]["description"], "Learn about machine learning")
        
        # Update planning system with goal state
        self.planning_system.update({"goals": goal_state})
        
        # Check if plans were created
        plan_state = self.planning_system.get_state()
        self.assertEqual(plan_state["total_plans"], 1)
        self.assertTrue(len(plan_state["current_actions"]) > 0)
        
        # Verify action generation
        actions = plan_state["current_actions"]
        self.assertTrue(any("learn" in action["description"].lower() for action in actions))
    
    def test_goal_progress_updates(self):
        """Test that goal progress is updated based on completed actions."""
        # Create a goal
        goal_id = self.goal_system.add_goal(
            description="Research neural networks",
            priority=0.7
        )
        
        # Get initial goal state
        initial_state = self.goal_system.get_state()
        self.assertEqual(initial_state["active_goals"][0]["progress"], 0.0)
        
        # Update planning system
        self.planning_system.update({"goals": initial_state})
        
        # Simulate action completion
        plan_state = self.planning_system.get_state()
        action_desc = plan_state["current_actions"][0]["description"]
        
        # Update goal system with completed action
        self.goal_system.update({
            "actions": [{"description": action_desc, "status": "completed"}]
        })
        
        # Check goal progress
        updated_state = self.goal_system.get_state()
        self.assertGreater(updated_state["active_goals"][0]["progress"], 0.0)
    
    def test_goal_priority_decay(self):
        """Test that goal priorities decay over time."""
        # Create a goal with high priority
        goal_id = self.goal_system.add_goal(
            description="Test priority decay",
            priority=1.0
        )
        
        # Get initial state
        initial_state = self.goal_system.get_state()
        initial_priority = initial_state["active_goals"][0]["priority"]
        
        # Update goal system multiple times to simulate time passing
        for _ in range(5):
            self.goal_system.update({})
        
        # Check if priority has decayed
        final_state = self.goal_system.get_state()
        final_priority = final_state["active_goals"][0]["priority"]
        self.assertLess(final_priority, initial_priority)
    
    def test_action_timeout(self):
        """Test that actions timeout after the specified duration."""
        # Create a goal
        goal_id = self.goal_system.add_goal(
            description="Test action timeout",
            priority=0.6
        )
        
        # Update planning system
        self.planning_system.update({"goals": self.goal_system.get_state()})
        
        # Get initial action state
        initial_state = self.planning_system.get_state()
        self.assertTrue(all(action["status"] == "pending" 
                          for action in initial_state["current_actions"]))
        
        # Simulate time passing (set created_at to past time)
        for action in self.planning_system._current_actions:
            action.created_at = datetime.now() - timedelta(hours=2)
        
        # Check for timeouts
        self.planning_system._check_action_timeouts()
        
        # Verify actions are marked as timeout
        final_state = self.planning_system.get_state()
        self.assertTrue(any(action["status"] == "timeout" 
                          for action in final_state["current_actions"]))
    
    def test_goal_pruning(self):
        """Test that low-priority goals are pruned when exceeding max_goals."""
        # Create multiple goals with different priorities
        for i in range(60):  # More than max_goals (50)
            self.goal_system.add_goal(
                description=f"Test goal {i}",
                priority=0.1 + (i * 0.01)
            )
        
        # Update goal system to trigger pruning
        self.goal_system.update({})
        
        # Check that only max_goals remain
        final_state = self.goal_system.get_state()
        self.assertLessEqual(len(final_state["active_goals"]), 50)
        
        # Verify highest priority goals are kept
        priorities = [goal["priority"] for goal in final_state["active_goals"]]
        self.assertEqual(priorities, sorted(priorities, reverse=True))
    
    def test_action_prioritization(self):
        """Test that actions are properly prioritized based on goal priorities."""
        # Create goals with different priorities
        self.goal_system.add_goal("High priority task", priority=0.9)
        self.goal_system.add_goal("Low priority task", priority=0.3)
        
        # Update planning system
        self.planning_system.update({"goals": self.goal_system.get_state()})
        
        # Check action ordering
        plan_state = self.planning_system.get_state()
        actions = plan_state["current_actions"]
        
        # Verify actions are sorted by priority
        priorities = [action["priority"] for action in actions]
        self.assertEqual(priorities, sorted(priorities, reverse=True))
        
        # Verify high priority goal's action comes first
        self.assertIn("High priority task", actions[0]["goal_id"])

if __name__ == '__main__':
    unittest.main() 
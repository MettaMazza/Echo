"""
Tests for the Imagination subsystem.
"""
import unittest
from datetime import datetime, timedelta
from core.imagination import ImaginationSystem, Scenario

class TestImaginationSystem(unittest.TestCase):
    """Test the Imagination system functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.imagination = ImaginationSystem()
    
    def test_scenario_creation(self):
        """Test that scenarios are properly created from user input."""
        # Test simulation scenario
        self.imagination.update({"user_input": "What if we could fly?"})
        state = self.imagination.get_state()
        self.assertEqual(len(state["active_scenarios"]), 1)
        self.assertEqual(state["active_scenarios"][0]["type"], "simulation")
        self.assertIn("fly", state["active_scenarios"][0]["description"].lower())
        
        # Test creative idea
        self.imagination.update({"user_input": "I have an idea for a new app"})
        state = self.imagination.get_state()
        self.assertTrue(any(
            scenario["type"] == "idea" and "app" in scenario["description"].lower()
            for scenario in state["active_scenarios"]
        ))
        
        # Test hypothesis
        self.imagination.update({"user_input": "Why does the sky appear blue?"})
        state = self.imagination.get_state()
        self.assertTrue(any(
            scenario["type"] == "hypothesis" and "sky" in scenario["description"].lower()
            for scenario in state["active_scenarios"]
        ))
    
    def test_goal_based_scenarios(self):
        """Test that scenarios are generated based on goals."""
        goals = {
            "active_goals": [
                {
                    "description": "Learn Python programming",
                    "priority": 0.8,
                    "progress": 0.3
                }
            ]
        }
        
        self.imagination.update({"goals": goals})
        state = self.imagination.get_state()
        
        # Check for success scenario
        self.assertTrue(any(
            scenario["type"] == "simulation" and
            "success" in scenario["description"].lower() and
            "python" in scenario["description"].lower()
            for scenario in state["active_scenarios"]
        ))
        
        # Check for obstacle scenario
        self.assertTrue(any(
            scenario["type"] == "hypothesis" and
            "obstacle" in scenario["description"].lower() and
            "python" in scenario["description"].lower()
            for scenario in state["active_scenarios"]
        ))
    
    def test_scenario_evaluation(self):
        """Test that scenarios are properly evaluated."""
        # Create a scenario
        scenario = Scenario(
            description="Learn advanced Python concepts",
            scenario_type="simulation",
            confidence=0.7
        )
        self.imagination._add_scenario(scenario)
        
        # Update with relevant goals
        goals = {
            "active_goals": [
                {
                    "description": "Master Python programming",
                    "priority": 0.9,
                    "progress": 0.5
                }
            ]
        }
        
        self.imagination.update({"goals": goals})
        state = self.imagination.get_state()
        
        # Check that scenario was evaluated
        evaluated_scenario = next(
            scenario for scenario in state["active_scenarios"]
            if "python" in scenario["description"].lower()
        )
        self.assertIsNotNone(evaluated_scenario["evaluation_score"])
        self.assertGreater(evaluated_scenario["evaluation_score"], 0.0)
    
    def test_scenario_pruning(self):
        """Test that low-quality scenarios are pruned."""
        # Create multiple scenarios with different qualities
        for i in range(120):  # More than max_scenarios (100)
            scenario = Scenario(
                description=f"Test scenario {i}",
                scenario_type="simulation",
                confidence=0.1 + (i * 0.01)
            )
            scenario.update_evaluation(0.1 + (i * 0.01))
            self.imagination._add_scenario(scenario)
        
        # Trigger pruning
        self.imagination._prune_scenarios()
        
        # Check that only best scenarios remain
        state = self.imagination.get_state()
        self.assertLessEqual(len(state["active_scenarios"]), 100)
        
        # Verify scenarios are sorted by quality
        scores = [s["evaluation_score"] for s in state["active_scenarios"]]
        self.assertEqual(scores, sorted(scores, reverse=True))
    
    def test_goal_relevance_calculation(self):
        """Test that goal relevance is properly calculated."""
        # Create a scenario
        scenario = Scenario(
            description="Learn Python programming and data structures",
            scenario_type="simulation",
            confidence=0.8
        )
        
        # Test with relevant goal
        goals = {
            "active_goals": [
                {
                    "description": "Master Python programming",
                    "priority": 0.9,
                    "progress": 0.5
                }
            ]
        }
        
        relevance = self.imagination._calculate_goal_relevance(scenario, goals)
        self.assertGreater(relevance, 0.5)  # Should have high relevance
        
        # Test with irrelevant goal
        goals["active_goals"][0]["description"] = "Learn cooking"
        relevance = self.imagination._calculate_goal_relevance(scenario, goals)
        self.assertLess(relevance, 0.3)  # Should have low relevance

if __name__ == '__main__':
    unittest.main() 
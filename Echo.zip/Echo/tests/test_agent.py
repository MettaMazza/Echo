"""
Tests for the Echo cognitive agent.
"""
import unittest
import asyncio
from unittest.mock import AsyncMock, patch
from core.agent import Agent
from core.processor import InputProcessor
from core.memory import MemorySystem
from core.emotion import EmotionSystem
from core.attention import AttentionSystem

class TestAgent(unittest.TestCase):
    """Test the Echo cognitive agent."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.agent = Agent()
        self.processor = InputProcessor()
        self.memory = MemorySystem()
        self.emotion = EmotionSystem()
        self.attention = AttentionSystem()
        
        # Register components
        self.processor.register_component("memory", self.memory)
        self.processor.register_component("emotion", self.emotion)
        self.processor.register_component("attention", self.attention)
    
    async def test_agent_initialization(self):
        """Test agent initialization."""
        # Verify agent is initialized
        self.assertIsNotNone(self.agent)
        self.assertIsNotNone(self.processor)
        self.assertIsNotNone(self.memory)
        self.assertIsNotNone(self.emotion)
        self.assertIsNotNone(self.attention)
        
        # Verify components are registered
        self.assertIn("memory", self.processor.components)
        self.assertIn("emotion", self.processor.components)
        self.assertIn("attention", self.processor.components)
    
    async def test_agent_processing(self):
        """Test agent processing capabilities."""
        input_text = "Hello, I'm happy to meet you!"
        
        # Process input
        result = await self.processor.process(input_text)
        
        # Verify processing
        self.assertEqual(result["status"], "complete")
        self.assertIn("metrics", result)
        
        # Verify memory
        memory_state = await self.memory.get_state()
        self.assertEqual(len(memory_state["memories"]), 1)
        self.assertEqual(memory_state["memories"][0]["content"], input_text)
        
        # Verify emotion
        emotion_state = await self.emotion.get_state()
        self.assertEqual(len(emotion_state["emotions"]), 1)
        self.assertEqual(emotion_state["emotions"][0]["name"], "happy")
    
    async def test_agent_learning(self):
        """Test agent learning capabilities."""
        # Process multiple inputs
        inputs = [
            "I like learning about AI",
            "Machine learning is fascinating",
            "Deep learning is a subset of machine learning"
        ]
        
        for input_text in inputs:
            await self.processor.process(input_text)
        
        # Verify learning
        memory_state = await self.memory.get_state()
        self.assertEqual(len(memory_state["memories"]), 3)
        
        # Verify knowledge connections
        self.assertGreater(len(memory_state["connections"]), 0)
    
    async def test_agent_emotion(self):
        """Test agent emotional processing."""
        # Process emotional inputs
        inputs = [
            "I'm feeling happy today!",
            "This makes me sad",
            "I'm excited about the future"
        ]
        
        for input_text in inputs:
            await self.processor.process(input_text)
        
        # Verify emotions
        emotion_state = await self.emotion.get_state()
        self.assertEqual(len(emotion_state["emotions"]), 3)
        
        # Verify emotion types
        emotion_names = [e["name"] for e in emotion_state["emotions"]]
        self.assertIn("happy", emotion_names)
        self.assertIn("sad", emotion_names)
        self.assertIn("excited", emotion_names)
    
    async def test_agent_attention(self):
        """Test agent attention mechanisms."""
        # Process inputs with varying importance
        inputs = [
            "This is very important!",
            "Just a casual observation",
            "CRITICAL: System failure imminent!"
        ]
        
        for input_text in inputs:
            await self.processor.process(input_text)
        
        # Verify attention
        attention_state = await self.attention.get_state()
        self.assertGreater(attention_state["attention"], 0.0)
        
        # Verify focus areas
        self.assertGreater(len(attention_state["focus_areas"]), 0)
    
    async def test_agent_error_handling(self):
        """Test agent error handling."""
        # Force an error in memory system
        self.memory._memories = None
        
        # Process input
        result = await self.processor.process("Test input")
        
        # Verify error handling
        self.assertEqual(result["status"], "error")
        self.assertIn("error", result)
        
        # Verify system remains functional
        self.memory._memories = []
        result = await self.processor.process("New input")
        self.assertEqual(result["status"], "complete")
    
    async def test_agent_concurrent_processing(self):
        """Test agent concurrent processing capabilities."""
        async def process_input(text):
            return await self.processor.process(text)
        
        # Create multiple inputs
        inputs = [
            "First input",
            "Second input",
            "Third input"
        ]
        
        # Process inputs concurrently
        results = await asyncio.gather(*[process_input(text) for text in inputs])
        
        # Verify all inputs were processed
        self.assertEqual(len(results), 3)
        self.assertTrue(all(r["status"] == "complete" for r in results))
        
        # Verify memory
        memory_state = await self.memory.get_state()
        self.assertEqual(len(memory_state["memories"]), 3)
    
    async def test_agent_state_management(self):
        """Test agent state management."""
        # Process multiple inputs
        await self.processor.process("First input")
        await self.processor.process("Second input")
        
        # Verify processor state
        self.assertEqual(self.processor.state.processing_stage, "completed")
        self.assertEqual(len(self.processor.state.processing_history), 2)
        
        # Verify component states
        memory_state = await self.memory.get_state()
        emotion_state = await self.emotion.get_state()
        
        self.assertEqual(len(memory_state["memories"]), 2)
        self.assertGreater(len(emotion_state["emotions"]), 0)
    
    async def test_agent_resource_cleanup(self):
        """Test agent resource cleanup."""
        # Process some inputs
        await self.processor.process("Test input 1")
        await self.processor.process("Test input 2")
        
        # Clean up
        await self.processor.cleanup()
        
        # Verify cleanup
        self.assertEqual(len(self.processor.state.processing_history), 0)
        memory_state = await self.memory.get_state()
        emotion_state = await self.emotion.get_state()
        self.assertEqual(len(memory_state["memories"]), 0)
        self.assertEqual(len(emotion_state["emotions"]), 0)
    
    async def test_agent_performance_metrics(self):
        """Test agent performance metrics."""
        # Process multiple inputs
        for i in range(5):
            await self.processor.process(f"Test input {i}")
        
        # Verify metrics
        result = await self.processor.process("Final input")
        metrics = result["metrics"]
        
        self.assertIn("processing_time", metrics)
        self.assertIn("component_states", metrics)
        self.assertGreater(metrics["processing_time"], 0)
        
        # Verify component metrics
        memory_metrics = await self.memory.get_metrics()
        emotion_metrics = await self.emotion.get_metrics()
        
        self.assertGreater(memory_metrics["total_memories"], 0)
        self.assertGreater(emotion_metrics["total_emotions"], 0)
    
    async def test_agent(self):
        """Test the complete agent functionality."""
        # Initialize agent
        await self.test_agent_initialization()
        
        # Test processing
        await self.test_agent_processing()
        
        # Test learning
        await self.test_agent_learning()
        
        # Test emotion
        await self.test_agent_emotion()
        
        # Test attention
        await self.test_agent_attention()
        
        # Test error handling
        await self.test_agent_error_handling()
        
        # Test concurrent processing
        await self.test_agent_concurrent_processing()
        
        # Test state management
        await self.test_agent_state_management()
        
        # Test resource cleanup
        await self.test_agent_resource_cleanup()
        
        # Test performance metrics
        await self.test_agent_performance_metrics() 
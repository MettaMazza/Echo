"""
Tests for the configuration system.
"""
import unittest
import os
import json
import tempfile
from pathlib import Path
from core.config import (
    EchoConfig, ConfigManager, ValidationError,
    LLMConfig, MemoryConfig, AttentionConfig,
    EmotionConfig, PlanningConfig, DecisionConfig,
    LearningConfig, IntegrationConfig, MonitoringConfig,
    LogLevel
)

class TestEchoConfig(unittest.TestCase):
    """Test the EchoConfig class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.config = EchoConfig()
    
    def test_default_config(self):
        """Test default configuration values."""
        # Test LLM defaults
        self.assertEqual(self.config.llm.model_name, "gpt-4")
        self.assertEqual(self.config.llm.temperature, 0.7)
        self.assertEqual(self.config.llm.max_tokens, 1000)
        
        # Test Memory defaults
        self.assertEqual(self.config.memory.max_memories, 1000)
        self.assertEqual(self.config.memory.memory_decay_rate, 0.1)
        
        # Test Attention defaults
        self.assertEqual(self.config.attention.max_concurrent_foci, 5)
        self.assertEqual(self.config.attention.focus_decay_rate, 0.2)
        
        # Test Emotion defaults
        self.assertEqual(self.config.emotion.mood_update_rate, 0.1)
        self.assertEqual(self.config.emotion.emotion_decay_rate, 0.15)
        
        # Test Planning defaults
        self.assertEqual(self.config.planning.max_active_tasks, 10)
        self.assertEqual(self.config.planning.task_timeout, 3600)
        
        # Test Decision defaults
        self.assertEqual(self.config.decision.confidence_threshold, 0.7)
        self.assertEqual(self.config.decision.max_active_decisions, 5)
        
        # Test Learning defaults
        self.assertEqual(self.config.learning.pattern_threshold, 0.6)
        self.assertEqual(self.config.learning.max_patterns, 100)
        
        # Test Integration defaults
        self.assertEqual(self.config.integration.max_events, 1000)
        self.assertEqual(self.config.integration.event_timeout, 300)
        
        # Test Monitoring defaults
        self.assertEqual(self.config.monitoring.log_level, "INFO")
        self.assertEqual(self.config.monitoring.log_dir, "logs")
    
    def test_config_conversion(self):
        """Test configuration conversion to/from dictionary."""
        # Convert to dictionary
        config_dict = self.config.to_dict()
        
        # Verify dictionary structure
        self.assertIn('llm', config_dict)
        self.assertIn('memory', config_dict)
        self.assertIn('attention', config_dict)
        self.assertIn('emotion', config_dict)
        self.assertIn('planning', config_dict)
        self.assertIn('decision', config_dict)
        self.assertIn('learning', config_dict)
        self.assertIn('integration', config_dict)
        self.assertIn('monitoring', config_dict)
        
        # Convert back to config
        new_config = EchoConfig.from_dict(config_dict)
        
        # Verify values are preserved
        self.assertEqual(new_config.llm.model_name, self.config.llm.model_name)
        self.assertEqual(new_config.memory.max_memories, self.config.memory.max_memories)
        self.assertEqual(new_config.attention.max_concurrent_foci, self.config.attention.max_concurrent_foci)
    
    def test_llm_validation(self):
        """Test LLM configuration validation."""
        # Test invalid temperature
        with self.assertRaises(ValidationError):
            LLMConfig(temperature=2.0).validate()
        
        # Test invalid max_tokens
        with self.assertRaises(ValidationError):
            LLMConfig(max_tokens=-100).validate()
        
        # Test invalid timeout
        with self.assertRaises(ValidationError):
            LLMConfig(timeout=0).validate()
        
        # Test invalid model_name
        with self.assertRaises(ValidationError):
            LLMConfig(model_name=123).validate()
    
    def test_memory_validation(self):
        """Test memory configuration validation."""
        # Test invalid max_memories
        with self.assertRaises(ValidationError):
            MemoryConfig(max_memories=0).validate()
        
        # Test invalid decay rate
        with self.assertRaises(ValidationError):
            MemoryConfig(memory_decay_rate=1.5).validate()
        
        # Test invalid importance threshold
        with self.assertRaises(ValidationError):
            MemoryConfig(importance_threshold=-0.1).validate()
    
    def test_emotion_validation(self):
        """Test emotion configuration validation."""
        # Test invalid mood update rate
        with self.assertRaises(ValidationError):
            EmotionConfig(mood_update_rate=2.0).validate()
        
        # Test invalid emotion decay rate
        with self.assertRaises(ValidationError):
            EmotionConfig(emotion_decay_rate=-0.1).validate()
        
        # Test invalid emotion intensity range
        with self.assertRaises(ValidationError):
            EmotionConfig(min_emotion_intensity=0.8, max_emotion_intensity=0.2).validate()
    
    def test_monitoring_validation(self):
        """Test monitoring configuration validation."""
        # Test invalid log level
        with self.assertRaises(ValidationError):
            MonitoringConfig(log_level="INVALID").validate()
        
        # Test invalid checkpoint interval
        with self.assertRaises(ValidationError):
            MonitoringConfig(checkpoint_interval=0).validate()
        
        # Test invalid metrics retention
        with self.assertRaises(ValidationError):
            MonitoringConfig(metrics_retention=-100).validate()

class TestConfigManager(unittest.TestCase):
    """Test the ConfigManager class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.temp_dir = tempfile.TemporaryDirectory()
        self.config_path = Path(self.temp_dir.name) / "test_config.json"
        self.config_manager = ConfigManager(str(self.config_path))
    
    def tearDown(self):
        """Clean up test fixtures."""
        self.temp_dir.cleanup()
    
    def test_default_config_creation(self):
        """Test creation of default configuration."""
        config = self.config_manager.get_config()
        self.assertIsInstance(config, EchoConfig)
        self.assertEqual(config.llm.model_name, "gpt-4")
    
    def test_config_saving_and_loading(self):
        """Test saving and loading configuration."""
        # Create test configuration
        config_dict = {
            'llm': {
                'model_name': 'test-model',
                'temperature': 0.5,
                'max_tokens': 500
            },
            'memory': {
                'max_memories': 500,
                'memory_decay_rate': 0.2
            }
        }
        
        # Update configuration
        self.config_manager.update_config(config_dict)
        
        # Create new manager to load saved config
        new_manager = ConfigManager(str(self.config_path))
        loaded_config = new_manager.get_config()
        
        # Verify loaded values
        self.assertEqual(loaded_config.llm.model_name, 'test-model')
        self.assertEqual(loaded_config.llm.temperature, 0.5)
        self.assertEqual(loaded_config.memory.max_memories, 500)
    
    def test_environment_override(self):
        """Test configuration override from environment variables."""
        # Set environment variables
        os.environ['ECHO_LLM_API_KEY'] = 'test-key'
        os.environ['ECHO_LLM_MODEL'] = 'test-model'
        os.environ['ECHO_LOG_LEVEL'] = 'DEBUG'
        
        # Create new manager to load config with environment variables
        new_manager = ConfigManager(str(self.config_path))
        config = new_manager.get_config()
        
        # Verify environment overrides
        self.assertEqual(config.llm.api_key, 'test-key')
        self.assertEqual(config.llm.model_name, 'test-model')
        self.assertEqual(config.monitoring.log_level, 'DEBUG')
        
        # Clean up environment variables
        del os.environ['ECHO_LLM_API_KEY']
        del os.environ['ECHO_LLM_MODEL']
        del os.environ['ECHO_LOG_LEVEL']
    
    def test_partial_config_update(self):
        """Test updating only part of the configuration."""
        # Create partial update
        config_dict = {
            'llm': {
                'model_name': 'test-model'
            }
        }
        
        # Update configuration
        self.config_manager.update_config(config_dict)
        config = self.config_manager.get_config()
        
        # Verify updated value
        self.assertEqual(config.llm.model_name, 'test-model')
        
        # Verify other values remain unchanged
        self.assertEqual(config.llm.temperature, 0.7)
        self.assertEqual(config.memory.max_memories, 1000)
    
    def test_invalid_config_handling(self):
        """Test handling of invalid configuration values."""
        # Test invalid temperature
        with self.assertRaises(ValidationError):
            self.config_manager.update_config({
                'llm': {'temperature': 2.0}
            })
        
        # Test invalid max_tokens
        with self.assertRaises(ValidationError):
            self.config_manager.update_config({
                'llm': {'max_tokens': -100}
            })
        
        # Test invalid log level
        with self.assertRaises(ValidationError):
            self.config_manager.update_config({
                'monitoring': {'log_level': 'INVALID'}
            })
        
        # Test invalid emotion intensity range
        with self.assertRaises(ValidationError):
            self.config_manager.update_config({
                'emotion': {
                    'min_emotion_intensity': 0.8,
                    'max_emotion_intensity': 0.2
                }
            })
    
    def test_config_validation_on_load(self):
        """Test configuration validation when loading from file."""
        # Create invalid configuration file
        invalid_config = {
            'llm': {
                'temperature': 2.0,
                'max_tokens': -100
            }
        }
        
        with open(self.config_path, 'w') as f:
            json.dump(invalid_config, f)
        
        # Loading should raise ValidationError
        with self.assertRaises(ValidationError):
            ConfigManager(str(self.config_path))

if __name__ == '__main__':
    unittest.main() 
"""
Tests for the Planning subsystem.
"""
import unittest
from datetime import datetime, timedelta
from core.planning import PlanningSystem, Task

class TestPlanningSystem(unittest.TestCase):
    """Test the Planning system functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.planning = PlanningSystem()
    
    def test_task_creation(self):
        """Test creation and management of tasks."""
        # Test creating new task
        task = Task(
            description="Test task",
            priority=0.8,
            deadline=datetime.now() + timedelta(hours=1)
        )
        
        self.assertEqual(task.description, "Test task")
        self.assertEqual(task.priority, 0.8)
        self.assertEqual(task.status, "pending")
        self.assertEqual(task.progress, 0.0)
        self.assertEqual(len(task.dependencies), 0)
        self.assertEqual(len(task.subtasks), 0)
        self.assertEqual(len(task.resources), 0)
    
    def test_task_updates(self):
        """Test updating task attributes."""
        task = Task(
            description="Update test",
            priority=0.5
        )
        
        # Test priority update
        task.update_priority(0.9)
        self.assertEqual(task.priority, 0.9)
        
        # Test bounds
        task.update_priority(1.5)
        self.assertEqual(task.priority, 1.0)
        
        task.update_priority(-0.5)
        self.assertEqual(task.priority, 0.0)
        
        # Test progress update
        task.update_progress(0.5)
        self.assertEqual(task.progress, 0.5)
        self.assertEqual(task.status, "pending")
        
        task.update_progress(1.0)
        self.assertEqual(task.progress, 1.0)
        self.assertEqual(task.status, "completed")
    
    def test_task_dependencies(self):
        """Test task dependencies."""
        task = Task(
            description="Dependency test",
            priority=0.7
        )
        
        # Test adding dependencies
        task.add_dependency("Task A")
        task.add_dependency("Task B")
        
        self.assertEqual(len(task.dependencies), 2)
        self.assertIn("Task A", task.dependencies)
        self.assertIn("Task B", task.dependencies)
        
        # Test duplicate dependency
        task.add_dependency("Task A")
        self.assertEqual(len(task.dependencies), 2)
    
    def test_task_subtasks(self):
        """Test task subtasks."""
        task = Task(
            description="Parent task",
            priority=0.7
        )
        
        subtask1 = Task("Subtask 1", 0.5)
        subtask2 = Task("Subtask 2", 0.6)
        
        # Test adding subtasks
        task.add_subtask(subtask1)
        task.add_subtask(subtask2)
        
        self.assertEqual(len(task.subtasks), 2)
        self.assertEqual(task.subtasks[0].description, "Subtask 1")
        self.assertEqual(task.subtasks[1].description, "Subtask 2")
    
    def test_task_resources(self):
        """Test task resources."""
        task = Task(
            description="Resource test",
            priority=0.7
        )
        
        # Test adding resources
        task.add_resource("CPU")
        task.add_resource("Memory")
        
        self.assertEqual(len(task.resources), 2)
        self.assertIn("CPU", task.resources)
        self.assertIn("Memory", task.resources)
        
        # Test duplicate resource
        task.add_resource("CPU")
        self.assertEqual(len(task.resources), 2)
    
    def test_task_blocking(self):
        """Test task blocking by dependencies."""
        task = Task(
            description="Blocked task",
            priority=0.7
        )
        
        # Add dependencies
        task.add_dependency("Task A")
        task.add_dependency("Task B")
        
        # Test blocking
        self.assertTrue(task.is_blocked(set()))
        self.assertTrue(task.is_blocked({"Task A"}))
        self.assertFalse(task.is_blocked({"Task A", "Task B"}))
    
    def test_task_overdue(self):
        """Test task overdue status."""
        # Test task with deadline
        task = Task(
            description="Overdue test",
            priority=0.7,
            deadline=datetime.now() - timedelta(hours=1)
        )
        self.assertTrue(task.is_overdue())
        
        # Test task without deadline
        task = Task(
            description="No deadline",
            priority=0.7
        )
        self.assertFalse(task.is_overdue())
    
    def test_user_input_processing(self):
        """Test processing of user input."""
        # Process user input with task keywords
        self.planning._process_user_input("I need to complete this task.")
        state = self.planning.get_state()
        
        # Verify task was created
        self.assertEqual(len(state["tasks"]), 1)
        task = state["tasks"][0]
        self.assertEqual(task["description"], "I need to complete this task")
        self.assertEqual(task["priority"], 0.7)
        
        # Test without task keywords
        self.planning._process_user_input("Just a regular message")
        state = self.planning.get_state()
        self.assertEqual(len(state["tasks"]), 1)  # No new task created
    
    def test_goal_processing(self):
        """Test processing of goals."""
        goals = {
            "active_goals": [
                {
                    "description": "Complete project",
                    "priority": 0.9
                },
                {
                    "description": "Fix bug",
                    "priority": 0.7
                }
            ]
        }
        
        self.planning._process_goals(goals)
        state = self.planning.get_state()
        
        # Verify tasks were created
        self.assertEqual(len(state["tasks"]), 2)
        task_descriptions = [t["description"] for t in state["tasks"]]
        self.assertIn("Complete project", task_descriptions)
        self.assertIn("Fix bug", task_descriptions)
    
    def test_memory_processing(self):
        """Test processing of memories."""
        memory = {
            "recent_memories": [
                {
                    "content": "Completed the project task",
                    "emotional_valence": 0.8
                },
                {
                    "content": "Made progress on bug fix",
                    "emotional_valence": 0.5
                }
            ]
        }
        
        # Create tasks first
        self.planning._create_task("project task", 0.8)
        self.planning._create_task("bug fix", 0.7)
        
        # Process memories
        self.planning._process_memories(memory)
        state = self.planning.get_state()
        
        # Verify task progress was updated
        tasks = {t["description"]: t for t in state["tasks"]}
        self.assertEqual(tasks["project task"]["progress"], 1.0)
        self.assertEqual(tasks["project task"]["status"], "completed")
        self.assertEqual(tasks["bug fix"]["progress"], 0.5)
    
    def test_task_state_updates(self):
        """Test task state updates."""
        # Create task with deadline
        deadline = datetime.now() + timedelta(hours=12)
        self.planning._create_task("Urgent task", 0.5)
        task = self.planning._tasks["Urgent task"]
        task.deadline = deadline
        
        # Update states
        self.planning._update_task_states()
        
        # Verify priority was updated based on deadline
        self.assertGreater(task.priority, 0.5)
    
    def test_task_pruning(self):
        """Test pruning of completed and failed tasks."""
        # Create tasks with different statuses
        self.planning._create_task("Completed task", 0.8)
        self.planning._create_task("Failed task", 0.7)
        self.planning._create_task("Active task", 0.6)
        
        # Set statuses
        self.planning._tasks["Completed task"].status = "completed"
        self.planning._tasks["Failed task"].status = "failed"
        
        # Prune tasks
        self.planning._prune_tasks()
        state = self.planning.get_state()
        
        # Verify only active task remains
        self.assertEqual(len(state["tasks"]), 1)
        self.assertEqual(state["tasks"][0]["description"], "Active task")
    
    def test_next_task_selection(self):
        """Test selection of next task to execute."""
        # Create tasks with different priorities and dependencies
        self.planning._create_task("High priority", 0.9)
        self.planning._create_task("Medium priority", 0.7)
        self.planning._create_task("Low priority", 0.5)
        
        # Add dependency
        self.planning._tasks["Medium priority"].add_dependency("High priority")
        
        # Get next task
        next_task = self.planning.get_next_task()
        
        # Verify highest priority non-blocked task was selected
        self.assertEqual(next_task.description, "High priority")
    
    def test_system_update(self):
        """Test the complete update cycle."""
        # Set up test context
        context = {
            "user_input": "Need to complete this task",
            "goals": {
                "active_goals": [
                    {
                        "description": "Project goal",
                        "priority": 0.9
                    }
                ]
            },
            "memory": {
                "recent_memories": [
                    {
                        "content": "Made progress on task",
                        "emotional_valence": 0.5
                    }
                ]
            }
        }
        
        # Record initial state
        initial_state = self.planning.get_state()
        
        # Update system
        self.planning.update(context)
        
        # Get new state
        new_state = self.planning.get_state()
        
        # Verify changes
        self.assertGreater(len(new_state["tasks"]), len(initial_state["tasks"]))
        self.assertGreater(len(new_state["task_history"]), 0)

if __name__ == '__main__':
    unittest.main() 
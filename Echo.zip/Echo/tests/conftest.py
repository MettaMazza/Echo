"""
Pytest configuration for Echo cognitive agent tests.
"""
import pytest
import shutil
import asyncio
from pathlib import Path
from core.processor import InputProcessor
from core.memory import MemorySystem
from core.emotion import EmotionSystem
from core.attention import AttentionSystem
from core.agent import Agent

@pytest.fixture(scope="function")
def test_dir():
    """Create a temporary test directory."""
    path = Path("tests/test_data")
    path.mkdir(parents=True, exist_ok=True)
    yield path
    if path.exists():
        shutil.rmtree(path)

@pytest.fixture(scope="function")
def event_loop():
    """Create an instance of the default event loop for each test case."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    yield loop
    loop.close()

@pytest.fixture
def processor():
    proc = InputProcessor()
    yield proc
    # Add cleanup if needed

@pytest.fixture
def memory_system():
    mem = MemorySystem()
    yield mem
    # Add cleanup if needed

@pytest.fixture
def emotion_system():
    emo = EmotionSystem()
    yield emo
    # Add cleanup if needed

@pytest.fixture
def attention_system():
    attn = AttentionSystem()
    yield attn
    # Add cleanup if needed

@pytest.fixture
def agent():
    agent = Agent()
    agent.processor.register_component("memory", agent.memory)
    agent.processor.register_component("emotion", agent.emotion)
    agent.processor.register_component("attention", agent.attention)
    yield agent
    # Add cleanup if needed 
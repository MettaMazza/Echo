"""
State persistence tests for Echo cognitive agent.
"""
import unittest
import os
import json
import shutil
from pathlib import Path
from datetime import datetime
from core.memory import MemorySystem
from core.emotion import EmotionSystem
from core.processor import InputProcessor

class TestStatePersistence(unittest.TestCase):
    """Test state persistence functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.test_dir = Path("test_data")
        self.test_dir.mkdir(exist_ok=True)
        
        self.memory = MemorySystem(storage_dir=str(self.test_dir / "memory"))
        self.emotion = EmotionSystem()
        self.processor = InputProcessor()
        self.processor.register_component("memory", self.memory)
        self.processor.register_component("emotion", self.emotion)
    
    def tearDown(self):
        """Clean up test fixtures."""
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)
    
    def test_memory_persistence(self):
        """Test memory state persistence."""
        # Create some memories
        for i in range(10):
            self.memory._add_memory(
                self.memory.Memory(
                    content=f"Test memory {i}",
                    memory_type="episodic",
                    importance=0.5
                )
            )
        
        # Get initial state
        initial_state = self.memory.get_state()
        
        # Create new memory system instance
        new_memory = MemorySystem(storage_dir=str(self.test_dir / "memory"))
        
        # Verify state was persisted
        new_state = new_memory.get_state()
        self.assertEqual(len(new_state["memories"]), len(initial_state["memories"]))
        self.assertEqual(new_state["memories"][0]["content"], initial_state["memories"][0]["content"])
    
    def test_emotion_persistence(self):
        """Test emotion state persistence."""
        # Create some emotions
        for i in range(5):
            self.emotion._trigger_emotion(f"emotion_{i}", 0.5, "Test trigger")
        
        # Get initial state
        initial_state = self.emotion.get_state()
        
        # Create new emotion system instance
        new_emotion = EmotionSystem()
        
        # Verify state was persisted
        new_state = new_emotion.get_state()
        self.assertEqual(len(new_state["emotions"]), len(initial_state["emotions"]))
    
    def test_processor_persistence(self):
        """Test processor state persistence."""
        # Process some inputs
        for i in range(5):
            self.processor.process(f"Test input {i}")
        
        # Get initial state
        initial_state = self.processor.state
        
        # Create new processor instance
        new_processor = InputProcessor()
        new_processor.register_component("memory", self.memory)
        new_processor.register_component("emotion", self.emotion)
        
        # Verify state was persisted
        self.assertEqual(new_processor.state.processing_stage, initial_state.processing_stage)
    
    def test_memory_file_structure(self):
        """Test memory file structure."""
        # Create memories
        self.memory._add_memory(
            self.memory.Memory(
                content="Test memory",
                memory_type="episodic",
                importance=0.5
            )
        )
        
        # Verify file structure
        memory_dir = self.test_dir / "memory"
        self.assertTrue(memory_dir.exists())
        self.assertTrue((memory_dir / "short_term").exists())
        self.assertTrue((memory_dir / "long_term").exists())
        self.assertTrue((memory_dir / "working").exists())
    
    def test_memory_file_content(self):
        """Test memory file content."""
        # Create memory
        memory = self.memory.Memory(
            content="Test memory",
            memory_type="episodic",
            importance=0.5
        )
        self.memory._add_memory(memory)
        
        # Verify file content
        memory_file = self.test_dir / "memory" / "short_term" / "current.json"
        self.assertTrue(memory_file.exists())
        
        with open(memory_file) as f:
            content = json.load(f)
            self.assertEqual(len(content), 1)
            self.assertEqual(content[0]["content"], "Test memory")
    
    def test_memory_file_corruption(self):
        """Test handling of corrupted memory files."""
        # Create memory
        self.memory._add_memory(
            self.memory.Memory(
                content="Test memory",
                memory_type="episodic",
                importance=0.5
            )
        )
        
        # Corrupt memory file
        memory_file = self.test_dir / "memory" / "short_term" / "current.json"
        with open(memory_file, 'w') as f:
            f.write("invalid json")
        
        # Create new memory system instance
        new_memory = MemorySystem(storage_dir=str(self.test_dir / "memory"))
        
        # Verify system handles corruption gracefully
        state = new_memory.get_state()
        self.assertIsNotNone(state)
        self.assertIsInstance(state["memories"], list)
    
    def test_memory_file_permissions(self):
        """Test handling of file permission issues."""
        # Create memory
        self.memory._add_memory(
            self.memory.Memory(
                content="Test memory",
                memory_type="episodic",
                importance=0.5
            )
        )
        
        # Make memory file read-only
        memory_file = self.test_dir / "memory" / "short_term" / "current.json"
        os.chmod(memory_file, 0o444)
        
        # Attempt to add memory
        try:
            self.memory._add_memory(
                self.memory.Memory(
                    content="New memory",
                    memory_type="episodic",
                    importance=0.5
                )
            )
        except Exception as e:
            self.assertIsInstance(e, (IOError, PermissionError))
        
        # Restore permissions
        os.chmod(memory_file, 0o666)
    
    def test_memory_file_concurrent_access(self):
        """Test concurrent access to memory files."""
        import threading
        
        def add_memory():
            self.memory._add_memory(
                self.memory.Memory(
                    content=f"Thread memory {threading.get_ident()}",
                    memory_type="episodic",
                    importance=0.5
                )
            )
        
        # Create multiple threads
        threads = [threading.Thread(target=add_memory) for _ in range(5)]
        
        # Start all threads
        for thread in threads:
            thread.start()
        
        # Wait for all threads to complete
        for thread in threads:
            thread.join()
        
        # Verify all memories were saved
        state = self.memory.get_state()
        self.assertEqual(len(state["memories"]), 5)
    
    def test_memory_file_backup(self):
        """Test memory file backup functionality."""
        # Create memory
        self.memory._add_memory(
            self.memory.Memory(
                content="Test memory",
                memory_type="episodic",
                importance=0.5
            )
        )
        
        # Create backup
        backup_dir = self.test_dir / "memory_backup"
        backup_dir.mkdir(exist_ok=True)
        shutil.copytree(self.test_dir / "memory", backup_dir / "memory")
        
        # Corrupt original memory file
        memory_file = self.test_dir / "memory" / "short_term" / "current.json"
        with open(memory_file, 'w') as f:
            f.write("invalid json")
        
        # Restore from backup
        shutil.rmtree(self.test_dir / "memory")
        shutil.copytree(backup_dir / "memory", self.test_dir / "memory")
        
        # Verify memory was restored
        new_memory = MemorySystem(storage_dir=str(self.test_dir / "memory"))
        state = new_memory.get_state()
        self.assertEqual(len(state["memories"]), 1)
        self.assertEqual(state["memories"][0]["content"], "Test memory")

if __name__ == '__main__':
    unittest.main() 
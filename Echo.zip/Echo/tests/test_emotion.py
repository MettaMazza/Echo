"""
Tests for the Emotion subsystem.
"""
import pytest
import asyncio
from datetime import datetime, timedelta
from core.emotion import EmotionSystem, Emotion

@pytest.mark.asyncio
class TestEmotionSystem:
    @pytest.fixture(autouse=True)
    def setup(self):
        self.emotion = EmotionSystem()

    async def test_emotion_creation(self):
        """Test creation and management of emotions."""
        emotion = Emotion(
            name="happy",
            intensity=0.8,
            duration=2.0
        )
        assert emotion.name == "happy"
        assert emotion.intensity == 0.8
        assert emotion.duration == 2.0
        # Remove triggers/related_emotions checks if not in implementation

    async def test_emotion_updates(self):
        """Test updating emotion attributes."""
        emotion = Emotion(
            name="sad",
            intensity=0.5
        )
        
        # Test intensity update
        emotion.update_intensity(0.9)
        assert emotion.intensity == 0.9
        
        # Test bounds
        emotion.update_intensity(1.5)
        assert emotion.intensity == 1.0
        
        emotion.update_intensity(-0.5)
        assert emotion.intensity == 0.0
    
    async def test_emotion_triggers(self):
        """Test emotion triggers."""
        emotion = Emotion(
            name="angry",
            intensity=0.7
        )
        
        # Test adding triggers
        emotion.add_trigger("User was rude")
        emotion.add_trigger("Task failed")
        
        assert len(emotion.triggers) == 2
        assert "User was rude" in emotion.triggers
        assert "Task failed" in emotion.triggers
        
        # Test duplicate trigger
        emotion.add_trigger("User was rude")
        assert len(emotion.triggers) == 2
    
    async def test_emotion_related(self):
        """Test related emotions."""
        emotion = Emotion(
            name="fearful",
            intensity=0.6
        )
        
        # Test adding related emotions
        emotion.add_related_emotion("anxious")
        emotion.add_related_emotion("worried")
        
        assert len(emotion.related_emotions) == 2
        assert "anxious" in emotion.related_emotions
        assert "worried" in emotion.related_emotions
        
        # Test duplicate related emotion
        emotion.add_related_emotion("anxious")
        assert len(emotion.related_emotions) == 2
    
    async def test_emotion_expiry(self):
        """Test emotion expiration."""
        emotion = Emotion(
            name="surprised",
            intensity=0.8,
            duration=1.0  # 1 hour duration
        )
        
        # Should not be expired immediately
        assert not emotion.is_expired()
        
        # Simulate time passing
        emotion.created_at = datetime.now() - timedelta(hours=2)
        assert emotion.is_expired()
    
    async def test_user_input_processing(self):
        """Test processing of user input."""
        await self.emotion._process_user_input("I'm so happy to see you!")
        state = await self.emotion.get_state()
        assert len(state["emotions"]) == 1
        emotion = state["emotions"][0]
        assert emotion["name"] == "happy"
        assert emotion["intensity"] > 0.0
        
        # Test negative emotion
        await self.emotion._process_user_input("I'm feeling sad today")
        state = await self.emotion.get_state()
        assert len(state["emotions"]) == 2
    
    async def test_goal_processing(self):
        """Test processing of goals."""
        goals = {
            "active_goals": [
                {
                    "description": "Complete project",
                    "priority": 0.9
                }
            ],
            "completed_goals": [
                {
                    "description": "Fix bug",
                    "priority": 0.7
                }
            ]
        }
        
        await self.emotion._process_goals(goals)
        state = await self.emotion.get_state()
        
        # Verify emotions were created
        assert len(state["emotions"]) == 2
        emotion_names = [e["name"] for e in state["emotions"]]
        assert "happy" in emotion_names
        assert "fearful" in emotion_names
    
    async def test_memory_processing(self):
        """Test processing of memories."""
        memory = {
            "recent_memories": [
                {
                    "content": "Great success!",
                    "emotional_valence": 0.8
                },
                {
                    "content": "Terrible failure",
                    "emotional_valence": -0.7
                }
            ]
        }
        
        await self.emotion._process_memories(memory)
        state = await self.emotion.get_state()
        
        # Verify emotions were created
        assert len(state["emotions"]) == 2
        emotion_names = [e["name"] for e in state["emotions"]]
        assert "happy" in emotion_names
        assert "sad" in emotion_names
    
    async def test_emotion_decay(self):
        """Test emotion intensity decay over time."""
        # Add an emotion
        await self.emotion._trigger_emotion("happy", 0.8, "Test trigger")
        
        # Get initial intensity
        initial_intensity = self.emotion._emotions["happy"].intensity
        
        # Simulate time passing
        self.emotion._last_update = datetime.now() - timedelta(hours=2)
        await self.emotion._update_emotional_states()
        
        # Verify intensity decayed
        new_intensity = self.emotion._emotions["happy"].intensity
        assert new_intensity < initial_intensity
    
    async def test_emotion_pruning(self):
        """Test pruning of expired and low-intensity emotions."""
        # Add multiple emotions
        await self.emotion._trigger_emotion("happy", 0.8, "High intensity")
        await self.emotion._trigger_emotion("sad", 0.2, "Low intensity")
        
        # Add expired emotion
        expired = Emotion("surprised", 0.7, 0.1)  # 6-minute duration
        expired.created_at = datetime.now() - timedelta(hours=1)
        self.emotion._emotions["surprised"] = expired
        
        # Prune emotions
        await self.emotion._prune_emotions()
        state = await self.emotion.get_state()
        
        # Verify only high-intensity, non-expired emotions remain
        assert len(state["emotions"]) == 1
        assert state["emotions"][0]["name"] == "happy"
    
    async def test_current_mood(self):
        """Test current mood calculation."""
        # Add emotions with different weights
        await self.emotion._trigger_emotion("happy", 0.8, "Positive")
        await self.emotion._trigger_emotion("sad", 0.6, "Negative")
        
        # Get current mood
        mood = await self.emotion.get_current_mood()
        
        # Verify mood is weighted average
        assert mood > 0.0  # Happy should outweigh sad
    
    async def test_emotional_response(self):
        """Test emotional response generation."""
        # Test positive mood
        await self.emotion._trigger_emotion("happy", 0.9, "Very positive")
        response = await self.emotion.get_emotional_response("test situation")
        assert "positive" in response.lower()
        
        # Test negative mood
        self.emotion._emotions.clear()
        await self.emotion._trigger_emotion("sad", 0.9, "Very negative")
        response = await self.emotion.get_emotional_response("test situation")
        assert "down" in response.lower()
        
        # Test neutral mood
        self.emotion._emotions.clear()
        response = await self.emotion.get_emotional_response("test situation")
        assert "neutral" in response.lower()
    
    async def test_system_update(self):
        """Test the complete update cycle."""
        # Set up test context
        context = {
            "user_input": "I'm feeling great today!",
            "goals": {
                "active_goals": [
                    {
                        "description": "Complete project",
                        "priority": 0.9
                    }
                ],
                "completed_goals": [
                    {
                        "description": "Fix bug",
                        "priority": 0.7
                    }
                ]
            },
            "memory": {
                "recent_memories": [
                    {
                        "content": "Great success!",
                        "emotional_valence": 0.8
                    }
                ]
            }
        }
        
        # Record initial state
        initial_state = await self.emotion.get_state()
        
        # Update system
        await self.emotion.update(context)
        
        # Get new state
        new_state = await self.emotion.get_state()
        
        # Verify changes
        assert len(new_state["emotions"]) > len(initial_state["emotions"])
        assert len(new_state["emotion_history"]) > 0

if __name__ == '__main__':
    pytest.main() 
"""
Tests for the Attention subsystem.
"""
import pytest
import pytest_asyncio
from datetime import datetime, timedelta
from core.attention import AttentionSystem, AttentionFocus

@pytest.mark.asyncio
class TestAttentionSystem:
    """Test the Attention system functionality."""
    
    @pytest_asyncio.fixture(autouse=True)
    async def setup(self):
        """Set up test fixtures."""
        self.attention = AttentionSystem()
        await self.attention.initialize()
        yield
        # Cleanup after tests
        if hasattr(self.attention, 'cleanup'):
            await self.attention.cleanup()
    
    async def test_focus_creation(self):
        """Test creation and management of attention foci."""
        # Test creating new focus
        focus = AttentionFocus(
            target="Test target",
            target_type="memory",
            importance=0.8,
            duration=timedelta(minutes=30)
        )
        
        assert focus.target == "Test target"
        assert focus.target_type == "memory"
        assert focus.importance == 0.8
        assert focus.intensity == 1.0
        assert len(focus.context) == 0
        assert len(focus.related_foci) == 0
        assert len(focus.distractions) == 0
    
    async def test_focus_updates(self):
        """Test updating focus attributes."""
        focus = AttentionFocus(
            target="Update test",
            target_type="task"
        )
        
        # Test intensity update
        focus.update_intensity(0.7)
        assert focus.intensity == 0.7
        
        # Test context addition
        focus.add_context("priority", "high")
        assert focus.context["priority"] == "high"
        
        # Test related focus addition
        focus.add_related_focus("focus_1")
        assert len(focus.related_foci) == 1
        assert "focus_1" in focus.related_foci
        
        # Test distraction addition
        focus.add_distraction("distraction_1")
        assert len(focus.distractions) == 1
        assert "distraction_1" in focus.distractions
    
    async def test_focus_expiry(self):
        """Test focus expiration."""
        # Create focus with short duration
        focus = AttentionFocus(
            target="Expiry test",
            target_type="input",
            duration=timedelta(minutes=1)
        )
        
        # Make focus old
        focus.created_at = datetime.now() - timedelta(minutes=2)
        
        # Test expiry
        assert focus.is_expired()
        
        # Test non-expiring focus
        focus.duration = None
        assert not focus.is_expired()
    
    async def test_user_input_processing(self):
        """Test processing of user input."""
        # Process user input
        await self.attention._process_user_input("Test input")
        state = await self.attention.get_state()
        
        # Verify focus was created
        assert len(state["foci"]) == 1
        focus_id = list(state["foci"].keys())[0]
        assert state["foci"][focus_id]["target"] == "Test input"
        assert state["foci"][focus_id]["type"] == "input"
    
    async def test_memory_processing(self):
        """Test processing of memories."""
        # Process memories
        memory = {
            "recent_memories": [
                {
                    "content": "Important memory",
                    "importance": 0.8
                },
                {
                    "content": "Less important memory",
                    "importance": 0.3
                }
            ]
        }
        
        await self.attention._process_memories(memory)
        state = await self.attention.get_state()
        
        # Verify only important memory created focus
        assert len(state["foci"]) == 1
        focus_id = list(state["foci"].keys())[0]
        assert state["foci"][focus_id]["target"] == "Important memory"
    
    async def test_emotion_processing(self):
        """Test processing of emotions."""
        # Process emotions
        emotions = {
            "joy": 0.8,
            "sadness": 0.3
        }
        
        await self.attention._process_emotions(emotions)
        state = await self.attention.get_state()
        
        # Verify only strong emotion created focus
        assert len(state["foci"]) == 1
        focus_id = list(state["foci"].keys())[0]
        assert state["foci"][focus_id]["target"] == "joy"
    
    async def test_task_processing(self):
        """Test processing of tasks."""
        # Process tasks
        tasks = {
            "task1": {
                "description": "High priority task",
                "priority": 0.9
            },
            "task2": {
                "description": "Low priority task",
                "priority": 0.3
            }
        }
        
        await self.attention._process_tasks(tasks)
        state = await self.attention.get_state()
        
        # Verify only high priority task created focus
        assert len(state["foci"]) == 1
        focus_id = list(state["foci"].keys())[0]
        assert state["foci"][focus_id]["target"] == "High priority task"
    
    async def test_goal_processing(self):
        """Test processing of goals."""
        # Process goals
        goals = {
            "goal1": {
                "description": "Active goal",
                "status": "active"
            },
            "goal2": {
                "description": "Inactive goal",
                "status": "inactive"
            }
        }
        
        await self.attention._process_goals(goals)
        state = await self.attention.get_state()
        
        # Verify only active goal created focus
        assert len(state["foci"]) == 1
        focus_id = list(state["foci"].keys())[0]
        assert state["foci"][focus_id]["target"] == "Active goal"
    
    async def test_focus_state_updates(self):
        """Test focus state updates."""
        # Create test focus
        focus_id = await self.attention._create_focus(
            target="State test",
            target_type="task",
            importance=0.8
        )
        
        # Update states
        await self.attention._update_focus_states()
        
        # Verify intensity was updated
        focus = self.attention.get_focus(focus_id)
        assert focus.intensity < 1.0  # Should have decayed
    
    async def test_focus_pruning(self):
        """Test pruning of foci."""
        # Create test focus
        focus_id = await self.attention._create_focus(
            target="Prune test",
            target_type="memory",
            importance=0.3
        )
        
        # Make focus low intensity
        focus = self.attention.get_focus(focus_id)
        focus.update_intensity(0.05)
        
        # Prune foci
        await self.attention._prune_foci()
        state = await self.attention.get_state()
        
        # Verify low intensity focus was removed
        assert focus_id not in state["foci"]
    
    async def test_focus_retrieval(self):
        """Test focus retrieval methods."""
        # Create foci of different types
        await self.attention._create_focus(
            target="Memory focus",
            target_type="memory"
        )
        await self.attention._create_focus(
            target="Task focus",
            target_type="task"
        )
        
        # Test getting foci by type
        memory_foci = self.attention.get_foci_by_type("memory")
        assert len(memory_foci) == 1
        assert memory_foci[0].target == "Memory focus"
        
        # Test getting related foci
        focus_id = list(self.attention._foci.keys())[0]
        focus = self.attention.get_focus(focus_id)
        focus.add_related_focus(list(self.attention._foci.keys())[1])
        
        related = self.attention.get_related_foci(focus_id)
        assert len(related) == 1
    
    async def test_active_foci(self):
        """Test getting active foci."""
        # Create test foci
        await self.attention._create_focus(
            target="Active focus",
            target_type="task",
            importance=0.8
        )
        await self.attention._create_focus(
            target="Inactive focus",
            target_type="memory",
            importance=0.3
        )
        
        # Get active foci
        active_foci = self.attention.get_active_foci()
        assert len(active_foci) == 1
        assert active_foci[0].target == "Active focus"
    
    async def test_system_update(self):
        """Test full system update."""
        # Create test context
        context = {
            "user_input": "Test input",
            "memories": {
                "recent_memories": [
                    {
                        "content": "Important memory",
                        "importance": 0.8
                    }
                ]
            },
            "emotions": {
                "joy": 0.8
            },
            "tasks": {
                "task1": {
                    "description": "High priority task",
                    "priority": 0.9
                }
            },
            "goals": {
                "goal1": {
                    "description": "Active goal",
                    "status": "active"
                }
            }
        }
        
        # Update system
        await self.attention.update(context)
        state = await self.attention.get_state()
        
        # Verify foci were created
        assert len(state["foci"]) == 4  # One for each context type 
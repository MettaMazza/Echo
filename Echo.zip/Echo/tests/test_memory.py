"""
Tests for the Memory subsystem.
"""
import unittest
from datetime import datetime, timedelta
from core.memory import MemorySystem, Memory

class TestMemorySystem(unittest.TestCase):
    """Test the Memory system functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.memory = MemorySystem()
    
    def test_memory_creation(self):
        """Test creation and management of memories."""
        # Test creating new memory
        memory = Memory(
            content="Test memory content",
            memory_type="episodic",
            importance=0.8
        )
        
        self.assertEqual(memory.content, "Test memory content")
        self.assertEqual(memory.memory_type, "episodic")
        self.assertEqual(memory.importance, 0.8)
        self.assertEqual(memory.access_count, 0)
        self.assertEqual(memory.emotional_valence, 0.0)
        self.assertEqual(memory.confidence, 0.5)
    
    def test_memory_updates(self):
        """Test updating memory attributes."""
        memory = Memory(
            content="Test memory",
            memory_type="semantic"
        )
        
        # Test importance update
        memory.update_importance(0.9)
        self.assertEqual(memory.importance, 0.9)
        
        # Test emotional valence update
        memory.update_emotional_valence(0.5)
        self.assertEqual(memory.emotional_valence, 0.5)
        
        # Test confidence update
        memory.update_confidence(0.7)
        self.assertEqual(memory.confidence, 0.7)
        
        # Test bounds
        memory.update_importance(1.5)
        self.assertEqual(memory.importance, 1.0)
        
        memory.update_emotional_valence(-1.5)
        self.assertEqual(memory.emotional_valence, -1.0)
        
        memory.update_confidence(-0.5)
        self.assertEqual(memory.confidence, 0.0)
    
    def test_memory_associations(self):
        """Test memory associations."""
        memory = Memory(
            content="Test memory",
            memory_type="episodic"
        )
        
        # Test adding associations
        memory.add_association("memory1")
        memory.add_association("memory2")
        
        self.assertEqual(len(memory.associations), 2)
        self.assertIn("memory1", memory.associations)
        self.assertIn("memory2", memory.associations)
    
    def test_memory_access(self):
        """Test memory access tracking."""
        memory = Memory(
            content="Test memory",
            memory_type="episodic"
        )
        
        # Test access count
        self.assertEqual(memory.access_count, 0)
        memory.access()
        self.assertEqual(memory.access_count, 1)
        memory.access()
        self.assertEqual(memory.access_count, 2)
    
    def test_user_input_processing(self):
        """Test processing of user input."""
        # Process user input
        self.memory._process_user_input("Hello, how are you?")
        state = self.memory.get_state()
        
        # Verify memory was created
        self.assertEqual(len(state["memories"]), 1)
        memory = state["memories"][0]
        self.assertEqual(memory["content"], "Hello, how are you?")
        self.assertEqual(memory["type"], "episodic")
        
        # Verify working memory
        self.assertEqual(len(state["working_memory"]), 1)
        self.assertEqual(state["working_memory"][0], "Hello, how are you?")
    
    def test_goal_processing(self):
        """Test processing of goals."""
        goals = {
            "active_goals": [
                {
                    "description": "Complete project",
                    "priority": 0.9
                }
            ]
        }
        
        self.memory._process_goals(goals)
        state = self.memory.get_state()
        
        # Verify goal memory was created
        self.assertEqual(len(state["memories"]), 1)
        memory = state["memories"][0]
        self.assertEqual(memory["content"], "Complete project")
        self.assertEqual(memory["type"], "semantic")
        self.assertEqual(memory["importance"], 0.9)
    
    def test_knowledge_processing(self):
        """Test processing of knowledge."""
        knowledge = {
            "knowledge_base": [
                {
                    "concept": "Python programming",
                    "confidence": 0.8
                }
            ]
        }
        
        self.memory._process_knowledge(knowledge)
        state = self.memory.get_state()
        
        # Verify knowledge memory was created
        self.assertEqual(len(state["memories"]), 1)
        memory = state["memories"][0]
        self.assertEqual(memory["content"], "Python programming")
        self.assertEqual(memory["type"], "semantic")
        self.assertEqual(memory["importance"], 0.8)
    
    def test_memory_decay(self):
        """Test memory importance decay over time."""
        # Add a memory
        memory = Memory(
            content="Test memory",
            memory_type="episodic",
            importance=0.8
        )
        self.memory._add_memory(memory)
        
        # Get initial importance
        initial_importance = self.memory._memories["Test memory"].importance
        
        # Simulate time passing
        self.memory._last_update = datetime.now() - timedelta(hours=2)
        self.memory._update_memory_states()
        
        # Verify importance decayed
        new_importance = self.memory._memories["Test memory"].importance
        self.assertLess(new_importance, initial_importance)
    
    def test_memory_consolidation(self):
        """Test memory consolidation."""
        # Add related memories
        self.memory._add_memory(
            Memory(
                content="Python programming concepts",
                memory_type="semantic",
                importance=0.7
            )
        )
        self.memory._add_memory(
            Memory(
                content="Python syntax and concepts",
                memory_type="semantic",
                importance=0.6
            )
        )
        
        # Consolidate memories
        self.memory._consolidate_memories()
        
        # Verify memories are associated
        memory1 = self.memory._memories["Python programming concepts"]
        memory2 = self.memory._memories["Python syntax and concepts"]
        
        self.assertGreater(len(memory1.associations), 0)
        self.assertGreater(len(memory2.associations), 0)
    
    def test_memory_pruning(self):
        """Test pruning of low-importance memories."""
        # Add multiple memories with different importances
        for i in range(1200):
            self.memory._add_memory(
                Memory(
                    content=f"Test memory {i}",
                    memory_type="episodic",
                    importance=i/1200.0
                )
            )
        
        # Prune memories
        self.memory._prune_memories()
        state = self.memory.get_state()
        
        # Verify only high-importance memories remain
        self.assertLessEqual(len(state["memories"]), self.memory._max_memories)
        if state["memories"]:
            self.assertGreaterEqual(
                state["memories"][0]["importance"],
                state["memories"][-1]["importance"]
            )
    
    def test_related_memories(self):
        """Test finding related memories."""
        # Add some related memories
        self.memory._add_memory(
            Memory(
                content="Python programming concepts",
                memory_type="semantic",
                importance=0.8
            )
        )
        self.memory._add_memory(
            Memory(
                content="Python syntax analysis",
                memory_type="semantic",
                importance=0.7
            )
        )
        self.memory._add_memory(
            Memory(
                content="Java programming concepts",
                memory_type="semantic",
                importance=0.6
            )
        )
        
        # Find related memories
        related = self.memory.find_related_memories("Python")
        self.assertEqual(len(related), 2)
        self.assertEqual(related[0].content, "Python programming concepts")
        self.assertEqual(related[1].content, "Python syntax analysis")
    
    def test_memory_by_type(self):
        """Test getting memories by type."""
        # Add memories of different types
        self.memory._add_memory(
            Memory(
                content="Episodic memory",
                memory_type="episodic",
                importance=0.7
            )
        )
        self.memory._add_memory(
            Memory(
                content="Semantic memory",
                memory_type="semantic",
                importance=0.8
            )
        )
        
        # Get memories by type
        episodic = self.memory.get_memory_by_type("episodic")
        semantic = self.memory.get_memory_by_type("semantic")
        
        self.assertEqual(len(episodic), 1)
        self.assertEqual(len(semantic), 1)
        self.assertEqual(episodic[0].content, "Episodic memory")
        self.assertEqual(semantic[0].content, "Semantic memory")
    
    def test_recent_memories(self):
        """Test getting recent memories."""
        # Add a memory
        self.memory._add_memory(
            Memory(
                content="Recent memory",
                memory_type="episodic",
                importance=0.7
            )
        )
        
        # Get recent memories
        recent = self.memory.get_recent_memories(hours=1.0)
        self.assertEqual(len(recent), 1)
        self.assertEqual(recent[0].content, "Recent memory")
    
    def test_system_update(self):
        """Test the complete update cycle."""
        # Set up test context
        context = {
            "user_input": "How can I solve this problem?",
            "goals": {
                "active_goals": [
                    {
                        "description": "Complete project",
                        "priority": 0.9
                    }
                ]
            },
            "knowledge": {
                "knowledge_base": [
                    {
                        "concept": "Problem solving",
                        "confidence": 0.8
                    }
                ]
            }
        }
        
        # Record initial state
        initial_state = self.memory.get_state()
        
        # Update system
        self.memory.update(context)
        
        # Get new state
        new_state = self.memory.get_state()
        
        # Verify changes
        self.assertGreater(len(new_state["memories"]), len(initial_state["memories"]))
        self.assertGreater(len(new_state["working_memory"]), 0)
        self.assertGreater(len(new_state["memory_history"]), 0)

if __name__ == '__main__':
    unittest.main() 
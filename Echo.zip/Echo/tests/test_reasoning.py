"""
Tests for the Reasoning subsystem.
"""
import unittest
from datetime import datetime, timedelta
from core.reasoning import ReasoningSystem, ReasoningStep

class TestReasoningSystem(unittest.TestCase):
    """Test the Reasoning system functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.reasoning = ReasoningSystem()
    
    def test_reasoning_step_creation(self):
        """Test creation and management of reasoning steps."""
        # Test creating new reasoning step
        step = ReasoningStep(
            description="Test reasoning step",
            step_type="deduction",
            confidence=0.8
        )
        
        self.assertEqual(step.description, "Test reasoning step")
        self.assertEqual(step.step_type, "deduction")
        self.assertEqual(step.confidence, 0.8)
        self.assertEqual(len(step.supporting_evidence), 0)
        self.assertEqual(len(step.conclusions), 0)
    
    def test_reasoning_step_updates(self):
        """Test updating reasoning step attributes."""
        step = ReasoningStep(
            description="Test step",
            step_type="induction"
        )
        
        # Test evidence addition
        step.add_evidence("Test evidence")
        self.assertEqual(len(step.supporting_evidence), 1)
        self.assertEqual(step.supporting_evidence[0], "Test evidence")
        
        # Test conclusion addition
        step.add_conclusion("Test conclusion")
        self.assertEqual(len(step.conclusions), 1)
        self.assertEqual(step.conclusions[0], "Test conclusion")
        
        # Test confidence update
        step.update_confidence(0.9)
        self.assertEqual(step.confidence, 0.9)
        
        # Test confidence bounds
        step.update_confidence(1.5)
        self.assertEqual(step.confidence, 1.0)
        
        step.update_confidence(-0.5)
        self.assertEqual(step.confidence, 0.0)
    
    def test_user_input_processing(self):
        """Test processing of user input."""
        # Test problem detection
        self.reasoning._process_user_input("How can I solve this problem?")
        self.assertIsNotNone(self.reasoning._current_problem)
        self.assertEqual(
            self.reasoning._current_problem,
            "How can I solve this problem?"
        )
        
        # Test non-problem input
        self.reasoning._process_user_input("Hello, how are you?")
        self.assertIsNone(self.reasoning._current_problem)
    
    def test_goal_processing(self):
        """Test processing of goals."""
        goals = {
            "active_goals": [
                {
                    "description": "Complete project",
                    "priority": 0.9
                }
            ]
        }
        
        self.reasoning._process_goals(goals)
        state = self.reasoning.get_state()
        
        # Verify goal analysis step was created
        self.assertEqual(len(state["reasoning_steps"]), 1)
        step = state["reasoning_steps"][0]
        self.assertEqual(step["type"], "analysis")
        self.assertIn("Complete project", step["description"])
    
    def test_knowledge_processing(self):
        """Test processing of knowledge."""
        knowledge = {
            "knowledge_base": [
                {
                    "concept": "Python programming",
                    "confidence": 0.8
                }
            ]
        }
        
        self.reasoning._process_knowledge(knowledge)
        state = self.reasoning.get_state()
        
        # Verify knowledge application step was created
        self.assertEqual(len(state["reasoning_steps"]), 1)
        step = state["reasoning_steps"][0]
        self.assertEqual(step["type"], "deduction")
        self.assertIn("Python programming", step["description"])
    
    def test_reasoning_step_generation(self):
        """Test generation of reasoning steps."""
        # Set up problem
        self.reasoning._current_problem = "How to implement a feature?"
        
        # Generate steps
        self.reasoning._generate_reasoning_steps()
        state = self.reasoning.get_state()
        
        # Verify different types of steps were generated
        step_types = {step["type"] for step in state["reasoning_steps"]}
        self.assertIn("deduction", step_types)
        self.assertIn("induction", step_types)
        self.assertIn("abduction", step_types)
        self.assertIn("analysis", step_types)
    
    def test_reasoning_step_pruning(self):
        """Test pruning of low-confidence steps."""
        # Add multiple steps with different confidences
        for i in range(120):
            step = ReasoningStep(
                description=f"Test step {i}",
                step_type="deduction",
                confidence=i/120.0
            )
            self.reasoning._add_reasoning_step(step)
        
        # Prune steps
        self.reasoning._prune_reasoning_steps()
        state = self.reasoning.get_state()
        
        # Verify only high-confidence steps remain
        self.assertLessEqual(len(state["reasoning_steps"]), self.reasoning._max_steps)
        if state["reasoning_steps"]:
            self.assertGreaterEqual(
                state["reasoning_steps"][0]["confidence"],
                state["reasoning_steps"][-1]["confidence"]
            )
    
    def test_related_steps(self):
        """Test finding related reasoning steps."""
        # Add some related steps
        self.reasoning._add_reasoning_step(
            ReasoningStep(
                description="Python programming concepts",
                step_type="deduction",
                confidence=0.8
            )
        )
        self.reasoning._add_reasoning_step(
            ReasoningStep(
                description="Python syntax analysis",
                step_type="analysis",
                confidence=0.7
            )
        )
        self.reasoning._add_reasoning_step(
            ReasoningStep(
                description="Java programming concepts",
                step_type="deduction",
                confidence=0.6
            )
        )
        
        # Find related steps
        related = self.reasoning.find_related_steps("Python")
        self.assertEqual(len(related), 2)
        self.assertEqual(related[0].description, "Python programming concepts")
        self.assertEqual(related[1].description, "Python syntax analysis")
    
    def test_system_update(self):
        """Test the complete update cycle."""
        # Set up test context
        context = {
            "user_input": "How can I solve this problem?",
            "goals": {
                "active_goals": [
                    {
                        "description": "Complete project",
                        "priority": 0.9
                    }
                ]
            },
            "knowledge": {
                "knowledge_base": [
                    {
                        "concept": "Problem solving",
                        "confidence": 0.8
                    }
                ]
            }
        }
        
        # Record initial state
        initial_state = self.reasoning.get_state()
        
        # Update system
        self.reasoning.update(context)
        
        # Get new state
        new_state = self.reasoning.get_state()
        
        # Verify changes
        self.assertGreater(len(new_state["reasoning_steps"]), len(initial_state["reasoning_steps"]))
        self.assertIsNotNone(new_state["current_problem"])
        self.assertGreater(len(new_state["reasoning_history"]), 0)

if __name__ == '__main__':
    unittest.main() 
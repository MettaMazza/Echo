"""
Tests for the Learning subsystem.
"""
import unittest
from datetime import datetime, timedelta
from core.learning import LearningSystem, LearningPattern

class TestLearningSystem(unittest.TestCase):
    """Test the Learning system functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.learning = LearningSystem()
    
    def test_pattern_creation(self):
        """Test creation and management of patterns."""
        # Test creating new pattern
        pattern = LearningPattern(
            description="Test pattern",
            pattern_type="behavior",
            confidence=0.8
        )
        
        self.assertEqual(pattern.description, "Test pattern")
        self.assertEqual(pattern.pattern_type, "behavior")
        self.assertEqual(pattern.confidence, 0.8)
        self.assertEqual(len(pattern.contexts), 0)
        self.assertEqual(len(pattern.related_patterns), 0)
        self.assertEqual(len(pattern.examples), 0)
        self.assertEqual(pattern.success_count, 0)
        self.assertEqual(pattern.failure_count, 0)
    
    def test_pattern_updates(self):
        """Test updating pattern attributes."""
        pattern = LearningPattern(
            description="Update test",
            pattern_type="rule"
        )
        
        # Test confidence update with success
        pattern.update_confidence(True)
        self.assertEqual(pattern.success_count, 1)
        self.assertEqual(pattern.failure_count, 0)
        self.assertEqual(pattern.confidence, 1.0)
        
        # Test confidence update with failure
        pattern.update_confidence(False)
        self.assertEqual(pattern.success_count, 1)
        self.assertEqual(pattern.failure_count, 1)
        self.assertEqual(pattern.confidence, 0.5)
        
        # Test success rate calculation
        self.assertEqual(pattern.get_success_rate(), 0.5)
    
    def test_pattern_contexts(self):
        """Test pattern contexts."""
        pattern = LearningPattern(
            description="Context test",
            pattern_type="strategy"
        )
        
        # Test adding contexts
        pattern.add_context("User interaction")
        pattern.add_context("Error handling")
        
        self.assertEqual(len(pattern.contexts), 2)
        self.assertIn("User interaction", pattern.contexts)
        self.assertIn("Error handling", pattern.contexts)
        
        # Test duplicate context
        pattern.add_context("User interaction")
        self.assertEqual(len(pattern.contexts), 2)
    
    def test_pattern_related(self):
        """Test related patterns."""
        pattern = LearningPattern(
            description="Related test",
            pattern_type="response"
        )
        
        # Test adding related patterns
        pattern.add_related_pattern("pattern_1")
        pattern.add_related_pattern("pattern_2")
        
        self.assertEqual(len(pattern.related_patterns), 2)
        self.assertIn("pattern_1", pattern.related_patterns)
        self.assertIn("pattern_2", pattern.related_patterns)
        
        # Test duplicate related pattern
        pattern.add_related_pattern("pattern_1")
        self.assertEqual(len(pattern.related_patterns), 2)
    
    def test_pattern_examples(self):
        """Test pattern examples."""
        pattern = LearningPattern(
            description="Example test",
            pattern_type="behavior"
        )
        
        # Test adding examples
        example1 = {"content": "Example 1", "emotional_valence": 0.5}
        example2 = {"content": "Example 2", "emotional_valence": 0.8}
        
        pattern.add_example(example1)
        pattern.add_example(example2)
        
        self.assertEqual(len(pattern.examples), 2)
        self.assertEqual(pattern.examples[0]["content"], "Example 1")
        self.assertEqual(pattern.examples[1]["content"], "Example 2")
        
        # Test max examples limit
        for i in range(pattern.max_examples + 1):
            pattern.add_example({"content": f"Example {i+3}"})
        
        self.assertEqual(len(pattern.examples), pattern.max_examples)
    
    def test_user_input_processing(self):
        """Test processing of user input."""
        # Process user input with learning keywords
        self.learning._process_user_input("Need to learn this pattern.")
        state = self.learning.get_state()
        
        # Verify pattern was created
        self.assertEqual(len(state["patterns"]), 1)
        pattern_id = list(state["patterns"].keys())[0]
        self.assertEqual(state["patterns"][pattern_id]["description"], "Need to learn this pattern")
        
        # Test without learning keywords
        self.learning._process_user_input("Just a regular message")
        state = self.learning.get_state()
        self.assertEqual(len(state["patterns"]), 1)  # No new pattern created
    
    def test_feedback_processing(self):
        """Test processing of feedback."""
        # Create pattern first
        self.learning._create_pattern("Test pattern")
        pattern_id = list(self.learning._patterns.keys())[0]
        
        # Process success feedback
        feedback = {
            "pattern_id": pattern_id,
            "success": True
        }
        self.learning._process_feedback(feedback)
        
        # Verify pattern was updated
        pattern = self.learning.get_pattern(pattern_id)
        self.assertEqual(pattern.success_count, 1)
        self.assertEqual(pattern.failure_count, 0)
        self.assertEqual(pattern.confidence, 1.0)
        
        # Process failure feedback
        feedback["success"] = False
        self.learning._process_feedback(feedback)
        
        # Verify pattern was updated
        pattern = self.learning.get_pattern(pattern_id)
        self.assertEqual(pattern.success_count, 1)
        self.assertEqual(pattern.failure_count, 1)
        self.assertEqual(pattern.confidence, 0.5)
    
    def test_memory_processing(self):
        """Test processing of memories."""
        # Create pattern first
        self.learning._create_pattern("Test pattern")
        pattern_id = list(self.learning._patterns.keys())[0]
        
        # Process memories
        memory = {
            "recent_memories": [
                {
                    "content": "This is a test pattern example",
                    "emotional_valence": 0.8
                },
                {
                    "content": "Unrelated memory",
                    "emotional_valence": 0.5
                }
            ]
        }
        
        self.learning._process_memories(memory)
        
        # Verify example was added
        pattern = self.learning.get_pattern(pattern_id)
        self.assertEqual(len(pattern.examples), 1)
        self.assertEqual(pattern.examples[0]["content"], "This is a test pattern example")
    
    def test_pattern_state_updates(self):
        """Test pattern state updates."""
        # Create pattern with some history
        self.learning._create_pattern("Test pattern")
        pattern_id = list(self.learning._patterns.keys())[0]
        pattern = self.learning.get_pattern(pattern_id)
        
        # Add some success/failure history
        pattern.update_confidence(True)
        pattern.update_confidence(True)
        pattern.update_confidence(False)
        
        # Update states
        self.learning._update_pattern_states()
        
        # Verify confidence was updated
        pattern = self.learning.get_pattern(pattern_id)
        self.assertGreater(pattern.confidence, 0.5)
    
    def test_pattern_pruning(self):
        """Test pruning of old patterns."""
        # Create pattern with old timestamp
        self.learning._create_pattern("Old pattern")
        pattern_id = list(self.learning._patterns.keys())[0]
        pattern = self.learning.get_pattern(pattern_id)
        
        # Make pattern old
        pattern.created_at = datetime.now() - timedelta(days=8)
        
        # Prune patterns
        self.learning._prune_patterns()
        state = self.learning.get_state()
        
        # Verify old pattern was removed
        self.assertNotIn(pattern_id, state["patterns"])
    
    def test_pattern_retrieval(self):
        """Test pattern retrieval methods."""
        # Create patterns of different types
        self.learning._create_pattern("Behavior pattern")
        self.learning._create_pattern("Response pattern")
        self.learning._create_pattern("Strategy pattern")
        
        # Test getting patterns by type
        behavior_patterns = self.learning.get_patterns_by_type("behavior")
        self.assertEqual(len(behavior_patterns), 1)
        self.assertEqual(behavior_patterns[0].description, "Behavior pattern")
        
        # Test getting related patterns
        pattern_id = list(self.learning._patterns.keys())[0]
        pattern = self.learning.get_pattern(pattern_id)
        pattern.add_related_pattern(list(self.learning._patterns.keys())[1])
        
        related = self.learning.get_related_patterns(pattern_id)
        self.assertEqual(len(related), 1)
    
    def test_system_update(self):
        """Test the complete update cycle."""
        # Set up test context
        context = {
            "user_input": "Need to learn this pattern",
            "feedback": {
                "pattern_id": "test_pattern",
                "success": True
            },
            "memory": {
                "recent_memories": [
                    {
                        "content": "This is a pattern example",
                        "emotional_valence": 0.8
                    }
                ]
            }
        }
        
        # Record initial state
        initial_state = self.learning.get_state()
        
        # Update system
        self.learning.update(context)
        
        # Get new state
        new_state = self.learning.get_state()
        
        # Verify changes
        self.assertGreater(len(new_state["patterns"]), len(initial_state["patterns"]))
        self.assertGreater(len(new_state["learning_history"]), 0)

if __name__ == '__main__':
    unittest.main() 
"""
Tests for the Integration subsystem.
"""
import pytest
import pytest_asyncio
import asyncio
import time
from datetime import datetime, timedelta
from core.integration import IntegrationSystem, IntegrationEvent
from core.interfaces import CognitiveSubsystem
from unittest.mock import Mock, patch, AsyncMock
from core.agent import Agent
from dialogue_interface import DialogueInterface
from llm_integration import LLMProvider
from service_locator import ServiceLocator
from core.processor import InputProcessor, ProcessingState
from core.memory import MemorySystem
from core.emotion import EmotionSystem
from core.context import State, Context
from core.attention import AttentionSystem

class MockSubsystem:
    """Mock subsystem for testing."""
    
    def __init__(self, name):
        self.name = name
        self.state = {}
    
    async def update(self, context):
        """Update subsystem state."""
        self.state = context
    
    async def get_state(self):
        """Get subsystem state."""
        return self.state

@pytest.mark.asyncio
class TestIntegrationSystem:
    """Test the Integration system functionality."""
    
    @pytest_asyncio.fixture(autouse=True)
    async def setup(self):
        """Set up test fixtures."""
        self.integration = IntegrationSystem()
        await self.integration.initialize()
        
        # Create mock subsystems
        self.memory = MockSubsystem("memory")
        self.emotion = MockSubsystem("emotion")
        self.attention = MockSubsystem("attention")
        
        # Register subsystems
        self.integration.register_subsystem("memory", self.memory)
        self.integration.register_subsystem("emotion", self.emotion)
        self.integration.register_subsystem("attention", self.attention)
        
        yield
        
        # Cleanup after tests
        if hasattr(self.integration, 'cleanup'):
            await self.integration.cleanup()
    
    async def test_event_creation(self):
        """Test creation and management of integration events."""
        # Create test event
        event = IntegrationEvent(
            event_type="data_transfer",
            source_subsystem="memory",
            target_subsystem="emotion",
            data={"key": "value"},
            priority=0.8
        )
        
        assert event.event_type == "data_transfer"
        assert event.source_subsystem == "memory"
        assert event.target_subsystem == "emotion"
        assert event.data == {"key": "value"}
        assert event.priority == 0.8
        assert event.status == "pending"
        assert event.retry_count == 0
    
    async def test_event_updates(self):
        """Test updating event attributes."""
        event = IntegrationEvent(
            event_type="state_sync",
            source_subsystem="memory",
            target_subsystem="attention",
            data={}
        )
        
        # Test status update
        event.update_status("in_progress")
        assert event.status == "in_progress"
        
        # Test result update
        event.update_status("completed", {"success": True})
        assert event.status == "completed"
        assert event.result == {"success": True}
        
        # Test retry
        event.increment_retry()
        assert event.retry_count == 1
    
    async def test_event_related(self):
        """Test event relationships."""
        # Create events
        event1 = IntegrationEvent(
            event_type="data_transfer",
            source_subsystem="memory",
            target_subsystem="emotion",
            data={}
        )
        
        event2 = IntegrationEvent(
            event_type="state_sync",
            source_subsystem="emotion",
            target_subsystem="attention",
            data={}
        )
        
        # Add related event
        event1.related_events.add("event2id")
        assert "event2id" in event1.related_events
    
    async def test_user_input_processing(self):
        """Test processing of user input."""
        # Process user input
        await self.integration.process_user_input("Test input")
        state = await self.integration.get_state()
        
        # Verify event was created
        assert len(state["events"]) == 1
        event_id = list(state["events"].keys())[0]
        assert state["events"][event_id]["event_type"] == "data_transfer"
        assert state["events"][event_id]["source_subsystem"] == "input"
    
    async def test_subsystem_state_processing(self):
        """Test processing of subsystem states."""
        # Update subsystem states
        await self.memory.update({"key": "value"})
        await self.emotion.update({"emotion": "happy"})
        
        # Process states
        await self.integration.process_subsystem_states()
        state = await self.integration.get_state()
        
        # Verify events were created
        assert len(state["events"]) == 2
    
    async def test_event_processing(self):
        """Test event processing."""
        # Create test event
        event = IntegrationEvent(
            event_type="data_transfer",
            source_subsystem="memory",
            target_subsystem="emotion",
            data={"key": "value"}
        )
        
        # Process event
        await self.integration.process_event(event)
        state = await self.integration.get_state()
        
        # Verify event was processed
        assert event.id in state["events"]
        assert state["events"][event.id]["status"] == "completed"
    
    async def test_event_state_updates(self):
        """Test event state updates."""
        # Create test event
        event = IntegrationEvent(
            event_type="state_sync",
            source_subsystem="memory",
            target_subsystem="attention"
        )
        
        # Update states
        await self.integration._update_event_states()
        
        # Verify event was updated
        assert event.status == "in_progress"
    
    async def test_event_pruning(self):
        """Test pruning of events."""
        # Create test event
        event = IntegrationEvent(
            event_type="data_transfer",
            source_subsystem="memory",
            target_subsystem="emotion"
        )
        
        # Make event old
        event.created_at = datetime.now() - timedelta(hours=2)
        
        # Prune events
        await self.integration._prune_events()
        state = await self.integration.get_state()
        
        # Verify old event was removed
        assert event.id not in state["events"]
    
    async def test_event_retrieval(self):
        """Test event retrieval methods."""
        # Create test events
        event1 = IntegrationEvent(
            event_type="data_transfer",
            source_subsystem="memory",
            target_subsystem="emotion"
        )
        
        event2 = IntegrationEvent(
            event_type="state_sync",
            source_subsystem="emotion",
            target_subsystem="attention"
        )
        
        # Test getting events by type
        data_events = self.integration.get_events_by_type("data_transfer")
        assert len(data_events) == 1
        assert data_events[0].id == event1.id
        
        # Test getting events by subsystem
        memory_events = self.integration.get_events_by_subsystem("memory")
        assert len(memory_events) == 1
        assert memory_events[0].id == event1.id
    
    async def test_system_update(self):
        """Test full system update."""
        # Create test context
        context = {
            "user_input": "Test input",
            "subsystem_states": {
                "memory": {"key": "value"},
                "emotion": {"emotion": "happy"},
                "attention": {"focus": "test"}
            }
        }
        
        # Update system
        await self.integration.update(context)
        state = await self.integration.get_state()
        
        # Verify events were created
        assert len(state["events"]) > 0

@pytest.mark.asyncio
class TestProcessorIntegration:
    """Test integration with the processor system."""
    
    @pytest_asyncio.fixture(autouse=True)
    async def setup(self):
        """Set up test fixtures."""
        self.integration = IntegrationSystem()
        await self.integration.initialize()
        
        # Create mock subsystems
        self.processor = MockSubsystem("processor")
        self.memory = MockSubsystem("memory")
        self.emotion = MockSubsystem("emotion")
        self.attention = MockSubsystem("attention")
        
        # Register subsystems
        self.integration.register_subsystem("processor", self.processor)
        self.integration.register_subsystem("memory", self.memory)
        self.integration.register_subsystem("emotion", self.emotion)
        self.integration.register_subsystem("attention", self.attention)
        
        yield
        
        # Cleanup after tests
        if hasattr(self.integration, 'cleanup'):
            await self.integration.cleanup()
    
    async def test_processor_memory_integration(self):
        """Test integration between processor and memory."""
        # Process input
        await self.processor.update({"input": "Test input"})
        await self.integration.process_subsystem_states()
        
        # Verify event was created
        state = await self.integration.get_state()
        assert len(state["events"]) == 1
        event = list(state["events"].values())[0]
        assert event.event_type == "data_transfer"
        assert event.source_subsystem == "processor"
        assert event.target_subsystem == "memory"
    
    async def test_processor_emotion_integration(self):
        """Test integration between processor and emotion."""
        # Process input
        await self.processor.update({"input": "Happy input"})
        await self.integration.process_subsystem_states()
        
        # Verify event was created
        state = await self.integration.get_state()
        assert len(state["events"]) == 1
        event = list(state["events"].values())[0]
        assert event.event_type == "data_transfer"
        assert event.source_subsystem == "processor"
        assert event.target_subsystem == "emotion"
    
    async def test_processor_attention_integration(self):
        """Test integration between processor and attention."""
        # Process input
        await self.processor.update({"input": "Important input"})
        await self.integration.process_subsystem_states()
        
        # Verify event was created
        state = await self.integration.get_state()
        assert len(state["events"]) == 1
        event = list(state["events"].values())[0]
        assert event.event_type == "data_transfer"
        assert event.source_subsystem == "processor"
        assert event.target_subsystem == "attention"
    
    async def test_full_pipeline_integration(self):
        """Test full pipeline integration."""
        # Process input through all subsystems
        await self.processor.update({"input": "Test input"})
        await self.integration.process_subsystem_states()
        
        # Verify events were created
        state = await self.integration.get_state()
        assert len(state["events"]) == 3  # One for each target subsystem
    
    async def test_error_propagation(self):
        """Test error propagation between subsystems."""
        # Create error event
        event = IntegrationEvent(
            event_type="error",
            source_subsystem="processor",
            target_subsystem="memory",
            data={"error": "Test error"}
        )
        
        # Process event
        await self.integration.process_event(event)
        
        # Verify error was propagated
        state = await self.integration.get_state()
        assert event.id in state["events"]
        assert state["events"][event.id]["status"] == "error"
    
    async def test_state_synchronization(self):
        """Test state synchronization between subsystems."""
        # Update subsystem states
        await self.processor.update({"state": "processing"})
        await self.memory.update({"state": "storing"})
        
        # Synchronize states
        await self.integration.process_subsystem_states()
        
        # Verify states were synchronized
        state = await self.integration.get_state()
        assert len(state["events"]) == 2  # One for each state update

@pytest.mark.asyncio
class TestIntegration:
    """Test integration between different subsystems."""
    
    @pytest_asyncio.fixture(autouse=True)
    async def setup(self):
        """Set up test fixtures."""
        self.integration = IntegrationSystem()
        await self.integration.initialize()
        
        # Create mock subsystems
        self.memory = MockSubsystem("memory")
        self.emotion = MockSubsystem("emotion")
        self.attention = MockSubsystem("attention")
        self.processor = MockSubsystem("processor")
        
        # Register subsystems
        self.integration.register_subsystem("memory", self.memory)
        self.integration.register_subsystem("emotion", self.emotion)
        self.integration.register_subsystem("attention", self.attention)
        self.integration.register_subsystem("processor", self.processor)
        
        yield
        
        # Cleanup after tests
        if hasattr(self.integration, 'cleanup'):
            await self.integration.cleanup()
    
    async def test_memory_emotion_integration(self):
        """Test integration between memory and emotion."""
        # Update memory state
        await self.memory.update({"memory": "Happy memory"})
        await self.integration.process_subsystem_states()
        
        # Verify event was created
        state = await self.integration.get_state()
        assert len(state["events"]) == 1
        event = list(state["events"].values())[0]
        assert event.event_type == "data_transfer"
        assert event.source_subsystem == "memory"
        assert event.target_subsystem == "emotion"
    
    async def test_processor_memory_integration(self):
        """Test integration between processor and memory."""
        # Process input
        await self.processor.update({"input": "Test input"})
        await self.integration.process_subsystem_states()
        
        # Verify event was created
        state = await self.integration.get_state()
        assert len(state["events"]) == 1
        event = list(state["events"].values())[0]
        assert event.event_type == "data_transfer"
        assert event.source_subsystem == "processor"
        assert event.target_subsystem == "memory"
    
    async def test_processor_emotion_integration(self):
        """Test integration between processor and emotion."""
        # Process input
        await self.processor.update({"input": "Happy input"})
        await self.integration.process_subsystem_states()
        
        # Verify event was created
        state = await self.integration.get_state()
        assert len(state["events"]) == 1
        event = list(state["events"].values())[0]
        assert event.event_type == "data_transfer"
        assert event.source_subsystem == "processor"
        assert event.target_subsystem == "emotion"
    
    async def test_complete_pipeline(self):
        """Test complete integration pipeline."""
        # Process input through all subsystems
        await self.processor.update({"input": "Test input"})
        await self.integration.process_subsystem_states()
        
        # Verify events were created
        state = await self.integration.get_state()
        assert len(state["events"]) == 3  # One for each target subsystem
    
    async def test_error_propagation(self):
        """Test error propagation through subsystems."""
        # Create error event
        event = IntegrationEvent(
            event_type="error",
            source_subsystem="processor",
            target_subsystem="memory",
            data={"error": "Test error"}
        )
        
        # Process event
        await self.integration.process_event(event)
        
        # Verify error was propagated
        state = await self.integration.get_state()
        assert event.id in state["events"]
        assert state["events"][event.id]["status"] == "error"
    
    async def test_state_consistency(self):
        """Test state consistency across subsystems."""
        # Update subsystem states
        await self.processor.update({"state": "processing"})
        await self.memory.update({"state": "storing"})
        await self.emotion.update({"state": "feeling"})
        await self.attention.update({"state": "focusing"})
        
        # Synchronize states
        await self.integration.process_subsystem_states()
        
        # Verify states were synchronized
        state = await self.integration.get_state()
        assert len(state["events"]) == 4  # One for each state update
    
    async def test_concurrent_processing_integration(self):
        """Test concurrent processing across subsystems."""
        # Update multiple subsystems concurrently
        await asyncio.gather(
            self.processor.update({"input": "Test 1"}),
            self.memory.update({"memory": "Memory 1"}),
            self.emotion.update({"emotion": "Happy"}),
            self.attention.update({"focus": "Focus 1"})
        )
        
        # Process states
        await self.integration.process_subsystem_states()
        
        # Verify events were created
        state = await self.integration.get_state()
        assert len(state["events"]) == 4  # One for each update
    
    async def test_resource_cleanup_integration(self):
        """Test resource cleanup across subsystems."""
        # Create test events
        for _ in range(10):
            event = IntegrationEvent(
                event_type="data_transfer",
                source_subsystem="processor",
                target_subsystem="memory"
            )
            await self.integration.process_event(event)
        
        # Cleanup
        if hasattr(self.integration, 'cleanup'):
            await self.integration.cleanup()
        
        # Verify cleanup
        state = await self.integration.get_state()
        assert len(state["events"]) == 0
    
    async def test_performance_integration(self):
        """Test performance of integration system."""
        # Measure processing time
        start_time = time.time()
        
        # Process multiple events
        for _ in range(100):
            event = IntegrationEvent(
                event_type="data_transfer",
                source_subsystem="processor",
                target_subsystem="memory"
            )
            await self.integration.process_event(event)
        
        end_time = time.time()
        processing_time = end_time - start_time
        
        # Verify performance
        assert processing_time < 1.0  # Should process 100 events in under 1 second

if __name__ == '__main__':
    pytest.main() 
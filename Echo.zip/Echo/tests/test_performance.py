"""
Performance tests for the core systems.
"""
import unittest
import time
import threading
from unittest.mock import Mock, patch
from core.memory import MemorySystem
from core.emotion import EmotionSystem
from core.processor import InputProcessor
from core.attention import AttentionSystem

class TestPerformance(unittest.TestCase):
    """Test performance of core systems."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.memory = MemorySystem()
        self.emotion = EmotionSystem()
        self.attention = AttentionSystem()
        self.processor = InputProcessor()
        
        # Connect systems
        self.processor.register_component("memory", self.memory)
        self.processor.register_component("emotion", self.emotion)
        self.processor.attention = self.attention
    
    def test_processing_speed(self):
        """Test processing speed for different input sizes."""
        input_sizes = [10, 100, 1000, 10000]
        processing_times = []
        
        for size in input_sizes:
            input_text = "x" * size
            start_time = time.time()
            result = self.processor.process(input_text)
            end_time = time.time()
            
            self.assertEqual(result["status"], "success")
            processing_times.append(end_time - start_time)
        
        # Verify processing time increases linearly or sub-linearly
        for i in range(1, len(processing_times)):
            ratio = processing_times[i] / processing_times[i-1]
            self.assertLess(ratio, 10)  # Processing time should not increase by more than 10x
    
    def test_memory_operations(self):
        """Test performance of memory operations."""
        # Test memory addition
        start_time = time.time()
        for i in range(1000):
            self.memory._process_user_input(f"Test memory {i}")
        add_time = time.time() - start_time
        
        # Test memory retrieval
        start_time = time.time()
        for i in range(1000):
            self.memory.find_related_memories(f"Test memory {i}")
        retrieve_time = time.time() - start_time
        
        # Verify operations complete within reasonable time
        self.assertLess(add_time, 5.0)  # Should add 1000 memories in under 5 seconds
        self.assertLess(retrieve_time, 5.0)  # Should retrieve 1000 memories in under 5 seconds
    
    def test_emotion_processing(self):
        """Test performance of emotion processing."""
        # Test emotion triggering
        start_time = time.time()
        for i in range(1000):
            self.emotion._trigger_emotion("happy", 0.5, f"Trigger {i}")
        trigger_time = time.time() - start_time
        
        # Test emotion decay
        start_time = time.time()
        for _ in range(1000):
            self.emotion._update_emotional_states()
        decay_time = time.time() - start_time
        
        # Verify operations complete within reasonable time
        self.assertLess(trigger_time, 5.0)  # Should trigger 1000 emotions in under 5 seconds
        self.assertLess(decay_time, 5.0)  # Should update 1000 emotions in under 5 seconds
    
    def test_concurrent_processing(self):
        """Test performance under concurrent load."""
        def process_input():
            self.processor.process("Test input")
        
        # Test with increasing number of concurrent threads
        thread_counts = [1, 2, 4, 8, 16]
        processing_times = []
        
        for count in thread_counts:
            threads = [threading.Thread(target=process_input) for _ in range(count)]
            
            start_time = time.time()
            for thread in threads:
                thread.start()
            for thread in threads:
                thread.join()
            end_time = time.time()
            
            processing_times.append(end_time - start_time)
        
        # Verify processing time increases sub-linearly with thread count
        for i in range(1, len(processing_times)):
            ratio = processing_times[i] / processing_times[i-1]
            self.assertLess(ratio, 2.0)  # Processing time should not double with thread count
    
    def test_memory_usage(self):
        """Test memory usage under load."""
        import psutil
        import os
        
        process = psutil.Process(os.getpid())
        initial_memory = process.memory_info().rss
        
        # Add large number of memories
        for i in range(10000):
            self.memory._process_user_input(f"Test memory {i}" * 100)  # Large memory content
        
        final_memory = process.memory_info().rss
        memory_increase = final_memory - initial_memory
        
        # Verify memory usage is reasonable (less than 1GB)
        self.assertLess(memory_increase, 1024 * 1024 * 1024)
    
    def test_response_time(self):
        """Test system response time under load."""
        # Process multiple inputs rapidly
        start_time = time.time()
        for _ in range(1000):
            result = self.processor.process("Test input")
            self.assertEqual(result["status"], "success")
        end_time = time.time()
        
        average_response_time = (end_time - start_time) / 1000
        
        # Verify average response time is under 100ms
        self.assertLess(average_response_time, 0.1)
    
    def test_system_stability(self):
        """Test system stability under continuous load."""
        # Run system for extended period
        start_time = time.time()
        duration = 60  # 1 minute test
        
        while time.time() - start_time < duration:
            result = self.processor.process("Test input")
            self.assertEqual(result["status"], "success")
            
            # Verify system state
            memory_state = self.memory.get_state()
            emotion_state = self.emotion.get_state()
            attention_state = self.attention.get_state()
            
            self.assertIsNotNone(memory_state)
            self.assertIsNotNone(emotion_state)
            self.assertIsNotNone(attention_state)
    
    def test_resource_cleanup_performance(self):
        """Test performance of resource cleanup."""
        # Fill systems with data
        for i in range(1000):
            self.memory._process_user_input(f"Test memory {i}")
            self.emotion._trigger_emotion("happy", 0.5, f"Trigger {i}")
        
        # Test cleanup performance
        start_time = time.time()
        self.processor.cleanup()
        cleanup_time = time.time() - start_time
        
        # Verify cleanup completes quickly
        self.assertLess(cleanup_time, 1.0)  # Should clean up in under 1 second
        
        # Verify systems are empty
        memory_state = self.memory.get_state()
        emotion_state = self.emotion.get_state()
        attention_state = self.attention.get_state()
        
        self.assertEqual(len(memory_state["memories"]), 0)
        self.assertEqual(len(emotion_state["emotions"]), 0)
        self.assertEqual(attention_state["current_attention"], 0)

if __name__ == '__main__':
    unittest.main() 
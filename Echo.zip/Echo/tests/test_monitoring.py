"""
Tests for the monitoring system.
"""
import unittest
import time
import json
import os
from pathlib import Path
from datetime import datetime
from core.monitoring import SystemMonitor, SystemMetrics

class TestSystemMetrics(unittest.TestCase):
    """Test the SystemMetrics class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.metrics = SystemMetrics()
    
    def test_response_time_tracking(self):
        """Test response time tracking."""
        # Record response times
        self.metrics.record_response_time(0.5)
        self.metrics.record_response_time(1.0)
        self.metrics.record_response_time(1.5)
        
        # Verify metrics
        metrics = self.metrics.get_metrics()
        self.assertEqual(len(metrics["response_times"]), 3)
        self.assertEqual(metrics["conversation_stats"]["average_response_time"], 1.0)
    
    def test_memory_usage_tracking(self):
        """Test memory usage tracking."""
        # Record memory usage
        self.metrics.record_memory_usage(100.0)
        self.metrics.record_memory_usage(150.0)
        
        # Verify metrics
        metrics = self.metrics.get_metrics()
        self.assertEqual(len(metrics["memory_usage"]), 2)
        self.assertEqual(metrics["memory_usage"][0], 100.0)
    
    def test_subsystem_performance_tracking(self):
        """Test subsystem performance tracking."""
        # Record performance metrics
        self.metrics.record_subsystem_performance("attention", 0.8)
        self.metrics.record_subsystem_performance("attention", 0.9)
        self.metrics.record_subsystem_performance("memory", 0.7)
        
        # Verify metrics
        metrics = self.metrics.get_metrics()
        self.assertEqual(len(metrics["subsystem_performance"]["attention"]), 2)
        self.assertEqual(len(metrics["subsystem_performance"]["memory"]), 1)
    
    def test_error_tracking(self):
        """Test error tracking."""
        # Record errors
        self.metrics.record_error("ValueError")
        self.metrics.record_error("ValueError")
        self.metrics.record_error("TypeError")
        
        # Verify metrics
        metrics = self.metrics.get_metrics()
        self.assertEqual(metrics["error_counts"]["ValueError"], 2)
        self.assertEqual(metrics["error_counts"]["TypeError"], 1)
    
    def test_conversation_stats(self):
        """Test conversation statistics."""
        # Record turns and errors
        for _ in range(5):
            self.metrics.increment_turn_count()
        self.metrics.record_error("ValueError")
        
        # Verify stats
        metrics = self.metrics.get_metrics()
        self.assertEqual(metrics["conversation_stats"]["total_turns"], 5)
        self.assertEqual(metrics["conversation_stats"]["error_rate"], 0.2)

class TestSystemMonitor(unittest.TestCase):
    """Test the SystemMonitor class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.log_dir = Path("test_logs")
        self.monitor = SystemMonitor(log_dir=str(self.log_dir))
    
    def tearDown(self):
        """Clean up test fixtures."""
        # Remove test log directory
        if self.log_dir.exists():
            for file in self.log_dir.glob("*"):
                file.unlink()
            self.log_dir.rmdir()
    
    def test_logging_setup(self):
        """Test logging configuration."""
        # Verify log directory was created
        self.assertTrue(self.log_dir.exists())
        
        # Verify loggers were created
        self.assertIn("agent", self.monitor.loggers)
        self.assertIn("attention", self.monitor.loggers)
        self.assertIn("emotion", self.monitor.loggers)
    
    def test_subsystem_event_logging(self):
        """Test subsystem event logging."""
        # Log test event
        self.monitor.log_subsystem_event(
            "agent",
            "Test event",
            "info",
            {"test_data": "value"}
        )
        
        # Verify log file was created
        log_files = list(self.log_dir.glob("*.log"))
        self.assertEqual(len(log_files), 1)
        
        # Verify log content
        with open(log_files[0]) as f:
            log_content = f.read()
            self.assertIn("Test event", log_content)
            self.assertIn("test_data", log_content)
    
    def test_turn_timing(self):
        """Test conversation turn timing."""
        # Start and end a turn
        start_time = self.monitor.start_turn()
        time.sleep(0.1)  # Simulate processing time
        self.monitor.end_turn(start_time)
        
        # Verify metrics
        metrics = self.monitor.metrics.get_metrics()
        self.assertEqual(len(metrics["response_times"]), 1)
        self.assertGreater(metrics["response_times"][0], 0.1)
        self.assertEqual(metrics["conversation_stats"]["total_turns"], 1)
    
    def test_error_recording(self):
        """Test error recording."""
        # Record test error
        test_error = ValueError("Test error")
        self.monitor.record_error("agent", test_error, {"context": "test"})
        
        # Verify error was recorded
        metrics = self.monitor.metrics.get_metrics()
        self.assertEqual(metrics["error_counts"]["ValueError"], 1)
        
        # Verify error was logged
        log_files = list(self.log_dir.glob("*.log"))
        with open(log_files[0]) as f:
            log_content = f.read()
            self.assertIn("Test error", log_content)
            self.assertIn("context", log_content)
    
    def test_checkpoint_creation(self):
        """Test system checkpoint creation."""
        # Create checkpoint
        checkpoint = self.monitor.checkpoint()
        
        # Verify checkpoint data
        self.assertIn("timestamp", checkpoint)
        self.assertIn("uptime", checkpoint)
        self.assertIn("metrics", checkpoint)
        
        # Verify checkpoint file was created
        checkpoint_files = list(self.log_dir.glob("checkpoint_*.json"))
        self.assertEqual(len(checkpoint_files), 1)
        
        # Verify checkpoint file content
        with open(checkpoint_files[0]) as f:
            checkpoint_data = json.load(f)
            self.assertEqual(checkpoint_data["timestamp"], checkpoint["timestamp"])
    
    def test_system_health(self):
        """Test system health reporting."""
        # Record some metrics
        self.monitor.metrics.record_response_time(0.5)
        self.monitor.metrics.increment_turn_count()
        self.monitor.metrics.record_error("ValueError")
        
        # Get health status
        health = self.monitor.get_system_health()
        
        # Verify health data
        self.assertIn("status", health)
        self.assertIn("uptime", health)
        self.assertIn("error_rate", health)
        self.assertIn("average_response_time", health)
        self.assertIn("total_turns", health)
        
        # Verify status calculation
        self.assertEqual(health["error_rate"], 1.0)  # 1 error in 1 turn
        self.assertEqual(health["status"], "critical")  # Error rate > 0.3

if __name__ == '__main__':
    unittest.main() 
"""
Bootstrap function for initializing the Echo cognitive agent.
"""
from typing import Dict, Any
from service_locator import ServiceLocator
from llm_integration import create_llm_provider
from dialogue_interface import create_dialogue_interface
from core.emotion import EmotionSubsystem
from core.memory import MemorySubsystem
from core.belief import BeliefSubsystem
from unified_agent import UnifiedAgent

def bootstrap_agent(config: Dict[str, Any]) -> UnifiedAgent:
    """Initialize and wire up all components of the Echo cognitive agent.
    
    Args:
        config: Configuration dictionary containing:
               - llm_provider: Type of LLM provider ("ollama" or "huggingface")
               - llm_config: Configuration for the LLM provider
               - dialogue_interface: Type of dialogue interface ("console" or "voice")
               - max_memories: Maximum number of memories to keep (optional)
    
    Returns:
        An initialized UnifiedAgent instance.
        
    Raises:
        ValueError: If required configuration is missing.
    """
    # Validate required configuration
    required_keys = {"llm_provider", "llm_config", "dialogue_interface"}
    missing_keys = required_keys - set(config.keys())
    if missing_keys:
        raise ValueError(f"Missing required configuration keys: {missing_keys}")
    
    # Create service locator
    service_locator = ServiceLocator()
    
    # Initialize LLM provider
    llm = create_llm_provider(
        config["llm_provider"],
        **config["llm_config"]
    )
    service_locator.register(type(llm), llm)
    
    # Initialize dialogue interface
    dialogue = create_dialogue_interface(config["dialogue_interface"])
    service_locator.register(type(dialogue), dialogue)
    
    # Initialize cognitive subsystems
    emotion = EmotionSubsystem()
    service_locator.register(type(emotion), emotion)
    
    memory = MemorySubsystem(
        max_memories=config.get("max_memories", 100)
    )
    service_locator.register(type(memory), memory)
    
    belief = BeliefSubsystem()
    service_locator.register(type(belief), belief)
    
    # Create and return the unified agent
    return UnifiedAgent(service_locator)

def create_default_config() -> Dict[str, Any]:
    """Create a default configuration for the Echo cognitive agent.
    
    Returns:
        A dictionary containing default configuration values.
    """
    return {
        "llm_provider": "ollama",
        "llm_config": {
            "model_name": "llama2",
            "base_url": "http://localhost:11434"
        },
        "dialogue_interface": "console",
        "max_memories": 100
    } 
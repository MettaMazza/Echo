"""
Service locator for dependency injection in the Echo cognitive agent system.
"""
from typing import Any, Dict, Type, TypeVar

T = TypeVar('T')

class ServiceLocator:
    """A simple service locator for dependency injection."""
    
    def __init__(self):
        self._services: Dict[Type, Any] = {}
    
    def register(self, service_type: Type[T], instance: T) -> None:
        """Register a service instance.
        
        Args:
            service_type: The type of the service.
            instance: The service instance to register.
        """
        self._services[service_type] = instance
    
    def get(self, service_type: Type[T]) -> T:
        """Get a registered service instance.
        
        Args:
            service_type: The type of the service to retrieve.
            
        Returns:
            The registered service instance.
            
        Raises:
            KeyError: If the service type is not registered.
        """
        if service_type not in self._services:
            raise KeyError(f"Service of type {service_type.__name__} not registered")
        return self._services[service_type]
    
    def has(self, service_type: Type[T]) -> bool:
        """Check if a service type is registered.
        
        Args:
            service_type: The type of the service to check.
            
        Returns:
            True if the service type is registered, False otherwise.
        """
        return service_type in self._services 
# Echo Cognitive Agent Troubleshooting Guide

This guide provides solutions for common issues and problems that may arise when running the Echo cognitive agent.

## Quick Diagnostics

### 1. Check System Status

```bash
# View system health
curl localhost:9090/metrics | grep echo_health

# Check memory usage
docker stats echo-agent

# View recent logs
tail -n 100 logs/echo.log
```

### 2. Common Error Codes

| Error Code | Description | Solution |
|------------|-------------|----------|
| E001 | LLM API Connection Error | Check API key and network connection |
| E002 | Memory System Error | Verify disk space and permissions |
| E003 | State Corruption | Restore from backup |
| E004 | Configuration Error | Validate config.json |
| E005 | Subsystem Failure | Check subsystem logs |

## Detailed Troubleshooting

### 1. Performance Issues

#### High Response Times

**Symptoms:**
- Slow response to user input
- High latency in subsystem operations
- Increased memory usage

**Diagnosis:**
```bash
# Check response time metrics
curl localhost:9090/metrics | grep response_time

# Monitor subsystem health
curl localhost:9090/metrics | grep subsystem_health
```

**Solutions:**
1. Adjust worker pool size:
```json
{
  "memory": {
    "max_workers": 8
  }
}
```

2. Optimize memory usage:
```json
{
  "memory": {
    "page_size": 50,
    "cleanup_interval": 3600
  }
}
```

3. Check LLM API latency:
```bash
curl -w "%{time_total}\n" -o /dev/null -s https://api.openai.com/v1/chat/completions
```

#### Memory Leaks

**Symptoms:**
- Increasing memory usage over time
- Slow performance after extended operation
- System crashes

**Diagnosis:**
```bash
# Monitor memory usage
watch -n 1 'docker stats echo-agent --no-stream'

# Check memory metrics
curl localhost:9090/metrics | grep memory_usage
```

**Solutions:**
1. Enable memory cleanup:
```json
{
  "memory": {
    "cleanup_interval": 1800,
    "max_memory_mb": 1024
  }
}
```

2. Adjust garbage collection:
```bash
export PYTHONMALLOC=debug
python echo.py
```

### 2. System Errors

#### LLM API Issues

**Symptoms:**
- Failed API calls
- Invalid responses
- Authentication errors

**Diagnosis:**
```bash
# Check API key
echo $LLM_API_KEY

# Test API connection
curl -H "Authorization: Bearer $LLM_API_KEY" \
     https://api.openai.com/v1/chat/completions
```

**Solutions:**
1. Verify API key:
```bash
# Update .env file
LLM_API_KEY=your_new_key
```

2. Check API limits:
```bash
curl -H "Authorization: Bearer $LLM_API_KEY" \
     https://api.openai.com/v1/usage
```

#### State/Memory Corruption

**Symptoms:**
- Inconsistent state
- Missing memories
- System crashes

**Diagnosis:**
```bash
# Check state files
ls -l state/
ls -l memory/

# Verify file integrity
md5sum state/*.json
```

**Solutions:**
1. Restore from backup:
```bash
./restore.sh backups/latest
```

2. Repair state:
```bash
python repair_state.py --state-dir state/
```

### 3. Configuration Issues

#### Invalid Configuration

**Symptoms:**
- Startup failures
- Missing features
- Unexpected behavior

**Diagnosis:**
```bash
# Validate configuration
python validate_config.py config.json

# Check schema
python generate_docs.py
```

**Solutions:**
1. Fix configuration:
```json
{
  "llm": {
    "model_name": "gpt-3.5-turbo",
    "temperature": 0.7,
    "max_tokens": 100
  },
  "memory": {
    "page_size": 50,
    "max_workers": 4
  }
}
```

2. Reset to defaults:
```bash
cp config.default.json config.json
```

### 4. Monitoring Issues

#### Metrics Not Showing

**Symptoms:**
- Empty Grafana dashboards
- Missing Prometheus metrics
- Incomplete monitoring

**Diagnosis:**
```bash
# Check Prometheus connection
curl localhost:9090/metrics

# Verify Grafana data source
curl localhost:3000/api/datasources
```

**Solutions:**
1. Restart monitoring:
```bash
docker-compose restart prometheus grafana
```

2. Update metrics configuration:
```yaml
# prometheus.yml
scrape_configs:
  - job_name: 'echo'
    static_configs:
      - targets: ['echo-agent:9090']
```

### 5. Deployment Issues

#### Container Problems

**Symptoms:**
- Container won't start
- Port conflicts
- Volume mount errors

**Diagnosis:**
```bash
# Check container status
docker ps -a

# View container logs
docker logs echo-agent

# Check port usage
netstat -tulpn | grep 9090
```

**Solutions:**
1. Fix port conflicts:
```bash
# Stop conflicting service
sudo systemctl stop conflicting-service

# Or use different port
docker run -p 9091:9090 echo-agent
```

2. Fix volume mounts:
```bash
# Check permissions
sudo chown -R 1000:1000 state/ memory/ logs/

# Verify mount points
docker inspect echo-agent | grep Mounts
```

## Advanced Troubleshooting

### 1. Debug Mode

Enable debug logging:
```bash
# Set log level
export LOG_LEVEL=DEBUG

# Start with debug
python echo.py --debug
```

### 2. Performance Profiling

Profile system performance:
```bash
# Install profiling tools
pip install py-spy

# Profile CPU usage
py-spy record -o profile.svg --pid $(pgrep -f echo.py)

# Profile memory usage
py-spy record -o memory.svg --pid $(pgrep -f echo.py) --memory
```

### 3. Network Diagnostics

Check network connectivity:
```bash
# Test API endpoints
curl -v https://api.openai.com/v1/chat/completions

# Check DNS resolution
nslookup api.openai.com

# Monitor network traffic
tcpdump -i any port 443
```

## Recovery Procedures

### 1. System Recovery

1. Stop the agent:
```bash
docker stop echo-agent
```

2. Backup current state:
```bash
./backup.sh
```

3. Restore from backup:
```bash
./restore.sh backups/latest
```

4. Start the agent:
```bash
docker start echo-agent
```

### 2. Data Recovery

1. Check backup integrity:
```bash
./verify_backup.sh backups/latest
```

2. Restore specific components:
```bash
# Restore state only
./restore.sh backups/latest --state-only

# Restore memory only
./restore.sh backups/latest --memory-only
```

### 3. Configuration Recovery

1. Reset configuration:
```bash
cp config.default.json config.json
```

2. Update configuration:
```bash
python update_config.py --reset
```

## Getting Help

If you're still experiencing issues:

1. Check the logs:
```bash
tail -f logs/echo.log
```

2. Review metrics:
```bash
curl localhost:9090/metrics
```

3. Contact support:
- Email: support@echo-agent.com
- GitHub: https://github.com/your-org/echo/issues
- Documentation: https://echo-agent.com/docs

## Prevention

### 1. Regular Maintenance

1. Daily checks:
```bash
./health_check.sh
```

2. Weekly maintenance:
```bash
./maintenance.sh
```

### 2. Monitoring Setup

1. Set up alerts:
```yaml
# alertmanager.yml
receivers:
  - name: 'team-echo'
    email_configs:
      - to: 'team@echo-agent.com'
```

2. Configure thresholds:
```json
{
  "monitoring": {
    "alert_thresholds": {
      "memory_usage": 80,
      "response_time": 2.0,
      "error_rate": 0.01
    }
  }
}
```

### 3. Backup Strategy

1. Schedule backups:
```bash
# Add to crontab
0 */4 * * * /path/to/backup.sh
```

2. Verify backups:
```bash
# Add to crontab
0 0 * * * /path/to/verify_backups.sh
``` 
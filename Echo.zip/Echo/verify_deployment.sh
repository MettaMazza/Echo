#!/bin/bash

# Exit on error
set -e

# Configuration
HEALTH_CHECK_TIMEOUT=60
METRICS_CHECK_TIMEOUT=30
MAX_RETRIES=3
RETRY_INTERVAL=10

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "Starting deployment verification..."

# Function to check if a command succeeds
check_command() {
    if ! $@; then
        echo -e "${RED}Error: Command '$@' failed${NC}"
        return 1
    fi
    return 0
}

# Function to wait for a condition
wait_for_condition() {
    local condition=$1
    local timeout=$2
    local message=$3
    local start_time=$(date +%s)
    
    echo -n "Waiting for $message... "
    while ! $condition; do
        if [ $(($(date +%s) - start_time)) -gt $timeout ]; then
            echo -e "${RED}Timeout${NC}"
            return 1
        fi
        sleep 1
    done
    echo -e "${GREEN}Done${NC}"
    return 0
}

# Check if containers are running
echo "Checking container status..."
if ! docker-compose ps | grep -q "Up"; then
    echo -e "${RED}Error: Containers are not running${NC}"
    exit 1
fi

# Check container health
check_health() {
    curl -s http://localhost:9090/health | grep -q "healthy"
}

wait_for_condition check_health $HEALTH_CHECK_TIMEOUT "health check"

# Check metrics endpoint
check_metrics() {
    curl -s http://localhost:9090/metrics | grep -q "echo_requests_total"
}

wait_for_condition check_metrics $METRICS_CHECK_TIMEOUT "metrics endpoint"

# Check log rotation
echo "Checking log rotation..."
if ! ls -l logs/ | grep -q "\.gz$"; then
    echo -e "${YELLOW}Warning: No archived logs found${NC}"
fi

# Check disk space
echo "Checking disk space..."
DISK_USAGE=$(df -h . | awk 'NR==2 {print $5}' | sed 's/%//')
if [ $DISK_USAGE -gt 80 ]; then
    echo -e "${YELLOW}Warning: High disk usage ($DISK_USAGE%)${NC}"
fi

# Check memory usage
echo "Checking memory usage..."
MEMORY_USAGE=$(docker stats --no-stream --format "{{.MemUsage}}" echo-agent | cut -d'/' -f1 | sed 's/MiB//')
if [ $(echo "$MEMORY_USAGE > 1000" | bc) -eq 1 ]; then
    echo -e "${YELLOW}Warning: High memory usage (${MEMORY_USAGE}MiB)${NC}"
fi

# Verify all subsystems
echo "Verifying subsystems..."
for subsystem in "memory" "emotion" "attention" "learning"; do
    if ! curl -s http://localhost:9090/metrics | grep -q "echo_subsystem_health.*$subsystem"; then
        echo -e "${RED}Error: Subsystem $subsystem not reporting health${NC}"
        exit 1
    fi
done

# Check for errors in logs
echo "Checking for errors in logs..."
ERROR_COUNT=$(grep -c "ERROR" logs/echo.log)
if [ $ERROR_COUNT -gt 0 ]; then
    echo -e "${YELLOW}Warning: Found $ERROR_COUNT errors in logs${NC}"
fi

# Final verification
echo "Performing final checks..."
for i in $(seq 1 $MAX_RETRIES); do
    if check_health && check_metrics; then
        echo -e "${GREEN}Deployment verified successfully!${NC}"
        exit 0
    fi
    echo "Retry $i/$MAX_RETRIES..."
    sleep $RETRY_INTERVAL
done

echo -e "${RED}Deployment verification failed after $MAX_RETRIES retries${NC}"
exit 1 